$(function(){

  // モバイルヘッダー用メニュークリック開閉
  $('#menu-btn').on('click', function(){
    $('.responsive-menu').slideToggle("fast");
    // 開いているメニューがあったら閉じる
    $('.fgnp-dropdown-menu ul').removeClass('show').css('display','none');
  });

  // モバイルヘッダー、デスクトップ用ヘッダー、タッチデバイス可否で処理分け
  $(window).on('load resize', function() {
    // モバイルヘッダー
    if (window.matchMedia('(max-width:880px)').matches) {
      resetEvent();
      $('[class*="-drpdwn"] > a').on('click', function(event){
          $(this).next().slideToggle("fast");
          event.preventDefault();
      });
    // デスクトップ用ヘッダー
    } else {
      // 開いているメニューがあったら閉じる
      $('.fgnp-dropdown-menu ul').removeClass('show').css('display','none');
      $('.responsive-menu').css('display','none');

      // タッチデバイス
      if (isTouchDevice()) {
        resetEvent();
        $('.primary-drpdwn > a').on('click', function(event){
          if($(this).next().hasClass('show')) {
            $('.primary-drpdwn ul').removeClass('show');
          } else {
            $('.primary-drpdwn ul').removeClass('show');
            $(this).next().addClass('show');
            
            var trigger = "body";
            $(document.createElement('div'))
              .addClass('toggle-backdrop')
              .appendTo(trigger)
              .on('click', function(){
                $('.fgnp-dropdown').removeClass('show');
                $('.toggle-backdrop').remove();
              });
              
          }
          event.preventDefault();
        });
        //2階層目の表示/非表示
        $('.primary-drpdwn > ul > .secondary-drpdwn > a').on('click', function(){
          // console.log('セカンド');
          if($(this).children("ul").hasClass('show')) {
            $('.secondary-drpdwn ul').removeClass('show');
          } else {
            $('.secondary-drpdwn ul').removeClass('show');
            $(this).next().addClass('show');
          }
        });
        //3階層目の表示/非表示    
        $('.primary-drpdwn > ul > .secondary-drpdwn .secondary-drpdwn > a').on('click', function(){
          // console.log('サード');
          if($(this).children("ul").hasClass('show')) {
            $('.secondary-drpdwn .secondary-drpdwn ul').removeClass('show');
          } else {
            $('.secondary-drpdwn .secondary-drpdwn ul').removeClass('show');
            $(this).next().addClass('show');
          }
        });
        
      // 非タッチデバイス(マウスオーバーで表示)
      } else {
        resetEvent();
        
        $('.fgnp-dropdown-menu').on('touchstart', function(){
            $(this).children("ul").addClass('show');
                       
        })
        .on('mouseenter', function(){
          $(this).children("ul").addClass('show');
          
        })
        .on('mouseleave', function(){
          $(this).children("ul").removeClass('show');          
        });                
      }           
    }
  });

  // タッチデバイス判定
  function isTouchDevice() {
    var result = false;
    if (window.ontouchstart === null) {
      result = true;
    }
    return result;
  }

  // イベントリセット
  function resetEvent() {
    $('[class*="-drpdwn"] > a').off('click');
    $('.fgnp-dropdown-menu').off('touchstart').off('mouseenter').off('mouseleave');
  }

});