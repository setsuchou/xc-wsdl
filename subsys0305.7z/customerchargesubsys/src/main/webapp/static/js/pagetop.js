$(function(){
    var topBtn=$('#pagetop');//トップに戻るボタン
    topBtn.hide();

    // ページ上部に飛ぶ
    $('#pagetop a[href^=#]').click(function() {
      var href= $(this).attr('href');
      var speed = 100; //アニメーションの速度
      var target = $(href == '#' || href == '' ? 'html' : href);
      var headerHeight = 100; //固定ヘッダーの高さ
      var position = target.offset().top - headerHeight; //ターゲットの座標からヘッダの高さ分引く
      $('body,html').animate({scrollTop:position}, speed, 'swing');
      return false;
    });

    //ボタンの表示設定
    $(window).scroll(function(){
      if($(this).scrollTop() > 60){
        // 画面を60pxスクロールしたら、ボタンを表示する
        topBtn.fadeIn();
      }else{
        // 画面が60pxより上なら、ボタンを表示しない
        topBtn.fadeOut();
      }
    });
});