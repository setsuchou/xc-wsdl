package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｍ＿料金プランMapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.ORAC0030Service;

@Service("ORAC0030Service")
public class ORAC0030ServiceImpl implements ORAC0030Service {

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private Ｍ＿料金プランMapper Ｍ＿料金プランMapper;

	/*
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0030Service#getＴ＿契約情報ByPrimaryKey(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public int updateByPrimaryKey(Ｔ＿契約情報 record) {

		return Ｔ＿契約情報Mapper.updateByPrimaryKey(record);
	}


	@Override
	public List<Ｍ＿料金プラン> getRyokimPuran() {
		List<Ｍ＿料金プラン> returnList = Ｍ＿料金プランMapper.selectAll();

		return returnList;
	}

}
