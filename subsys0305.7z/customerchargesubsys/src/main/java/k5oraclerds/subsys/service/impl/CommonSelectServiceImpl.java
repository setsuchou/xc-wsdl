package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｍ＿メッセージMapper;
import k5oraclerds.subsys.dao.Ｍ＿商品型Mapper;
import k5oraclerds.subsys.dao.Ｍ＿料金プランMapper;
import k5oraclerds.subsys.dao.Ｍ＿期間調整商品型Mapper;
import k5oraclerds.subsys.dao.Ｍ＿注文種別Mapper;
import k5oraclerds.subsys.dao.Ｍ＿超過使用料Mapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.dao.Ｔ＿注文情報Mapper;
import k5oraclerds.subsys.dao.Ｔ＿注文明細Mapper;
import k5oraclerds.subsys.dao.Ｔ＿無効化対象Mapper;
import k5oraclerds.subsys.dao.Ｔ＿ｐａｙｇ情報Mapper;
import k5oraclerds.subsys.model.Ｍ＿メッセージ;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿期間調整商品型;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｍ＿超過使用料;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.model.Ｔ＿無効化対象;
import k5oraclerds.subsys.model.Ｔ＿ｐａｙｇ情報;
import k5oraclerds.subsys.service.CommonSecletService;

@Service("CommonSelectService")
public class CommonSelectServiceImpl implements CommonSecletService {

	public CommonSelectServiceImpl() {
	}

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private Ｔ＿注文情報Mapper Ｔ＿注文情報Mapper;

	@Autowired
	private Ｔ＿注文明細Mapper Ｔ＿注文明細Mapper;

	@Autowired
	private Ｍ＿超過使用料Mapper Ｍ＿超過使用料Mapper;

	@Autowired
	private Ｍ＿期間調整商品型Mapper Ｍ＿期間調整商品型Mapper;

	@Autowired
	private Ｔ＿ｐａｙｇ情報Mapper Ｔ＿ｐａｙｇ情報Mapper;

	@Autowired
	private Ｍ＿商品型Mapper Ｍ＿商品型Mapper;

	@Autowired
	private Ｍ＿注文種別Mapper Ｍ＿注文種別Mapper;

	@Autowired
	private Ｍ＿料金プランMapper Ｍ＿料金プランMapper;

	@Autowired
	private Ｔ＿無効化対象Mapper Ｔ＿無効化対象Mapper;

	@Autowired
	private Ｍ＿メッセージMapper Ｍ＿メッセージMapper;

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public Ｔ＿契約情報 selectByPrimaryKeyKeiyakuJoho(String ｋ５契約番号, String サービス申込番号) {
		Ｔ＿契約情報 Ｔ＿契約情報 = Ｔ＿契約情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号);
		return Ｔ＿契約情報;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.Short)
	 */
	@Override
	public Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号, Short 連番) {
		Ｔ＿注文情報 Ｔ＿注文情報 = Ｔ＿注文情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番);
		return Ｔ＿注文情報;
	}
	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.Short)
	 */
	@Override
	public Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号) {
		Ｔ＿注文情報 Ｔ＿注文情報 = Ｔ＿注文情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号,null);
		return Ｔ＿注文情報;
	}


	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.Short, java.lang.String)
	 */
	@Override
	public Ｔ＿注文明細 selectByPrimaryKeyChumonjohoMeisai(String ｋ５契約番号, String サービス申込番号, Short 連番, String 商品型ｉｄ) {
		Ｔ＿注文明細 Ｔ＿注文明細 = Ｔ＿注文明細Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番, 商品型ｉｄ);
		return Ｔ＿注文明細;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ｔ＿ｐａｙｇ情報 selectByPrimaryKey(String ｋ５契約番号, String サービス申込番号, String 年月, String 商品型ｉｄ) {
		Ｔ＿ｐａｙｇ情報 Ｔ＿ｐａｙｇ情報 = Ｔ＿ｐａｙｇ情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 年月, 商品型ｉｄ);
		return Ｔ＿ｐａｙｇ情報;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ｍ＿超過使用料 selectByPrimaryKey(String 料金プランｉｄ, String 適用開始年月, String 適用終了年月) {
		Ｍ＿超過使用料 Ｍ＿超過使用料 = Ｍ＿超過使用料Mapper.selectByPrimaryKey(料金プランｉｄ, 適用開始年月, 適用終了年月);
		return Ｍ＿超過使用料;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String)
	 */
	@Override
	public Ｍ＿期間調整商品型 selectByPrimaryKey(String 商品型ｉｄ) {
		Ｍ＿期間調整商品型 Ｍ＿期間調整商品型 = Ｍ＿期間調整商品型Mapper.selectByPrimaryKey(商品型ｉｄ);
		return Ｍ＿期間調整商品型;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectAllMukokaTaisho()
	 */
	@Override
	public List<Ｔ＿無効化対象> selectAllMukokaTaisho() {
		List<Ｔ＿無効化対象> list = Ｔ＿無効化対象Mapper.selectAll();
		return list;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see k5oraclerds.subsys.service.commonSecletService#getAllShohinGata()
	 */
	@Override
	public List<Ｍ＿商品型> selectAllShohinGata() {
		List<Ｍ＿商品型> list = Ｍ＿商品型Mapper.selectAll();
		return list;
	}

	public List<Ｍ＿商品型> selectShohinGataForChumonmesai(String 料金プランｉｄ, String 適用日){
		List<Ｍ＿商品型> list = Ｍ＿商品型Mapper.selectForChumonmesai(料金プランｉｄ,適用日);
		return list;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see k5oraclerds.subsys.service.commonSecletService#getAllRyokimPuran()
	 */
	@Override
	public List<Ｍ＿料金プラン> selectAllRyokimPuran() {
		List<Ｍ＿料金プラン> list = Ｍ＿料金プランMapper.selectAll();
		return list;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#getAllChumonShubetsu()
	 */
	@Override
	public List<Ｍ＿注文種別> selectAllChumonShubetsu() {
		List<Ｍ＿注文種別> list = Ｍ＿注文種別Mapper.selectAll();
		return list;
	}

	@Override
	public boolean 契約情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号){
		Ｔ＿契約情報 keiyakuJoho = selectByPrimaryKeyKeiyakuJoho(ｋ５契約番号, サービス申込番号);
		return 論理削除フラグ判断(keiyakuJoho.get論理削除フラグ());
	}

	@Override
	public boolean 注文情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番){
		Ｔ＿注文情報 chumonJoho = selectByPrimaryKeyChumonJoho(ｋ５契約番号,サービス申込番号,連番);
		return 論理削除フラグ判断(chumonJoho.get論理削除フラグ());
	}

	@Override
	public boolean 注文明細論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番, String 商品型ｉｄ){
		Ｔ＿注文明細 chumonjohoMeisai = selectByPrimaryKeyChumonjohoMeisai(ｋ５契約番号,サービス申込番号,連番,商品型ｉｄ);
		return  論理削除フラグ判断(chumonjohoMeisai.get論理削除フラグ());
	}

	private boolean 論理削除フラグ判断(String 論理削除フラグ){
		if(論理削除フラグ.equals("1")){
			return true;
		}else{
			return false;
		}
	}

	/*
	 *
	 * @see
	 * lang.String, java.lang.String)
	 */
	@Override
	public String selectMessagesText(String messageId){
		Ｍ＿メッセージ message = Ｍ＿メッセージMapper.selectByPrimaryKey(messageId);
		return message.getメッセージ文言();
	}

}
