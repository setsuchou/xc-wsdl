package k5oraclerds.subsys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

public interface ORAC0020FormMeisaiMapper {

	/**
	 * 契約条件をもとにORAC0020Form画面の明細を検索する
	 */
	List<ORAC0020FormMeisai> selectMeisaiByKeiyakuCondition(@Param("sabisuMoshikomiBango") String サービス申込番号,
			@Param("k5keiyakubango") String Ｋ５契約番号, @Param("aidenteiteiDmein") String アイデンティティドメイン,
			@Param("sabisushuryoBiFrom") String サービス終了日FROM, @Param("sabisushuryoBiTo") String サービス終了日TO);

	/**
	 * 注文条件をもとにORAC0020Form画面の明細を検索する
	 */
	List<ORAC0020FormMeisai> selectMeisaiByChumonCondition(@Param("sabisuMoshikomiBango") String サービス申込番号,
			@Param("k5keiyakubango") String Ｋ５契約番号, @Param("remban") Short 連番,
			@Param("aidenteiteiDmein") String アイデンティティドメイン, @Param("sabisushuryoBiFrom") String サービス終了日FROM,
			@Param("sabisushuryoBiTo") String サービス終了日TO, @Param("tekiyoKaishiKibobiFrom") String 適用開始希望日FROM,
			@Param("tekiyoKaishiKibobiTo") String 適用開始希望日TO);

}