package k5oraclerds.subsys.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.service.CommonSecletService;
import k5oraclerds.subsys.service.ORAC0010Service;
import k5oraclerds.subsys.service.impl.ORAC0010ServiceImpl;
import k5oraclerds.subsys.webform.ORAC0010Form;

@Controller
@RequestMapping(value = "/ORAC0010Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0010Controller {

	@Resource
	private ORAC0010Service ORAC0010Service;

	@Resource
	private CommonSecletService commonSecletService;

	@RequestMapping("/init")
	public String init(Model model) {
		ORAC0010Form ORAC0010Form = new ORAC0010Form();

		// 画面フォームの初期化を行う
		initForm(ORAC0010Form);
		model.addAttribute("ORAC0010Form", ORAC0010Form);

		// ORAC0010画面へ遷移する
		return "ORAC0010Form";
	}

	/**
	 * 画面初期化時、フォームインスタンスを生成する。
	 *
	 * @param ORAC0010Form
	 */
	private void initForm(ORAC0010Form ORAC0010Form) {

		// 契約情報を初期化する
		ORAC0010Form.setKeiyakuJoho(new Ｔ＿契約情報());

		// 注文情報を初期化する
		ORAC0010Form.setChumonjoho(new Ｔ＿注文情報());

		// 注文明細を初期化する
		List<Ｔ＿注文明細> chumonjohoMesaiList = new ArrayList<Ｔ＿注文明細>();
		Ｔ＿注文明細 chumonjohoMesai = new Ｔ＿注文明細();
		chumonjohoMesai.setＦｊ単価(new BigDecimal("1000"));
		chumonjohoMesaiList.add(chumonjohoMesai);
		ORAC0010Form.setChumonjohoMeisaiList(chumonjohoMesaiList);

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);

		// TODO テストのため、この後に削除する
		// 契約情報テストデータを取得する
		// Ｔ＿契約情報 keiyakuJoho =
		// commonSecletService.selectByPrimaryKeyKeiyakuJoho("00001001",
		// "000000000000001");
		//
		// Ｔ＿注文情報 chumonjoho =
		// commonSecletService.selectByPrimaryKeyChumonJoho("00001001",
		// "000000000000001", new Short("1"));
		//
		// Ｔ＿注文明細 Ｔ＿注文明細 =
		// commonSecletService.selectByPrimaryKeyChumonjohoMeisai("00001001",
		// "000000000000001", new Short("1"),
		// "ORA0000101");
		List<Ｔ＿注文明細> chumonjohoMeisaiList = new ArrayList<Ｔ＿注文明細>();
		Ｔ＿注文明細 Ｔ＿注文明細 = new Ｔ＿注文明細();
		chumonjohoMeisaiList.add(Ｔ＿注文明細);

		// ORAC0010Form.setKeiyakuJoho(keiyakuJoho);
		//
		// ORAC0010Form.setChumonjoho(chumonjoho);

		ORAC0010Form.setChumonjohoMeisaiList(chumonjohoMeisaiList);

		// 料金プラン、注文種別プルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);
	}

	/**
	 * ORAC0010画面上の料金プラン、注文種別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0010Form
	 */
	private void initPullDownList(ORAC0010Form ORAC0010Form) {

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = ORAC0010Service.getShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		// 商品型が存在する場合、フォーム情報に設定する
		if (shohinGatas.size() > 0) {
			ORAC0010Form.setShohinGataMap(Collections.unmodifiableMap(shohinGatas));
		}

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0010Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0010Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuMap = ORAC0010Service.getChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuMap) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}

		// 注文種別が存在する場合、フォーム情報に設定する
		if (chumonShubetsus.size() > 0) {
			ORAC0010Form.setChumonShubetsuMap(Collections.unmodifiableMap(chumonShubetsus));
		}
	}

	/**
	 *
	 * @return
	 */
	@RequestMapping("/insert")
	public String insert(@Valid @ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form, BindingResult result) {
		if (result.hasErrors()) {
			result.getAllErrors().get(0).getCode();
			return "ORAC0010Form";
		}

		String ｋ５契約番号;
		String サービス申込番号;
		String エラーメッセージID = "E005";
		// Ｔ＿契約情報の登録する
		Ｔ＿契約情報 keiyakuJoho = ORAC0010Form.getKeiyakuJoho();
		ｋ５契約番号 = keiyakuJoho.getＫ５契約番号();
		サービス申込番号 = keiyakuJoho.getサービス申込番号();
		boolean 論理削除フラグ判断 = commonSecletService.契約情報論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号);
		if (論理削除フラグ判断) {
			Ｔ＿契約情報 keiyakuJohoUpdate = new Ｔ＿契約情報();
			keiyakuJohoUpdate.setＫ５契約番号(ｋ５契約番号);
			keiyakuJohoUpdate.setサービス申込番号(サービス申込番号);
			keiyakuJohoUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
			keiyakuJohoUpdate.setオーダーｎｏ(keiyakuJoho.getオーダーｎｏ());
			keiyakuJohoUpdate.set論理削除フラグ("0");
			keiyakuJohoUpdate.set更新日時(new Date());
			keiyakuJohoUpdate.set更新ユーザー("WEB_TEST01");
			ORAC0010Service ORAC0010Service = new ORAC0010ServiceImpl();
			ORAC0010Service.updateInsertKeiyakuJoho(keiyakuJohoUpdate);
		} else {
			// エラーメッセージ[E005]をダイアログ表示し、OKボタン押下後は、新規登録ボタン押下前の状態に戻る。
			String エラーメッセージ文言 = commonSecletService.selectMessagesText(エラーメッセージID);
			return "ORAC0010Form";
		}

		// Ｔ＿注文情報の登録する
		Short short001 = new Short("001");
		Ｔ＿注文情報 chumonJoho = ORAC0010Form.getChumonjoho();
		論理削除フラグ判断 = commonSecletService.注文情報論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号, short001);
		if (論理削除フラグ判断) {
			Ｔ＿注文情報 chumonJohoUpdate = new Ｔ＿注文情報();
			chumonJohoUpdate.setＫ５契約番号(ｋ５契約番号);
			chumonJohoUpdate.setサービス申込番号(サービス申込番号);
			chumonJohoUpdate.set連番(short001);
			chumonJohoUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
			chumonJohoUpdate.set注文種別ｉｄ(chumonJoho.get注文種別ｉｄ());
			chumonJohoUpdate.set見積日(chumonJoho.get見積日());
			// chumonJohoUpdate;//画面のFJ単価適用日
			chumonJohoUpdate.setＦｊ料金表適用日(chumonJoho.getＦｊ料金表適用日());
			// chumonJohoUpdate;//画面のOracle単価適用日
			chumonJohoUpdate.setＯｒａｃｌｅ料金表適用日(chumonJoho.getＯｒａｃｌｅ料金表適用日());
			chumonJohoUpdate.set適用開始希望日(chumonJoho.get適用開始希望日());
			chumonJohoUpdate.set特別値引フラグ(chumonJoho.get特別値引フラグ());
			chumonJohoUpdate.setＰａａｓ連携済フラグ("0");
			chumonJohoUpdate.set請求依頼抽出済フラグ("0");
			chumonJohoUpdate.set論理削除フラグ("0");
			chumonJohoUpdate.set更新日時(new Date());
			chumonJohoUpdate.set更新ユーザー("WEB_TEST01");
			ORAC0010Service.updateInsertChumonjoho(chumonJohoUpdate);
		} else {
			// エラーメッセージ[E005]をダイアログ表示し、OKボタン押下後は、新規登録ボタン押下前の状態に戻る。
			String エラーメッセージ文言 = commonSecletService.selectMessagesText(エラーメッセージID);
			return "ORAC0010Form";
		}

		// Ｔ＿注文明細の登録する
		List<Ｔ＿注文明細> chumonjohoMeisaiList = ORAC0010Form.getChumonjohoMeisaiList();
		// List<Ｔ＿注文明細> chumonjohoMeisaiSelectedList =
		// commonSecletService.selectByPrimaryKeyChumonjohoMeisai(ｋ５契約番号,
		// サービス申込番号);
		if (chumonjohoMeisaiList != null && chumonjohoMeisaiList.size() != 0) {
			for (Ｔ＿注文明細 chumonjohoMeisai : chumonjohoMeisaiList) {
				論理削除フラグ判断 = commonSecletService.注文明細論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号, short001,
						chumonjohoMeisai.get商品型ｉｄ());
				if (論理削除フラグ判断) {
					Ｔ＿注文明細 chumonjohoMeisaiUpdate = new Ｔ＿注文明細();
					chumonjohoMeisaiUpdate.setＫ５契約番号(ｋ５契約番号);
					chumonjohoMeisaiUpdate.setサービス申込番号(サービス申込番号);
					chumonjohoMeisaiUpdate.set連番(short001);
					chumonjohoMeisaiUpdate.set商品型ｉｄ(chumonjohoMeisai.get商品型ｉｄ());
					chumonjohoMeisaiUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
					chumonjohoMeisaiUpdate.set注文種別ｉｄ(chumonJoho.get注文種別ｉｄ());
					chumonjohoMeisaiUpdate.set数量(chumonjohoMeisai.get数量());
					chumonjohoMeisaiUpdate.set期間(chumonjohoMeisai.get期間());
					chumonjohoMeisaiUpdate.setＦｊ売値(chumonjohoMeisai.getＦｊ売値());
					chumonjohoMeisaiUpdate.setＦｊ単価(chumonjohoMeisai.getＦｊ単価());
					// Ｍ＿商品型のORACLE単価
					// 画面の仕切り率÷100
					chumonjohoMeisaiUpdate.set仕切り率(chumonjohoMeisai.get仕切り率().divide(new BigDecimal(100)));
					chumonjohoMeisaiUpdate.setＦｊ想定仕入値(chumonjohoMeisai.getＦｊ想定仕入値());
					chumonjohoMeisaiUpdate.set論理削除フラグ("0");
					chumonjohoMeisaiUpdate.set更新日時(new Date());
					chumonjohoMeisaiUpdate.set更新ユーザー("WEB_TEST01");
					ORAC0010Service.updateInsertChumonjohoMeisai(chumonjohoMeisaiUpdate);
				} else {
					String エラーメッセージ文言 = commonSecletService.selectMessagesText(エラーメッセージID);
					return "ORAC0010Form";
				}
			}

		}

		// 全部の新規登録完了メッセージ[I002]をダイアログ表示する。
		String エラーメッセージ文言 = commonSecletService.selectMessagesText("I002");
		return "ORAC0010Form";
	};

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/sonzaiCheck")
	public String sonzaiCheck(@ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Ｔ＿契約情報 keiyakuJoho = ORAC0010Form.getKeiyakuJoho();
		Ｔ＿契約情報 keiyakuJohoSelected = commonSecletService.selectByPrimaryKeyKeiyakuJoho(keiyakuJoho.getＫ５契約番号(),
				keiyakuJoho.getサービス申込番号());
		if (keiyakuJohoSelected != null) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			// String エラーメッセージ文言 =
			// commonSecletService.selectMessagesText("E005");
			out.print("<script language=\"javascript\">alert('エラーメッセージ文言');</script>");
		}
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);
		request.setAttribute("ORAC0010Form", ORAC0010Form);
		return "ORAC0010Form";
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/selectchumonList")
	public String selectchumonList(@ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form){
		String 料金プランID = ORAC0010Form.getKeiyakuJoho().get料金プランｉｄ();
		String 見積日 = ORAC0010Form.getChumonjoho().get見積日();
		見積日.replaceAll("/", "");
		String FJ料金表適用日 = ORAC0010Form.getChumonjoho().getＦｊ料金表適用日();
		String Oracle料金表適用日 = ORAC0010Form.getChumonjoho().getＯｒａｃｌｅ料金表適用日();

		List<Ｍ＿商品型> 商品型List;
		if(!FJ料金表適用日.isEmpty() && FJ料金表適用日.length() == 10){
			FJ料金表適用日.replaceAll("/", "");
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, FJ料金表適用日);
		}else{
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, 見積日);
		}

		if(!Oracle料金表適用日.isEmpty() && Oracle料金表適用日.length() == 10){
			Oracle料金表適用日.replaceAll("/", "");
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, Oracle料金表適用日);
		}else{
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, 見積日);
		}

		return "ORAC0010Form";
	}

	private List<Ｔ＿注文明細> set注文明細List(List<Ｔ＿注文明細> 注文明細List, List<Ｍ＿商品型> 商品型List){

		return 注文明細List;
	}
}
