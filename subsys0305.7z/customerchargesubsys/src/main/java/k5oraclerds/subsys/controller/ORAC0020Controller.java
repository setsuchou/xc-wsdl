package k5oraclerds.subsys.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.service.CommonSecletService;
import k5oraclerds.subsys.service.ORAC0020Service;
import k5oraclerds.subsys.webform.ORAC0020Form;
import k5oraclerds.subsys.webform.component.ORAC0020FormCondition;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

@Controller
@SessionAttributes("ORAC0020Form")
@RequestMapping(value = "/ORAC0020Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0020Controller {

	@Resource
	private ORAC0020Service ORAC0020Service;

	@Resource
	private CommonSecletService commonSecletService;

	private ORAC0020Form ORAC0020Form;

	@RequestMapping("/init")
	// @RequestMapping(value = "/init", produces = "text/html;charset=UTF-8")
	public String init(Model model, HttpServletResponse response) throws Exception {

		ORAC0020Form = new ORAC0020Form();

		// 画面フォームの初期化を行う
		initForm(ORAC0020Form);
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// PrintWriter out = response.getWriter();
		// out.append("<script>parent.alert('サブメニューへようこそ');</script>");
		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping("/searchByKeiyakuCondition")
	public String searchByChumonCondition(@ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, Model model)
			throws Exception {

		// 画面条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 画面明細部を取得する
		List<ORAC0020FormMeisai> meisaiList = ORAC0020Service.selectMeisaiByKeiyakuCondition(
				condition.getSabisuMoshikomiBango(), condition.getK5keiyakubango(), condition.getAidenteiteiDmein(),
				condition.getSabisushuryoBiFrom(), condition.getSabisushuryoBiTo());
		ORAC0020Form.setMeisaiList(meisaiList);
		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// PrintWriter out = response.getWriter();
		// out.append("<script>parent.alert('サブメニューへようこそ');</script>");
		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping("/searchByChomonCondition")
	public String searchByKeiyakuCondition(@ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, Model model)
			throws Exception {

		// 画面条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 画面明細部を取得する
		List<ORAC0020FormMeisai> meisaiList = ORAC0020Service.selectMeisaiByChumonCondition(
				condition.getSabisuMoshikomiBango(), condition.getK5keiyakubango(), condition.getRemban(),
				condition.getAidenteiteiDmein(), condition.getSabisushuryoBiFrom(), condition.getSabisushuryoBiTo(),
				condition.getTekiyokibobiFrom(), condition.getTekiyokibobiTo());
		ORAC0020Form.setMeisaiList(meisaiList);
		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// PrintWriter out = response.getWriter();
		// out.append("<script>parent.alert('サブメニューへようこそ');</script>");
		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	/**
	 * 画面初期化時、フォームインスタンスを生成する。
	 *
	 * @param ORAC0020Form
	 */
	private void initForm(ORAC0020Form ORAC0020Form) {

		// 契約情報を初期化する
		ORAC0020Form.setKeiyakuJoho(new Ｔ＿契約情報());

		// 注文情報を初期化する
		ORAC0020Form.setChumonJoho(new Ｔ＿注文情報());

		// 検索単位ラジオのデフォルト値を設定する
		ORAC0020Form.setTanyi("chumonTanyi");

		// // 契約情報を初期化する
		// List<Ｔ＿契約情報> keiyakuJohoList = new ArrayList<Ｔ＿契約情報>();
		// Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		// keiyakuJohoList.add(keiyakuJoho);
		// ORAC0020Form.setKeiyakuJohoList(keiyakuJohoList);
		//
		// // 注文情報を初期化する
		// List<Ｔ＿注文情報> chumonJohoList = new ArrayList<Ｔ＿注文情報>();
		// Ｔ＿注文情報 chumonjohoJoho = new Ｔ＿注文情報();
		// chumonJohoList.add(chumonjohoJoho);
		// ORAC0020Form.setChumonJohoList(chumonJohoList);

		// 画面条件を初期化する
		ORAC0020FormCondition condition = new ORAC0020FormCondition();

		// TODO 契約単位場合のテストデータ to delete
		Ｔ＿契約情報 keiyakuJoho = commonSecletService.selectByPrimaryKeyKeiyakuJoho("00001001", "000000000000001");
		condition.setK5keiyakubango(keiyakuJoho.getＫ５契約番号());
		condition.setSabisuMoshikomiBango(keiyakuJoho.getサービス申込番号());
		condition.setAidenteiteiDmein(keiyakuJoho.getアイデンティティドメイン());

		// TODO 注文単位場合のテストデータ to delete
		Ｔ＿注文情報 chumonJoho = commonSecletService.selectByPrimaryKeyChumonJoho("00001001", "000000000000001",
				new Short("001"));
		condition.setK5keiyakubango(chumonJoho.getＫ５契約番号());
		condition.setSabisuMoshikomiBango(chumonJoho.getサービス申込番号());
		condition.setAidenteiteiDmein(keiyakuJoho.getアイデンティティドメイン());
		condition.setRemban(chumonJoho.get連番());

		ORAC0020Form.setCondition(condition);

		// 画面明細を初期化する
		List<ORAC0020FormMeisai> meisaiList = new ArrayList<ORAC0020FormMeisai>();
		ORAC0020FormMeisai ORAC0020FormMeisai = new ORAC0020FormMeisai();
		meisaiList.add(ORAC0020FormMeisai);
		ORAC0020Form.setMeisaiList(meisaiList);

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0020Form);

		// TODO テストのため、この後に削除する
		// 契約情報テストデータを取得する
		// Ｔ＿契約情報 keiyakuJoho =
		// commonSecletService.selectByPrimaryKeyKeiyakuJoho("00001001",
		// "000000000000001");
		//
		// Ｔ＿注文情報 chumonjoho =
		// commonSecletService.selectByPrimaryKeyChumonJoho("00001001",
		// "000000000000001", new Short("1"));
		//
		// Ｔ＿注文情報 Ｔ＿注文情報 =
		// commonSecletService.selectByPrimaryKeyChumonjohoMeisai("00001001",
		// "000000000000001", new Short("1"),
		// "ORA0000101");
		// List<Ｔ＿注文情報> chumonjohoMeisaiList = new ArrayList<Ｔ＿注文情報>();
		// chumonjohoMeisaiList.add(Ｔ＿注文情報);
		//
		// ORAC0020Form.setKeiyakuJoho(keiyakuJoho);
		//
		// ORAC0020Form.setChumonjoho(chumonjoho);
		//
		// ORAC0020Form.setChumonjohoMeisaiList(chumonjohoMeisaiList);

		// 料金プラン、注文種別プルダウンリストの初期化を行う
		initPullDownList(ORAC0020Form);
	}

	/**
	 * ORAC0020画面上の料金プラン、注文種別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0020Form
	 */
	private void initPullDownList(ORAC0020Form ORAC0020Form) {

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = commonSecletService.selectAllShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		// 商品型が存在する場合、フォーム情報に設定する
		if (shohinGatas.size() > 0) {
			ORAC0020Form.setShohinGataMap(Collections.unmodifiableMap(shohinGatas));
		}

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = commonSecletService.selectAllRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0020Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuMap = commonSecletService.selectAllChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuMap) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}

		// 注文種別が存在する場合、フォーム情報に設定する
		if (chumonShubetsus.size() > 0) {
			ORAC0020Form.setChumonShubetsuMap(Collections.unmodifiableMap(chumonShubetsus));
		}
	}

}
