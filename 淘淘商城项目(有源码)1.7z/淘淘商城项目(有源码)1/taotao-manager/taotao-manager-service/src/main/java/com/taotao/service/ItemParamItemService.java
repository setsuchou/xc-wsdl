package com.taotao.service;

public interface ItemParamItemService {

	String getItemParamByItemId(Long itemId);
}
