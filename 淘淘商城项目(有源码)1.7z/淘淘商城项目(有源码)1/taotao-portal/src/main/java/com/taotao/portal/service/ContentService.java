package com.taotao.portal.service;

public interface ContentService {

	String getContentList();
}
