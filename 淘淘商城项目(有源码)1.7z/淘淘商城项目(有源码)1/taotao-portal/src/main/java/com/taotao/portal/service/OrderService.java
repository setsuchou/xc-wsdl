package com.taotao.portal.service;

import com.taotao.portal.pojo.Order;

public interface OrderService {

	String createOrder(Order order);
}
