package com.taotao.rest.service;

import com.taotao.rest.pojo.CatResult;

public interface ItemCatService {

	CatResult getItemCatList();
}
