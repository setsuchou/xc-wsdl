package com.youmeek.ssm.module.user.service;

import com.youmeek.ssm.module.user.pojo.SysUser;

public interface SysUserService {
	SysUser getById(Long id);
}
