package k5oraclerds.subsys.controller;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.CommonSecletService;
import k5oraclerds.subsys.service.ORAC0080Service;
import k5oraclerds.subsys.webform.ORAC0080Form;

@Controller
@RequestMapping(value = "/ORAC0080Form", method = {RequestMethod.GET, RequestMethod.POST})
public class ORAC0080Controller {

	@Resource
	private ORAC0080Service ORAC0080Service;

	@Resource
	private CommonSecletService commonSecletService;


	@RequestMapping("/init")
	public String init(@ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form, Model model) {

		// 遷移元[契約検索画面ORAC0020Form]からサービス申込番号、K5契約番号を引継ぎ
		Ｔ＿契約情報 keiyakuJohoForm;
		if (ORAC0080Form.getKeiyakuJoho() == null) {
			ORAC0080Form = new ORAC0080Form();
			// フォームの初期化を行う
			// 契約情報を初期化する
			keiyakuJohoForm = new Ｔ＿契約情報();

		} else {
			Ｔ＿契約情報 keiyakuJoho = ORAC0080Form.getKeiyakuJoho();
			keiyakuJohoForm = ORAC0080Service.selectKeiyakuJohoByPrimaryKey(keiyakuJoho.getＫ５契約番号(),
					keiyakuJoho.getサービス申込番号());
		}

		ORAC0080Form.setKeiyakuJoho(keiyakuJohoForm);
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0080Form);

		model.addAttribute("ORAC0080Form", ORAC0080Form);
		return "ORAC0080Form";
	}

	/**
	 * ORAC0080画面上の料金プラン別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0010Form
	 */
	private void initPullDownList(ORAC0080Form ORAC0080Form) {

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0080Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0080Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}
	}
}
