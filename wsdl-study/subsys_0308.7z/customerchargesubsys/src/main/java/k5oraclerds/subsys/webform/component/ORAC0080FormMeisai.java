package k5oraclerds.subsys.webform.component;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

public class ORAC0080FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;

	// チェックボックス
	private String strCheckbox;

	// 連番
	private Short remban;

	// 年月
	private String nengetu;

	// 商品型ＩＤ
	private String syohinkataId;

	// 商品型名
	private String shohinmei;

	// Oracle請求額／超過使用ユニット
	@DecimalMax(value = "999999999999", message = "入力値は最大值「{value}」より大きいです。")
	@DecimalMin(value = "0", message = "入力値は最大值「{value}」より小さいです。")
	private BigDecimal oracleSeikyugaku;

	// FJ単価
	private BigDecimal fjTanka;

	// FJ売値
	private BigDecimal fjUrine;

	// 超過使用料
	private BigDecimal tyoukasiyouryou;

	// 料金プラン名
	private String ryokimpuramMei;

	/**
	 * @return strCheckbox
	 */
	public String getStrCheckbox() {
		return strCheckbox;
	}

	/**
	 * @param strCheckbox
	 *            セットする strCheckbox
	 */
	public void setStrCheckbox(String strCheckbox) {
		this.strCheckbox = strCheckbox;
	}

	/**
	 * @return remban
	 */
	public Short getRemban() {
		return remban;
	}

	/**
	 * @param remban
	 *            セットする remban
	 */
	public void setRemban(Short remban) {
		this.remban = remban;
	}

	/**
	 * @return nengetu
	 */
	public String getNengetu() {
		return nengetu;
	}

	/**
	 * @param nengetu
	 *            セットする nengetu
	 */
	public void setNengetu(String nengetu) {
		this.nengetu = nengetu;
	}

	/**
	 * @return syohinkataId
	 */
	public String getSyohinkataId() {
		return syohinkataId;
	}

	/**
	 * @param syohinkataId
	 *            セットする syohinkataId
	 */
	public void setSyohinkataId(String syohinkataId) {
		this.syohinkataId = syohinkataId;
	}

	/**
	 * @return shohinmei
	 */
	public String getShohinmei() {
		return shohinmei;
	}

	/**
	 * @param shohinmei
	 *            セットする shohinmei
	 */
	public void setShohinmei(String shohinmei) {
		this.shohinmei = shohinmei;
	}

	/**
	 * @return oracleSeikyugaku
	 */
	public BigDecimal getOracleSeikyugaku() {
		return oracleSeikyugaku;
	}

	/**
	 * @param oracleSeikyugaku
	 *            セットする oracleSeikyugaku
	 */
	public void setOracleSeikyugaku(BigDecimal oracleSeikyugaku) {
		this.oracleSeikyugaku = oracleSeikyugaku;
	}

	/**
	 * @return fjTanka
	 */
	public BigDecimal getFjTanka() {
		return fjTanka;
	}

	/**
	 * @param fjTanka
	 *            セットする fjTanka
	 */
	public void setFjTanka(BigDecimal fjTanka) {
		this.fjTanka = fjTanka;
	}

	/**
	 * @return fjUrine
	 */
	public BigDecimal getFjUrine() {
		return fjUrine;
	}

	/**
	 * @param fjUrine
	 *            セットする fjUrine
	 */
	public void setFjUrine(BigDecimal fjUrine) {
		this.fjUrine = fjUrine;
	}

	/**
	 * @return tyoukasiyouryou
	 */
	public BigDecimal getTyoukasiyouryou() {
		return tyoukasiyouryou;
	}

	/**
	 * @param tyoukasiyouryou
	 *            セットする tyoukasiyouryou
	 */
	public void setTyoukasiyouryou(BigDecimal tyoukasiyouryou) {
		this.tyoukasiyouryou = tyoukasiyouryou;
	}

	/**
	 * @return ryokimpuramMei
	 */
	public String getRyokimpuramMei() {
		return ryokimpuramMei;
	}

	/**
	 * @param ryokimpuramMei
	 *            セットする ryokimpuramMei
	 */
	public void setRyokimpuramMei(String ryokimpuramMei) {
		this.ryokimpuramMei = ryokimpuramMei;
	}
}
