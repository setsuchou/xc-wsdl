package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿注文明細;

public class ORAC0060FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;
	// チェックボックス
	private boolean checkboxStatus;

	// 商品名
	private String shohinmei;

	// Ｔ＿注文明細
	@Valid
	private Ｔ＿注文明細 注文明細;

	//請求額チェック結果
	private String 請求額チェック結果;

	/**
	 * @return checkboxStatus
	 */
	public boolean isCheckboxStatus() {
		return checkboxStatus;
	}

	/**
	 * @param checkboxStatus
	 *            セットする checkboxStatus
	 */
	public void setCheckboxStatus(boolean checkboxStatus) {
		this.checkboxStatus = checkboxStatus;
	}

	/**
	 * @return the shohinmei
	 */
	public String getShohinmei() {
		return shohinmei;
	}

	/**
	 * @param shohinmei
	 *            the shohinmei to set
	 */
	public void setShohinmei(String shohinmei) {
		this.shohinmei = shohinmei;
	}

	/**
	 * @return the 注文明細
	 */
	public Ｔ＿注文明細 get注文明細() {
		return 注文明細;
	}

	/**
	 * @param 注文明細
	 *            the 注文明細 to set
	 */
	public void set注文明細(Ｔ＿注文明細 注文明細) {
		this.注文明細 = 注文明細;
	}

	public String get請求額チェック結果() {
		return 請求額チェック結果;
	}

	public void set請求額チェック結果(String 請求額チェック結果) {
		this.請求額チェック結果 = 請求額チェック結果;
	}

}
