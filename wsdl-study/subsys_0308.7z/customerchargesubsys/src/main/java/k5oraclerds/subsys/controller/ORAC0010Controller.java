package k5oraclerds.subsys.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.common.Global;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.service.CommonSecletService;
import k5oraclerds.subsys.service.ORAC0010Service;
import k5oraclerds.subsys.webform.ORAC0010Form;
import k5oraclerds.subsys.webform.component.ORAC0010FormMeisai;

@Controller
@RequestMapping(value = "/ORAC0010Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0010Controller {

	@Resource
	private ORAC0010Service ORAC0010Service;

	@Resource
	private CommonSecletService commonSecletService;

	@RequestMapping("/init")
	public String init(Model model) {
		ORAC0010Form ORAC0010Form = new ORAC0010Form();

		// 画面フォームの初期化を行う
		initForm(ORAC0010Form);
		model.addAttribute("ORAC0010Form", ORAC0010Form);

		// ORAC0010画面へ遷移する
		return "ORAC0010Form";
	}

	/**
	 * 画面初期化時、フォームインスタンスを生成する。
	 *
	 * @param ORAC0010Form
	 */

	/**
	 *
	 * @return
	 */
	@RequestMapping("/insert")
	public String insert(@Valid @ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form, BindingResult result
			,Map<String, Object> map) {
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);

		if (result.hasErrors()) {
			return "ORAC0010Form";
		}

		if(!compositeCheck(ORAC0010Form, map)){
			return "ORAC0010Form";
		}

		List<String> errMsgList = new ArrayList<String>();

		String ｋ５契約番号;
		String サービス申込番号;
		String エラーメッセージID = "E005";
		// Ｔ＿契約情報の登録する
		Ｔ＿契約情報 keiyakuJoho = ORAC0010Form.getKeiyakuJoho();
		ｋ５契約番号 = keiyakuJoho.getＫ５契約番号();
		サービス申込番号 = keiyakuJoho.getサービス申込番号();
		boolean 論理削除フラグ判断 = commonSecletService.契約情報論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号);
		if (論理削除フラグ判断) {
			Ｔ＿契約情報 keiyakuJohoUpdate = new Ｔ＿契約情報();
			keiyakuJohoUpdate.setＫ５契約番号(ｋ５契約番号);
			keiyakuJohoUpdate.setサービス申込番号(サービス申込番号);
			keiyakuJohoUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
			keiyakuJohoUpdate.setオーダーｎｏ(keiyakuJoho.getオーダーｎｏ());
			keiyakuJohoUpdate.set論理削除フラグ("0");
			keiyakuJohoUpdate.set登録ユーザー("WEB_TEST01");
			keiyakuJohoUpdate.set更新日時(new Date());
			keiyakuJohoUpdate.set更新ユーザー("WEB_TEST01");
			ORAC0010Service.updateInsertKeiyakuJoho(keiyakuJohoUpdate);
		} else {
			// エラーメッセージ[E005]をダイアログ表示し、OKボタン押下後は、新規登録ボタン押下前の状態に戻る。
			String strErrorMessage = Global.getMsg(エラーメッセージID);
			errMsgList.add(strErrorMessage);
			map.put("Message", errMsgList);
			map.put("MessageCode", エラーメッセージID);
			return "ORAC0010Form";
		}

		// Ｔ＿注文情報の登録する
		Ｔ＿注文情報 chumonJoho = ORAC0010Form.getChumonjoho();
		Short short001 = new Short("001");
		論理削除フラグ判断 = commonSecletService.注文情報論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号, short001);
		if (論理削除フラグ判断) {
			Ｔ＿注文情報 chumonJohoUpdate = new Ｔ＿注文情報();
			chumonJohoUpdate.setＫ５契約番号(ｋ５契約番号);
			chumonJohoUpdate.setサービス申込番号(サービス申込番号);
			chumonJohoUpdate.set連番(short001);
			chumonJohoUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
			chumonJohoUpdate.set注文種別ｉｄ(chumonJoho.get注文種別ｉｄ());
			chumonJohoUpdate.set見積日(dateReplace(chumonJoho.get見積日()));
			// chumonJohoUpdate;//画面のFJ単価適用日
			chumonJohoUpdate.setＦｊ料金表適用日(dateReplace(chumonJoho.getＦｊ料金表適用日()));
			// chumonJohoUpdate;//画面のOracle単価適用日
			chumonJohoUpdate.setＯｒａｃｌｅ料金表適用日(dateReplace(chumonJoho.getＯｒａｃｌｅ料金表適用日()));
			chumonJohoUpdate.set適用開始希望日(dateReplace(chumonJoho.get適用開始希望日()));
			chumonJohoUpdate.set特別値引フラグ(chumonJoho.get特別値引フラグ());
			chumonJohoUpdate.setＰａａｓ連携済フラグ("0");
			chumonJohoUpdate.set請求依頼抽出済フラグ("0");
			chumonJohoUpdate.set論理削除フラグ("0");
			chumonJohoUpdate.set登録ユーザー("WEB_TEST01");
			chumonJohoUpdate.set更新日時(new Date());
			chumonJohoUpdate.set更新ユーザー("WEB_TEST01");
			ORAC0010Service.updateInsertChumonjoho(chumonJohoUpdate);
		} else {
			// エラーメッセージ[E005]をダイアログ表示し、OKボタン押下後は、新規登録ボタン押下前の状態に戻る。
			String strErrorMessage = Global.getMsg(エラーメッセージID);
			errMsgList.add(strErrorMessage);
			map.put("Message", errMsgList);
			map.put("MessageCode", エラーメッセージID);
			return "ORAC0010Form";
		}

		// Ｔ＿注文明細の登録する
		List<ORAC0010FormMeisai> chumonjohoMeisaiList = ORAC0010Form.getChumonjohoMeisaiList();
		// List<Ｔ＿注文明細> chumonjohoMeisaiSelectedList =
		// commonSecletService.selectByPrimaryKeyChumonjohoMeisai(ｋ５契約番号,
		// サービス申込番号);
		List<ORAC0010FormMeisai> chumonjohoMeisaiCheckedList = new ArrayList<ORAC0010FormMeisai>();

		for(ORAC0010FormMeisai chumonjohoMeisai : chumonjohoMeisaiList){
			//if(chumonjohoMeisai.getStrCheckbox()){
			//数量が１以上の商品のみ登録する。　（ゼロ、または、空白の場合は登録しない。）
			if(chumonjohoMeisai.get注文明細().get数量() != null &&
					chumonjohoMeisai.get注文明細().get数量().compareTo(BigDecimal.ONE) >= 0){
				chumonjohoMeisaiCheckedList.add(chumonjohoMeisai);
			}
		}

		if (chumonjohoMeisaiCheckedList != null && chumonjohoMeisaiCheckedList.size() != 0) {
			for (ORAC0010FormMeisai chumonjohoMeisai : chumonjohoMeisaiCheckedList) {
				Ｔ＿注文明細 注文明細 = chumonjohoMeisai.get注文明細();
				論理削除フラグ判断 = commonSecletService.注文明細論理削除フラグ判断ByKey(ｋ５契約番号, サービス申込番号, short001,
						注文明細.get商品型ｉｄ());
				if (論理削除フラグ判断) {
					Ｔ＿注文明細 chumonjohoMeisaiUpdate = new Ｔ＿注文明細();
					chumonjohoMeisaiUpdate.setＫ５契約番号(ｋ５契約番号);
					chumonjohoMeisaiUpdate.setサービス申込番号(サービス申込番号);
					chumonjohoMeisaiUpdate.set連番(short001);
					chumonjohoMeisaiUpdate.set商品型ｉｄ(注文明細.get商品型ｉｄ());
					chumonjohoMeisaiUpdate.set料金プランｉｄ(keiyakuJoho.get料金プランｉｄ());
					chumonjohoMeisaiUpdate.set注文種別ｉｄ(chumonJoho.get注文種別ｉｄ());
					chumonjohoMeisaiUpdate.set数量(注文明細.get数量());
					chumonjohoMeisaiUpdate.set期間(注文明細.get期間());
					chumonjohoMeisaiUpdate.setＦｊ売値(注文明細.getＦｊ売値());
					chumonjohoMeisaiUpdate.setＦｊ単価(注文明細.getＦｊ単価());
					// Ｍ＿商品型のORACLE単価
					chumonjohoMeisaiUpdate.setＯｒａｃｌｅ単価(注文明細.getＯｒａｃｌｅ単価());
					// 画面の仕切り率÷100
					chumonjohoMeisaiUpdate.set仕切り率(注文明細.get仕切り率().divide(new BigDecimal(100)));
					chumonjohoMeisaiUpdate.setＦｊ想定仕入値(注文明細.getＦｊ想定仕入値());
					chumonjohoMeisaiUpdate.set論理削除フラグ("0");
					chumonjohoMeisaiUpdate.set登録ユーザー("WEB_TEST01");
					chumonjohoMeisaiUpdate.set更新日時(new Date());
					chumonjohoMeisaiUpdate.set更新ユーザー("WEB_TEST01");
					ORAC0010Service.updateInsertChumonjohoMeisai(chumonjohoMeisaiUpdate);
				} else {
					String strErrorMessage = Global.getMsg(エラーメッセージID);
					errMsgList.add(strErrorMessage);
					map.put("Message", errMsgList);
					map.put("MessageCode", エラーメッセージID);
					return "ORAC0010Form";
				}
			}

		}

		// 全部の新規登録完了メッセージ[I002]をダイアログ表示する。
		//String エラーメッセージ文言 = commonSecletService.selectMessagesText("I002");
		String msgShinkinKanryo = Global.getMsg("I002");;
		List<String> msgList = new ArrayList<String>();
		msgList.add(msgShinkinKanryo);
		map.put("Message", msgShinkinKanryo);
		map.put("MessageCode", "I002");
		return "ORAC0010Form";
	};

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/sonzaiCheck")
	public String sonzaiCheck(@ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form, HttpServletRequest request,
			HttpServletResponse response ,Map<String, Object> map) throws Exception {
		Ｔ＿契約情報 keiyakuJoho = ORAC0010Form.getKeiyakuJoho();
		Ｔ＿契約情報 keiyakuJohoSelected = commonSecletService.selectByPrimaryKeyKeiyakuJoho(keiyakuJoho.getＫ５契約番号(),
				keiyakuJoho.getサービス申込番号());
		if (keiyakuJohoSelected != null) {
			List<String> errMsgList = new ArrayList<String>();
			String strErrorMessage = Global.getMsg("E005");
			errMsgList.add(strErrorMessage);
			map.put("Message", errMsgList);
			map.put("MessageCode", "E005");
		}
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);
		request.setAttribute("ORAC0010Form", ORAC0010Form);
		return "ORAC0010Form";
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/selectchumonList")
	public String selectchumonList(@ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form,Model model){
		String 料金プランID = ORAC0010Form.getKeiyakuJoho().get料金プランｉｄ();
		String 見積日 = ORAC0010Form.getChumonjoho().get見積日();
		見積日 = dateReplace(見積日);
		String FJ料金表適用日 = ORAC0010Form.getChumonjoho().getＦｊ料金表適用日();
		String Oracle料金表適用日 = ORAC0010Form.getChumonjoho().getＯｒａｃｌｅ料金表適用日();

		List<ORAC0010FormMeisai>  注文明細List = new ArrayList<ORAC0010FormMeisai>();
		List<Ｍ＿商品型> 商品型List;
		if(!FJ料金表適用日.isEmpty() && FJ料金表適用日.length() == 10){
			FJ料金表適用日 = dateReplace(FJ料金表適用日);
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, FJ料金表適用日);
		}else{
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, 見積日);
		}

		set注文明細List(注文明細List,商品型List);

		if(!Oracle料金表適用日.isEmpty() && Oracle料金表適用日.length() == 10){
			Oracle料金表適用日 = dateReplace(Oracle料金表適用日);
			商品型List = commonSecletService.selectShohinGataForChumonmesai(料金プランID, Oracle料金表適用日);
		}

		set注文明細List(注文明細List,商品型List);

		ORAC0010Form.setChumonjohoMeisaiList(注文明細List);
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);
		model.addAttribute("ORAC0010Form", ORAC0010Form);
		return "ORAC0010Form";
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/clearchumonList")
	public String clearchumonList(@ModelAttribute("ORAC0010Form") ORAC0010Form ORAC0010Form,Model model){

		List<ORAC0010FormMeisai>  注文明細List = new ArrayList<ORAC0010FormMeisai>();
		ORAC0010Form.setChumonjohoMeisaiList(注文明細List);
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);
		model.addAttribute("ORAC0010Form", ORAC0010Form);
		return "ORAC0010Form";
	}

	private void initForm(ORAC0010Form ORAC0010Form) {

		// 契約情報を初期化する
		ORAC0010Form.setKeiyakuJoho(new Ｔ＿契約情報());

		// 注文情報を初期化する
		ORAC0010Form.setChumonjoho(new Ｔ＿注文情報());

		// 注文明細を初期化する
//		List<ORAC0010FormChumonMeisai> chumonjohoMesaiList = new ArrayList<ORAC0010FormChumonMeisai>();
//		Ｔ＿注文明細 注文明細 = new Ｔ＿注文明細();
//		注文明細.setＦｊ単価(new BigDecimal("1000"));
//		ORAC0010FormChumonMeisai chumonjohoMesai = new ORAC0010FormChumonMeisai();
//		chumonjohoMesai.setStrCheckbox(true);
//		chumonjohoMesaiList.add(chumonjohoMesai);
//		ORAC0010Form.setChumonjohoMeisaiList(chumonjohoMesaiList);

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0010Form);

	}

	/**
	 * ORAC0010画面上の料金プラン、注文種別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0010Form
	 */
	private void initPullDownList(ORAC0010Form ORAC0010Form) {

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = ORAC0010Service.getShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		// 商品型が存在する場合、フォーム情報に設定する
		if (shohinGatas.size() > 0) {
			ORAC0010Form.setShohinGataMap(Collections.unmodifiableMap(shohinGatas));
		}

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0010Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0010Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuMap = ORAC0010Service.getChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuMap) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}

		// 注文種別が存在する場合、フォーム情報に設定する
		if (chumonShubetsus.size() > 0) {
			ORAC0010Form.setChumonShubetsuMap(Collections.unmodifiableMap(chumonShubetsus));
		}
	}

	private Boolean compositeCheck(ORAC0010Form ORAC0010Form, Map<String, Object> map) {
		List<String> errMsgList = new ArrayList<String>();

		List<ORAC0010FormMeisai> chumonjohoMeisaiList = ORAC0010Form.getChumonjohoMeisaiList();
		BigDecimal suryoSum = BigDecimal.ZERO;
		for(ORAC0010FormMeisai chumonjohoMeisai : chumonjohoMeisaiList){
			if(chumonjohoMeisai.get注文明細().get数量() != null){
				suryoSum = suryoSum.add(chumonjohoMeisai.get注文明細().get数量());
			}
		}
		if(suryoSum.compareTo(BigDecimal.ZERO) <= 0){
			String strErrorMessage = Global.getMsg("E004");
			errMsgList.add(strErrorMessage);
		}

		Ｔ＿注文情報 chumonJoho = ORAC0010Form.getChumonjoho();
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date nowDate = new Date();
		int intNowDate = Integer.parseInt(format.format(nowDate));
		int int見積日 = Integer.parseInt(dateReplace(chumonJoho.get見積日()));
		if(int見積日 > intNowDate){
			String strErrorMessage = Global.getMsg("E012");
			errMsgList.add(strErrorMessage);
		}

		String FJ料金表適用日 = chumonJoho.getＦｊ料金表適用日();
		String Oracle料金表適用日 = chumonJoho.getＯｒａｃｌｅ料金表適用日();

		if(FJ料金表適用日.length() == 0 && Oracle料金表適用日.length() > 0){
			String strErrorMessage = Global.getMsg("E025");
			errMsgList.add(strErrorMessage);
		}else if(FJ料金表適用日.length() > 0 && Oracle料金表適用日.length() == 0){
			String strErrorMessage = Global.getMsg("E025");
			errMsgList.add(strErrorMessage);
		}

		if(errMsgList.size() > 0){
			map.put("ErrorMessage", errMsgList);
			//model.addAttribute("ORAC0010Form", ORAC0010Form);
			return false;
		}

		return true;
	}

	private List<ORAC0010FormMeisai> set注文明細List(List<ORAC0010FormMeisai> 注文明細List, List<Ｍ＿商品型> 商品型List){
		BigDecimal DECIMAL100 = new BigDecimal(100);
		for(Ｍ＿商品型 商品型 : 商品型List){
			Ｔ＿注文明細 注文明細 = new Ｔ＿注文明細();
			注文明細.setＦｊ単価(商品型.getＦｊ単価());
			注文明細.set仕切り率(商品型.get仕切り率().multiply(DECIMAL100));
			注文明細.set商品型ｉｄ(商品型.get商品型ｉｄ());
			注文明細.setＯｒａｃｌｅ単価(商品型.getＯｒａｃｌｅ単価());
			ORAC0010FormMeisai chumonMeisai = new ORAC0010FormMeisai();
			chumonMeisai.set注文明細(注文明細);
//			if(料金プラン.equals("01")){
//				BigDecimal FJ想定仕入値 =
//			}else if(料金プラン.equals("02")){
//
//			}
			chumonMeisai.setShohinmei(商品型.get商品型名());
			注文明細List.add(chumonMeisai);
		}
		return 注文明細List;
	}

	private String dateReplace(String strDate){
		if(strDate == null){
			return strDate;
		}
		return strDate.replaceAll("/", "");
	}

}
