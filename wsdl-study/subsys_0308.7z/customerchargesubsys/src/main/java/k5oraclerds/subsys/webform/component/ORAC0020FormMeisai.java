package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

public class ORAC0020FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;


	// チェックボックス
	private Boolean checkboxStatus;

	// サービス申込番号
	private String sabisuMoshikomiBango;

	// Ｔ＿契約情報から取得する
	// ｋ５契約番号
	private String k5KeiyakuBango;

	// 連番
	private Short remban;

	// Ｔ＿契約情報から取得する
	// アイデンティティドメイン
	private String aidenteiteiDomein;

	// 料金プランｉｄ
	private String ryokimPuranId;

	// 料金プラン名
	private String ryokimPuramMei;

	// Ｔ＿契約情報から取得する
	// サービス開始日
	private String sabisuKaishibi;

	// サービス終了日
	private String sabisuShuryobi;

	// 注文種別ｉｄ
	private String chumonShubetsuId;

	// 契約単位の場合： 空白で表示
	// 注文単位の場合： Ｍ＿注文種別の注文種別名を注文種別ｉｄキーで取得し表示する。
	// 注文種別名
	private String chumonShubetsuMei;

	// 契約単位の場合： 空白で表示
	// 注文単位の場合： yyyy/mm/dd 形式で表示
	// 適用開始希望日
	private String tekiyoKaishiKibobi;

	/**
	 * @return checkboxStatus
	 */
	public Boolean getCheckboxStatus() {
		return checkboxStatus;
	}

	/**
	 * @param checkboxStatus セットする checkboxStatus
	 */
	public void setCheckboxStatus(Boolean checkboxStatus) {
		this.checkboxStatus = checkboxStatus;
	}

	/**
	 * @return the k5KeiyakuBango
	 */
	public String getK5KeiyakuBango() {
		return k5KeiyakuBango;
	}

	/**
	 * @param k5KeiyakuBango
	 *            the k5KeiyakuBango to set
	 */
	public void setK5KeiyakuBango(String k5KeiyakuBango) {
		this.k5KeiyakuBango = k5KeiyakuBango;
	}

	/**
	 * @return the sabisuMoshikomiBango
	 */
	public String getSabisuMoshikomiBango() {
		return sabisuMoshikomiBango;
	}

	/**
	 * @param sabisuMoshikomiBango
	 *            the sabisuMoshikomiBango to set
	 */
	public void setSabisuMoshikomiBango(String sabisuMoshikomiBango) {
		this.sabisuMoshikomiBango = sabisuMoshikomiBango;
	}

	/**
	 * @return the remban
	 */
	public Short getRemban() {
		return remban;
	}

	/**
	 * @param remban
	 *            the remban to set
	 */
	public void setRemban(Short remban) {
		this.remban = remban;
	}

	/**
	 * @return the aidenteiteiDomein
	 */
	public String getAidenteiteiDomein() {
		return aidenteiteiDomein;
	}

	/**
	 * @param aidenteiteiDomein
	 *            the aidenteiteiDomein to set
	 */
	public void setAidenteiteiDomein(String aidenteiteiDomein) {
		this.aidenteiteiDomein = aidenteiteiDomein;
	}

	/**
	 * @return chumonShubetsuMei
	 */
	public String getChumonShubetsuMei() {
		return chumonShubetsuMei;
	}

	/**
	 * @param chumonShubetsuMei
	 *            セットする chumonShubetsuMei
	 */
	public void setChumonShubetsuMei(String chumonShubetsuMei) {
		this.chumonShubetsuMei = chumonShubetsuMei;
	}

	/**
	 * @return the tekiyoKaishiKibobi
	 */
	public String getTekiyoKaishiKibobi() {
		return tekiyoKaishiKibobi;
	}

	/**
	 * @param tekiyoKaishiKibobi
	 *            the tekiyoKaishiKibobi to set
	 */
	public void setTekiyoKaishiKibobi(String tekiyoKaishiKibobi) {
		this.tekiyoKaishiKibobi = tekiyoKaishiKibobi;
	}

	/**
	 * @return the sabisuKaishibi
	 */
	public String getSabisuKaishibi() {
		return sabisuKaishibi;
	}

	/**
	 * @param sabisuKaishibi
	 *            the sabisuKaishibi to set
	 */
	public void setSabisuKaishibi(String sabisuKaishibi) {
		this.sabisuKaishibi = sabisuKaishibi;
	}

	/**
	 * @return ryokimPuranId
	 */
	public String getRyokimPuranId() {
		return ryokimPuranId;
	}

	/**
	 * @param ryokimPuranId
	 *            セットする ryokimPuranId
	 */
	public void setRyokimPuranId(String ryokimPuranId) {
		this.ryokimPuranId = ryokimPuranId;
	}

	/**
	 * @return ryokimPuramMei
	 */
	public String getRyokimPuramMei() {
		return ryokimPuramMei;
	}

	/**
	 * @param ryokimPuramMei
	 *            セットする ryokimPuramMei
	 */
	public void setRyokimPuramMei(String ryokimPuramMei) {
		this.ryokimPuramMei = ryokimPuramMei;
	}

	/**
	 * @return sabisuShuryobi
	 */
	public String getSabisuShuryobi() {
		return sabisuShuryobi;
	}

	/**
	 * @param sabisuShuryobi
	 *            セットする sabisuShuryobi
	 */
	public void setSabisuShuryobi(String sabisuShuryobi) {
		this.sabisuShuryobi = sabisuShuryobi;
	}

	/**
	 * @return chumonShubetsuId
	 */
	public String getChumonShubetsuId() {
		return chumonShubetsuId;
	}

	/**
	 * @param chumonShubetsuId
	 *            セットする chumonShubetsuId
	 */
	public void setChumonShubetsuId(String chumonShubetsuId) {
		this.chumonShubetsuId = chumonShubetsuId;
	}

}
