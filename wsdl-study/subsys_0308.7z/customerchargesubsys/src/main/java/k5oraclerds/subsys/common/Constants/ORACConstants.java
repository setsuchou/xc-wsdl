package k5oraclerds.subsys.common.Constants;

/**
 *
 * 定数を定義するクラス
 *
 * @author setsuchou
 *
 *
 */
public final class ORACConstants {

	/**
	 * 論理削除フラグ（0：削除しない；1：削除；）
	 */
	public static final String DEL_FLAG_NORMAL = "0";
	public static final String DEL_FLAG_DELETE = "1";

	/**
	 * 注文種別
	 */
	public static final String ORDER_TYPE_NEW = "New";

	/**
	 * 料金プラン
	 */
	public static final String RATE_PLAN_METERED_ID = "01";
	public static final String RATE_PLAN_NON_METERED_ID = "02";

	/**
	 * 契約情報検索画面[ORAC0020Form]の検索単位
	 */
	public static final String ORAC0020FORM_SEARCH_CHUMON_TANYI = "chumonTanyi";
	public static final String ORAC0020FORM_SEARCH_KEIYAKU_TANYI = "keiyakuTanyi";
	/**
	 * 契約検索画面ボタン種類
	 */

	public static final String ORDER_SERACH＿PAGE＿BUTTON_NAME_DELETE = "delete";

}
