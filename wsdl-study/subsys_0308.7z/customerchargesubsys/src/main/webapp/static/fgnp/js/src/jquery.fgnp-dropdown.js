/*
 * jquery.fgnp-dropdown.js v1.3.2
 *=============================================================================================================*/

/*!
 * Copyright (c) 2009 - 2013 Erik van den Berg (http://www.tweego.nl/jeegoocontext)
 * Licensed under MIT (http://www.opensource.org/licenses/mit-license.php) license.
 * Consider linking back to author's homepage: http://www.tweego.nl
 *
 * Contributors:
 * Denis Evteev
 * Roman Imankulov (www.netangels.ru)
 * Julian Verdurmen
 *
 * Version: 2.0
 * Requires jQuery 1.4.2+
 */

(function($){
    var _global;
    var _menus;
    var lastDirection = 0; // 1-right, 2-left, 0-undefined

    var _overflow = function(x, y){
        var windowHeight = window.innerHeight ? window.innerHeight : $(window).height();
        return {
            width : x - $(window).width() - $(window).scrollLeft(),
            height : y - windowHeight - $(window).scrollTop()
        };
    };

    var _clearActive = function(){
        for(cm in _menus)
        {
            $(_menus[cm].allContext).removeClass(_global.activeClass);

        }
    };

    var _resetMenu = function(){
        if(_global.activeId)$(_global.activeId).add(_global.activeId + ' ul').fadeOut(_global.activeId.delay / 2);
        if(_menus[_global.activeId])_menus[_global.activeId].currentHover = null;
        _global.activeId = null;
        $(document).unbind('.fgnp-dropdown');
        $(window).unbind('resize.fgnp-dropdown');
        $(document).off("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown scroll.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown");
        $("iframe").contents().off("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown mousedown.fgnp-dropdown touchmove.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown", _globalHide);
        $('ul.fgnp-dropdown').off("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown mousedown.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown");
        lastDirection = 0;
    };

    var _globalHide = function(e){
        if(_global.activeId && _menus[_global.activeId].onHide)
        {
            if(_menus[_global.activeId].onHide.apply($(_global.activeId), [e, _menus[_global.activeId].context]) === false)
            {
                return false;
            }
        }
        _clearActive();
        _resetMenu();
    };

    $.fn.fgnpDropdown = function(id, options){

        if(!_global) _global = {};
        if(!_menus) _menus = {};

        if(options && options.menuClass)_global.menuClass = options.menuClass;
        if(!_global.menuClass)_global.menuClass = 'fgnp-dropdown';
        if(options && options.activeClass)_global.activeClass = options.activeClass;
        if(!_global.activeClass)_global.activeClass = 'fgnp-active';

   	    if(_menus[id]) return;

	    _menus[id] = $.extend({
            submenuClass: 'submenu',
            separatorClass: 'separator',
            operaEvent: 'ctrl+click',
            wrapper: 'body',
            fadeIn: 200,
            delay: 150,
            keyDelay: 100,
            widthOverflowOffset: 0,
            heightOverflowOffset: 0,
            submenuLeftOffset: 0,
            submenuTopOffset: 0,
            autoAddSubmenuArrows: true,
            startLeftOffset: 0,
            startTopOffset: 0,
            keyboard: true,
            event: 'click'
        }, options || {});

        _menus[id].allContext = this.selector;

        $(id).delegate('li', 'mouseover.fgnp-dropdown', function(e) {
            var $this = _menus[id].currentHover = $(this);
            clearTimeout(_menus[id].show);
            clearTimeout(_menus[id].hide);
            var $parents = $this.parents('li');
            $this.add($this.find('> *')).add($parents).add($parents.find('> *'));
            var continueDefault = true;
            if(_menus[id].onHover) {
                if(_menus[id].onHover.apply(this, [e, _menus[id].context]) === false)continueDefault = false;
            }

        if($('body').hasClass('fgnp-device-mobile')){ // just for testing mobile functionality on desktop
            if(e.isTrigger === undefined) {
                return;
            }
        }
        $this.parent().find('ul').not($this.find('> ul')).parent().removeClass('fgnp-current');

        if(!_menus[id].proceed) {
            _menus[id].show = setTimeout(function(){
                _menus[id].proceed = true;
                $this.mouseover();
            }, _menus[id].delay);

            return false;
        }

        _menus[id].proceed = false;
        $this.parent().find('ul').not($this.find('> ul')).hide();

        if(!continueDefault) {
            e.preventDefault();
            return false;
        }

        var $submenu = $this.find('> ul');
        if($submenu.length !== 0) {
            var offSet = $this.offset();
            var overflow = _overflow(
                (offSet.left + $this.parent().outerWidth() + _menus[id].submenuLeftOffset + $submenu.outerWidth() + _menus[id].widthOverflowOffset),
                (offSet.top + _menus[id].submenuTopOffset + $submenu.outerHeight() + _menus[id].heightOverflowOffset)
            );
            var parentWidth = $submenu.parent().parent().outerWidth();
            //var y = offSet.top - $this.parent().offset().top - ($this.parent().outerHeight() - $this.parent().innerHeight());
            var y = 0;
            var parentZindex = parseInt($submenu.parent().parent().css('z-index'), 10);
            var rootLeft = - $this.offset().left;
            if(lastDirection === 2){
                var left = -parentWidth - _menus[id].submenuLeftOffset;
                if(left < rootLeft) left = parentWidth + _menus[id].submenuLeftOffset;
                $submenu.css({
                    'left': left + 'px',
                    'top': (overflow.height > 0 && !_menus[id].ignoreHeightOverflow) ? (y - overflow.height + _menus[id].submenuTopOffset) + 'px' : y + _menus[id].submenuTopOffset + 'px',
                    'z-index': parentZindex + 1,
                });
            } else {
                var left = parentWidth + _menus[id].submenuLeftOffset;
                if (overflow.width > 0 && !_menus[id].ignoreWidthOverflow) left = - parentWidth - _menus[id].submenuLeftOffset;
                if(left < rootLeft) left = rootLeft;
                $submenu.css({
                    'left': left + 'px',
                    'top': (overflow.height > 0 && !_menus[id].ignoreHeightOverflow) ? (y - overflow.height + _menus[id].submenuTopOffset) + 'px' : y + _menus[id].submenuTopOffset + 'px',
                    'z-index': parentZindex + 1,
                });
            }

            lastDirection = (overflow.width <= 0) ? 1 : 2;
            $submenu.parent().addClass('fgnp-current');
            $submenu.fadeIn(_menus[id].fadeIn);
        }

        e.stopPropagation();

    }).delegate('li', 'click.fgnp-dropdown', function(e) {
        if(_menus[id].onSelect) {
            if(_menus[id].onSelect.apply(this, [e, _menus[id].context]) === false) {
                return false;
            }
        }

        if($('body').hasClass('fgnp-device-mobile') || $('body').hasClass('fgnp-device-tablet')){
            if($(this).hasClass('fgnp-dropdown-link')){
                e.stopPropagation();
                e.preventDefault();
                $(this).mouseover();
            } else {
                if($('body').find('.b-modal').length > 0){
                    $('body').find('.b-modal').click();
                }
                _resetMenu();
                $(_menus[id].context).removeClass(_global.activeClass);
                e.stopPropagation();
            }
        } else {
            if($(this).hasClass('fgnp-dropdown-link')){
                e.stopPropagation();
                e.preventDefault();
                $(this).mouseover();
            } else {
                _resetMenu();
                $(_menus[id].context).removeClass(_global.activeClass);
                e.stopPropagation();
            }
        }
    });

	var div = document.createElement('div');
        div.setAttribute('oncontextmenu', '');
        var eventType = "click.fgnp-dropdown";

        return $(_menus[id].wrapper).delegate(_menus[id].allContext, eventType, function(e) {
	    if (typeof _menus[id].modifier === 'string' && !e[_menus[id].modifier]) return;
        _menus[id].context = this;
        var $menu = $(id);
        var startLeft, startTop;
	    var contextOffset = $(this).offset();
	    startLeft = contextOffset.left;
        startTop = contextOffset.top + $(this).outerHeight();
        startLeft += _menus[id].startLeftOffset;
        startTop += _menus[id].startTopOffset;
	    var menuWidth = $menu.actual('outerWidth');
	    var menuHeight = $menu.actual('outerHeight');

        var overflow = _overflow((startLeft + menuWidth + _menus[id].widthOverflowOffset), (startTop + menuHeight + _menus[id].heightOverflowOffset));
        if(!_menus[id].ignoreWidthOverflow && overflow.width > 0) startLeft -= overflow.width;
//        if(!_menus[id].openBelowContext && !_menus[id].ignoreHeightOverflow && overflow.height > 0) {
//            startTop -= overflow.height;
//        }

        // http://bugs.jquery.com/ticket/6724
        var windowHeight = window.innerHeight ? window.innerHeight : $(window).height();
	    if(contextOffset.top + $menu.outerHeight() + $(this).outerHeight() > $(window).scrollTop() + windowHeight) {
		    startTop = contextOffset.top - menuHeight;
	    }

        if(_menus[id].onShow) {
            if(_menus[id].onShow.apply($menu, [e, _menus[id].context, startLeft, startTop]) === false) {
                return false;
            }
        }

        _resetMenu();
        _global.activeId = id;
        $(_global.activeId).add(_global.activeId + ' ul').hide();
        _clearActive();
        $(_menus[id].context).addClass(_global.activeClass);
        $menu.find('li').removeClass('fgnp-current');
        if(_menus[id].autoAddSubmenuArrows) {
            $menu.find('li:has(ul)').not(':has(span.' + _menus[id].submenuClass + ')').prepend('<span class="' + _menus[id].submenuClass + '"></span>');
            $menu.find('li').not(':has(ul)').find('> span.' + _menus[id].submenuClass).remove();
        }

        $menu.appendTo('body');

	    if($('body').hasClass('fgnp-device-mobile')){
            $menu.css({
                'left': startLeft + 'px',
                'top':  startTop + 'px'
            }).fadeIn(_menus[id].fadeIn);
	    } else {
            $menu.css({
                'left': startLeft + 'px',
                'top':  startTop + 'px' ,
                'position': "absolute"
            }).fadeIn(_menus[id].fadeIn);
	    }

	    $(window).bind('resize.fgnp-dropdown', function(){
		    _globalHide();
	    });

	    $('ul.fgnp-dropdown').on("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown mousedown.fgnp-dropdown touchmove.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown", function(e){
            if($(this).scrollTop() === 0){
                if(e.originalEvent.wheelDelta / 120 > 0) {
                    e.preventDefault();
                }
            }
            if($(this).scrollTop() === $(this)[0].scrollHeight - $(this).height()){
                if(e.originalEvent.wheelDelta / 120 < 0) {
                    e.preventDefault();
                }
            }
            if (e.type == 'touchmove' & !$(this).hasClass('fgnp-fixed')){
                e.preventDefault();
            }
            e.stopPropagation();
        });
        if(!$('body').hasClass('fgnp-device-mobile')){
            $(document).on("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown mousedown.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown", _globalHide);
            $("iframe").contents().on("mousewheel.fgnp-dropdown DOMMouseScroll.fgnp-dropdown mousedown.fgnp-dropdown touchstart.fgnp-dropdown keydown.fgnp-dropdown", _globalHide);
        }

	    $(document).bind('mouseover.fgnp-dropdown', function(e){
		    if($(e.relatedTarget).parents(id).length > 0)
		    {
			clearTimeout(_menus[id].show);
			var $li = $(e.relatedTarget).parent().find('li');
			_menus[_global.activeId].currentHover = null;
			_menus[id].hide = setTimeout(function(){
				$li.find('ul').hide();
				if(_menus[id].autoHide)_globalHide(e);
			}, _menus[id].delay);
		    }
	    }).bind('click.fgnp-dropdown', _globalHide);
            return false;
        });
    };

})(jQuery);

/*! Dropdown Plugin ends here */
