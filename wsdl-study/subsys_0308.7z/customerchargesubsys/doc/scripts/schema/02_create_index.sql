--Ｔ＿注文情報index
CREATE INDEX "Ｔ＿注文情報_index1" ON "Ｔ＿注文情報" ("開始日＿実績");
CREATE INDEX "Ｔ＿注文情報_index2" ON "Ｔ＿注文情報" ("最大開始日＿実績");

--Ｔ＿ＰＡＹＧ情報index
CREATE INDEX "Ｔ＿ＰＡＹＧ情報_index1" ON "Ｔ＿ＰＡＹＧ情報" ("ＰＡＡＳ連携済フラグ");