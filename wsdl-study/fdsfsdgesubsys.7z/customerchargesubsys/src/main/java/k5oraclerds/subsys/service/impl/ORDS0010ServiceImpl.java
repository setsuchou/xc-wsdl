package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｍ＿商品型Mapper;
import k5oraclerds.subsys.dao.Ｍ＿料金プランMapper;
import k5oraclerds.subsys.dao.Ｍ＿注文種別Mapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.ORDS0010Service;

@Service("ORDS0010ServiceImpl")
public class ORDS0010ServiceImpl implements ORDS0010Service {

	public ORDS0010ServiceImpl() {
	}

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private Ｍ＿商品型Mapper Ｍ＿商品型Mapper;

	@Autowired
	private Ｍ＿注文種別Mapper Ｍ＿注文種別Mapper;

	@Autowired
	private Ｍ＿料金プランMapper Ｍ＿料金プランMapper;

	@Override
	public void insertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報) {
		int result = Ｔ＿契約情報Mapper.insert(Ｔ＿契約情報);
		System.out.println("ORDS0010ServiceImplの新規結果：" + result);
	}

	@Override
	public Ｔ＿契約情報 selectByPrimaryKey(String ｋ５契約番号, String サービス申込番号) {
		return Ｔ＿契約情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号);
	}

	@Override
	public List<Ｍ＿商品型> getShohinGata() {

		List<Ｍ＿商品型> returnList = Ｍ＿商品型Mapper.selectAll();

		return returnList;
	}

	@Override
	public List<Ｍ＿料金プラン> getRyokimPuran() {
		List<Ｍ＿料金プラン> returnList = Ｍ＿料金プランMapper.selectAll();

		return returnList;
	}

	@Override
	public List<Ｍ＿注文種別> getChumonShubetsu() {

		List<Ｍ＿注文種別> returnList = Ｍ＿注文種別Mapper.selectAll();
		return returnList;
	}

}
