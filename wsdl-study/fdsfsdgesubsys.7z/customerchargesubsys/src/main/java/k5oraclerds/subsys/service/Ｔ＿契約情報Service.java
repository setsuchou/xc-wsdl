package k5oraclerds.subsys.service;

import k5oraclerds.subsys.model.Ｔ＿契約情報;

public interface Ｔ＿契約情報Service {

	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

/*	List<Ｔ＿契約情報> getAll();

	List<Ｔ＿契約情報> getAll2();

	List<Ｔ＿契約情報> getAll3();*/

}
