/*
 * jquery.fgnp-layout.js v1.3.2
 *=============================================================================================================*/

/*!
 * @preserve jLayout Border Layout - JavaScript Layout Algorithms v0.4
 *
 * Licensed under the new BSD License.
 * Copyright 2008-2009, Bram Stein
 * All rights reserved.
 */

/*global fgnpLayout:true */
var fgnpLayout;
(function () {
	fgnpLayout = (typeof fgnpLayout === 'undefined') ? {} : fgnpLayout;

	fgnpLayout.border = function (spec) {
		var my = {},
			that = {},
			east = spec.east,
			west = spec.west,
			north = spec.north,
			south = spec.south,
			center = spec.center;

		my.hgap = spec.hgap || 0;
		my.vgap = spec.vgap || 0;

		that.items = function () {
			var items = [];
			if (east) {
				items.push(east);
			}

			if (west) {
				items.push(west);
			}

			if (north) {
				items.push(north);
			}

			if (south) {
				items.push(south);
			}

			if (center) {
				items.push(center);
			}
			return items;
		};

		that.layout = function (container) {
			var size = container.bounds(),
				insets = container.insets(),
				top = insets.top,
				bottom = size.height - insets.bottom,
				left = insets.left,
				right = size.width - insets.right,
				tmp;

			if (north && north.isVisible()) {
				tmp = north.preferredSize();
				north.bounds({'x': left, 'y': top, 'width': right - left, 'height': tmp.height});
				north.doLayout();

				top += tmp.height + my.vgap;
			}
			if (south && south.isVisible()) {
				tmp = south.preferredSize();
				south.bounds({'x': left, 'y': bottom - tmp.height, 'width': right - left, 'height': tmp.height});
				south.doLayout();

				bottom -= tmp.height + my.vgap;
			}
			if (east && east.isVisible()) {
				tmp = east.preferredSize();
				east.bounds({'x': right - tmp.width, 'y': top, 'width': tmp.width, 'height': bottom - top});
				east.doLayout();

				right -= tmp.width + my.hgap;
			}
			if (west && west.isVisible()) {
				tmp = west.preferredSize();
				west.bounds({'x': left, 'y': top, 'width': tmp.width, 'height': bottom - top});
				west.doLayout();

				left += tmp.width + my.hgap;
			}
			if (center && center.isVisible()) {
				center.bounds({'x': left, 'y': top, 'width': right - left, 'height': bottom - top});
				center.doLayout();
			}
			return container;
		};

		function typeLayout(type) {
			return function (container) {
				var insets = container.insets(),
					width = 0,
					height = 0,
					type_size;

				if (east && east.isVisible()) {
					type_size = east[type + 'Size']();
					width += type_size.width + my.hgap;
					height = type_size.height;
				}
				if (west && west.isVisible()) {
					type_size = west[type + 'Size']();
					width += type_size.width + my.hgap;
					height = Math.max(type_size.height, height);
				}
				if (center && center.isVisible()) {
					type_size = center[type + 'Size']();
					width += type_size.width;
					height = Math.max(type_size.height, height);
				}
				if (north && north.isVisible()) {
					type_size = north[type + 'Size']();
					width = Math.max(type_size.width, width);
					height += type_size.height + my.vgap;
				}
				if (south && south.isVisible()) {
					type_size = south[type + 'Size']();
					width = Math.max(type_size.width, width);
					height += type_size.height + my.vgap;
				}

				return {
					'width': width + insets.left + insets.right,
					'height': height + insets.top + insets.bottom
				};
			};
		}
		that.preferred = typeLayout('preferred');
		that.minimum = typeLayout('minimum');
		that.maximum = typeLayout('maximum');
		return that;
	};
}());

/*! jLayout Border Layout ends here */

/*!
 * JSizes - JQuery plugin v0.33
 *
 * Licensed under the revised BSD License.
 * Copyright 2008-2010 Bram Stein
 * All rights reserved.
 */

/*global jQuery*/
(function ($) {
	var num = function (value) {
			return parseInt(value, 10) || 0;
		};

	/**
	 * Sets or gets the values for min-width, min-height, max-width
	 * and max-height.
	 */
	$.each(['min', 'max'], function (i, name) {
		$.fn[name + 'Size'] = function (value) {
			var width, height;
			if (value) {
				if (value.width !== undefined) {
					this.css(name + '-width', value.width);
				}
				if (value.height !== undefined) {
					this.css(name + '-height', value.height);
				}
				return this;
			}
			else {
				width = this.css(name + '-width');
				height = this.css(name + '-height');
				// Apparently:
				//  * Opera returns -1px instead of none
				//  * IE6 returns undefined instead of none
				return {'width': (name === 'max' && (width === undefined || width === 'none' || num(width) === -1) && Number.MAX_VALUE) || num(width),
						'height': (name === 'max' && (height === undefined || height === 'none' || num(height) === -1) && Number.MAX_VALUE) || num(height)};
			}
		};
	});

	/**
	 * Returns whether or not an element is visible.
	 */
	$.fn.isVisible = function () {
		return this.is(':visible');
	};

	/**
	 * Sets or gets the values for border, margin and padding.
	 */
	$.each(['border', 'margin', 'padding'], function (i, name) {
		$.fn[name] = function (value) {
			if (value) {
				if (value.top !== undefined) {
					this.css(name + '-top' + (name === 'border' ? '-width' : ''), value.top);
				}
				if (value.bottom !== undefined) {
					this.css(name + '-bottom' + (name === 'border' ? '-width' : ''), value.bottom);
				}
				if (value.left !== undefined) {
					this.css(name + '-left' + (name === 'border' ? '-width' : ''), value.left);
				}
				if (value.right !== undefined) {
					this.css(name + '-right' + (name === 'border' ? '-width' : ''), value.right);
				}
				return this;
			}
			else {
				return {top: num(this.css(name + '-top' + (name === 'border' ? '-width' : ''))),
						bottom: num(this.css(name + '-bottom' + (name === 'border' ? '-width' : ''))),
						left: num(this.css(name + '-left' + (name === 'border' ? '-width' : ''))),
						right: num(this.css(name + '-right' + (name === 'border' ? '-width' : '')))};
			}
		};
	});
})(jQuery);

/*! JSizes - JQuery plugin ends here */

/*!
 * @preserve jLayout JQuery Plugin v0.17
 *
 * Licensed under the new BSD License.
 * Copyright 2008-2009 Bram Stein
 * All rights reserved.
 */

/*global jQuery fgnpLayout*/
if (jQuery && fgnpLayout) {
	(function ($) {
		/**
		 * This wraps jQuery objects in another object that supplies
		 * the methods required for the layout algorithms.
		 */
		function wrap(item, resize) {
			var that = {};

			$.each(['min', 'max'], function (i, name) {
				that[name + 'imumSize'] = function (value) {
					var l = item.data('fgnplayout');
					if (l) {
						return l[name + 'imum'](that);
					} else {
						return item[name + 'Size'](value);
					}
				};
			});

			$.extend(that, {
				doLayout: function () {
					var l = item.data('fgnplayout');
					if (l) {
					    l.layout(that);
					}
					item.css({position: 'absolute'});
				},
				isVisible: function () {
					return item.isVisible();
				},
				insets: function () {
					var p = item.padding(),
						b = item.border();

					return {
						'top': p.top,
						'bottom': p.bottom + b.bottom + b.top,
						'left': p.left,
						'right': p.right + b.right + b.left
					};
				},
				bounds: function (value) {
					var tmp = {};

					if (value) {
						if (typeof value.x === 'number') {
							tmp.left = value.x;
						}
						if (typeof value.y === 'number') {
							tmp.top = value.y;
						}
						if (typeof value.width === 'number') {
							tmp.width = (value.width - (item.outerWidth(true) - item.width()));
							tmp.width = (tmp.width >= 0) ? tmp.width : 0;
						}
						if (typeof value.height === 'number') {
							tmp.height = value.height - (item.outerHeight(true) - item.height());
							tmp.height = (tmp.height >= 0) ? tmp.height : 0;
						}
						item.css(tmp);
						return item;
					} else {
						tmp = item.position();
						return {
							'x': tmp.left,
							'y': tmp.top,
							'width': item.outerWidth(false),
							'height': item.outerHeight(false)
                        };
					}
				},
				preferredSize: function () {
					var minSize,
						maxSize,
						margin = item.margin(),
						size = {width: 0, height: 0},
						l = item.data('fgnplayout');

					if (l && resize) {
						size = l.preferred(that);

						minSize = that.minimumSize();
						maxSize = that.maximumSize();

						size.width += margin.left + margin.right;
						size.height += margin.top + margin.bottom;

						if (size.width < minSize.width || size.height < minSize.height) {
							size.width = Math.max(size.width, minSize.width);
							size.height = Math.max(size.height, minSize.height);
						} else if (size.width > maxSize.width || size.height > maxSize.height) {
							size.width = Math.min(size.width, maxSize.width);
							size.height = Math.min(size.height, maxSize.height);
						}
					} else {
						size = that.bounds();
						size.width += margin.left + margin.right;
						size.height += margin.top + margin.bottom;
					}
					return size;
				}
			});
			return that;
		}


		$.fn.layout = function (options) {
			var opts = $.extend({}, $.fn.layout.defaults, options);

			//We don't want someone adding thier overrides in sectionOverrides, and then loosing all of the default ones
			opts['sectionOverrides'] = $.extend( {}, opts['sectionOverrides'], opts['defaultSectionOverrides']);

			var elementsToWatch = ['north', 'south', 'west', 'east', 'center'];
			$.each(opts['sectionOverrides'], function(k, v)
			{
				elementsToWatch.push(k);
			});

			$.each(this, function () {
				var element = $(this),
					o = ( element.data('layout') ) ? $.extend(opts, element.data('layout')) : opts,
					elementWrapper = wrap(element, o.resize);

				if (o.type === 'border' && typeof fgnpLayout.border !== 'undefined') {
					$.each(elementsToWatch, function (i, name) {
						if (element.children().hasClass(name)) {
							if(opts['sectionOverrides'][name] !== undefined)
								o[opts['sectionOverrides'][name]] = wrap(element.children('.' + name + ':first'));
							else
								o[name] = wrap(element.children('.' + name + ':first'));
						}
					});

					element.data('fgnplayout', fgnpLayout.border(o));
				} else if (o.type === 'grid' && typeof fgnpLayout.grid !== 'undefined') {
					o.items = [];
					element.children().each(function (i) {
						if (!$(this).hasClass('ui-resizable-handle')) {
							o.items[i] = wrap($(this));
						}
					});
					element.data('fgnplayout', fgnpLayout.grid(o));
				} else if (o.type === 'flexGrid' && typeof fgnpLayout.flexGrid !== 'undefined') {
					o.items = [];
					element.children().each(function (i) {
						if (!$(this).hasClass('ui-resizable-handle')) {
							o.items[i] = wrap($(this));
						}
					});
					element.data('fgnplayout', fgnpLayout.flexGrid(o));
				} else if (o.type === 'column' && typeof fgnpLayout.column !== 'undefined') {
					o.items = [];
					element.children().each(function (i) {
						if (!$(this).hasClass('ui-resizable-handle')) {
							o.items[i] = wrap($(this));
						}
					});
					element.data('fgnplayout', fgnpLayout.column(o));
				} else if (o.type === 'flow' && typeof fgnpLayout.flow !== 'undefined') {
					o.items = [];
					element.children().each(function (i) {
						if (!$(this).hasClass('ui-resizable-handle')) {
							o.items[i] = wrap($(this));
						}
					});
					element.data('fgnplayout', fgnpLayout.flow(o));
				}

				if (o.resize) {
					elementWrapper.bounds(elementWrapper.preferredSize());
				}
				elementWrapper.doLayout();
				element.css({position: 'relative'});
				if ($.ui !== undefined) {
//					element.addClass('ui-widget');
//					element.addClass('fgnp-helper');
				}
			});

			return $.each(this, function () {
				var element = $(this),
					o = ( element.data('layout') ) ? $.extend(opts, element.data('layout')) : opts,
					elementWrapper = wrap(element, o.resize);

				if (o.type === 'border' && typeof fgnpLayout.border !== 'undefined') {
					$.each(elementsToWatch, function (i, name) {
						if (element.children().hasClass(name)) {
							if(opts['sectionOverrides'][name] !== undefined)
								o[opts['sectionOverrides'][name]] = wrap(element.children('.' + name + ':first'));
							else
								o[name] = wrap(element.children('.' + name + ':first'));
						}
					});

					element.data('fgnplayout', fgnpLayout.border(o));
				}
				elementWrapper.doLayout();
				element.css({position: 'relative'});
			    });
		};

		$.fn.layout.defaults = {
			resize: true,
			type: 'border',
			hgap: 0,
			vgap: 0,

			sectionOverrides : { },

			defaultSectionOverrides :
			{
				'fgnp-pane-top' 	: 'north',
				'fgnp-pane-bottom'	: 'south',
				'fgnp-pane-right'	: 'east',
				'fgnp-pane-left'	: 'west',
				'fgnp-pane-center'	: 'center',
				'fgnp-pane-top-inner'	: 'north',
				'fgnp-pane-bottom-inner': 'south',
				'fgnp-pane-right-inner'	: 'east',
				'fgnp-pane-left-inner'	: 'west',
				'fgnp-pane-center-inner': 'center'
			}
		};
	}(jQuery));
}

/*! jLayout JQuery Plugin  ends here */

(function ( $ )
{
	/**
	 * Adjust the size of scrollables in the given elements
	 * For options taken, see $.fn.adjustScrollSize.defaults
	 *
	 * @name $.fn.adjustScrollSize
	 * @param options
	 */
	$.fn.fgnpScrollable = function( options, devicetype )
	{

	    //if(devicetype !== 1){

		var options = $.extend( {}, $.fn.fgnpScrollable.defaults, options );

		//options.outerSelectorVisible = ':not(' + $(this).selector + '):visible';
		//options.outerSelector = ':not(' + $(this).selector + ')',
		//options.scrollableSelector = $(this).selector;

		var selector = $(this).selector;

		$.each(options, function(key, value)
		{
			options[key] = value.replace("{{selector}}", selector);
		});

		var $parents = [];
		$(this).each(function()
		{
			if($.inArray($(this).parent().get(0), $parents) === -1)
			{
				$parents.push($(this).parent().get(0));
			}
		});

		$.each($parents, function()
		{
			var $parent = $(this);

			if(!($parent.data("accordion") !== undefined && $parent.data("accordion").multiple === true)){

				var totalHeight = $parent.height();
				var remaining = totalHeight;

				var $children;
				if($parent.hasClass('fgnp-modal-box') || $parent.hasClass('fgnp-tab-content') ||  $parent.hasClass('fgnp-accordion'))
					$children = $parent.children(options.outerSelector);
				else
					$children = $parent.children(options.outerSelectorVisible);

				$children.each(function()
				{
					if($(this).hasClass('fgnp-size-mark') || $(this).hasClass('fgnp-resizable-handle'))
						return;

					remaining -= $(this).outerHeight(true);
				});

				var scrolls = $parent.children(options.scrollableSelector);

				scrolls.each(function()
				{
					$(this).outerHeight(remaining);
				});
			}
		});

		return $(this);
//	    }
	};

	/**
	 * The default options for this plugin
	 *
	 * @name $.fn.adjustScrollSize.defaults
	 * @property {string} outerSelector
	 * @property {string} scrollableSelector
	 */
	$.fn.fgnpScrollable.defaults = {
		outerSelectorVisible: ':not({{selector}}):visible',
		outerSelector: ':not({{selector}})',
		scrollableSelector: '{{selector}}'
	};

})(jQuery);


(function($){
    $.fn.fgnpLayoutToggle = function(options){

	var opts = $.extend({}, $.fn.fgnpLayoutToggle.defaults, options);

	var $elem = $('.fgnp-layout-toggle');
	var targetElem, elemWidth, elemHeight;

	var container = $(".fgnp-layout");
	function layout_complete()
	{
	    container.layout({resize : false });

	}

	function layout_step_width()
	{
	    if(parseInt($(targetElem).width()) !== elemWidth) {
		container.layout({resize : false });
	    }
	}

	function layout_step_height()
	{
	    if(parseInt($(targetElem).height()) !== elemHeight) {
		container.layout({resize : false });
	    }
	}

	$elem.on("click", function(){
	    targetElem = '.' + $(this).data('layout-toggle');

	    if(targetElem.indexOf("left") > 0 || targetElem.indexOf("right") > 0) {
		if($(targetElem).is(':visible')) elemWidth = $(targetElem).width();
		$(targetElem).animate({width: opts.animation}, {duration: opts.duration, complete: layout_complete, step: layout_step_width});
	    } else {
		if($(targetElem).is(':visible')) elemHeight = $(targetElem).height();
		$(targetElem).animate({height: opts.animation}, {duration: opts.duration, complete: layout_complete, step: layout_step_height});
	    }
	});

    };

    $.fn.fgnpLayoutToggle.defaults = {
	animation: 'toggle',
	duration: 500
    };

})(jQuery);


/*!
 * jQuery Actual Plugin
 * Copyright 2012, Ben Lin (http://dreamerslab.com/)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Version: 1.0.15
 *
 * Requires: jQuery >= 1.2.3
 *
 * the function returns the real width and height of a hidden element
 *
 */
;( function ( $ ){
  $.fn.addBack = $.fn.addBack || $.fn.andSelf;

  $.fn.extend({

    actual : function ( method, options ){
      // check if the jQuery method exist
      if( !this[ method ]){
        throw '$.actual => The jQuery method "' + method + '" you called does not exist';
      }

      var defaults = {
        absolute      : false,
        clone         : false,
        includeMargin : true
      };

      var configs = $.extend( defaults, options );

      var $target = this.eq( 0 );
      var fix, restore;

      if( configs.clone === true ){
        fix = function (){
          var style = 'position: absolute !important; top: -1000 !important; ';

          // this is useful with css3pie
          $target = $target.
            clone().
            attr( 'style', style ).
            appendTo( 'body' );
        };

        restore = function (){
          // remove DOM element after getting the width
          $target.remove();
        };
      }else{
        var tmp   = [];
        var style = '';
        var $hidden;

        fix = function (){
          // get all hidden parents
          $hidden = $target.parents().addBack().filter( ':hidden' );
          style   += 'visibility: hidden !important; display: block !important; ';

          if( configs.absolute === true ) style += 'position: absolute !important; ';

          // save the origin style props
          // set the hidden el css to be got the actual value later
          $hidden.each( function (){
            var $this = $( this );

            // Save original style. If no style was set, attr() returns undefined
            tmp.push( $this.attr( 'style' ));
            $this.attr( 'style', style );
          });
        };

        restore = function (){
          // restore origin style values
          $hidden.each( function ( i ){
            var $this = $( this );
            var _tmp  = tmp[ i ];

            if( _tmp === undefined ){
              $this.removeAttr( 'style' );
            }else{
              $this.attr( 'style', _tmp );
            }
          });
        };
      }

      fix();
      // get the actual value with user specific methed
      // it can be 'width', 'height', 'outerWidth', 'innerWidth'... etc
      // configs.includeMargin only works for 'outerWidth' and 'outerHeight'
      var actual = /(outer)/.test( method ) ?
        $target[ method ]( configs.includeMargin ) :
        $target[ method ]();

      restore();
      // IMPORTANT, this plugin only return the value of the first element
      return actual;
    }
  });
})( jQuery );

/*! jQuery Actual Plugin ends here */