/*
 * jquery.fgnp-keyboard-focus.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/

;
(function ($) {

  $.fn.fgnpKeyboardFocus = function (options) {

    if (typeof options !== 'object' || options instanceof jQuery) {
      options = {
        text: options
      };
    }

    var defaults = {
      keyFocusClass: 'fgnp-keyboard-focus',
      mouseFocusClass: 'fgnp-mouse-focus'
    };

    var opts = $.extend({}, defaults, options);

    var lastKey = new Date();
    var lastMouse = new Date();

    $(this).off('.fgnpKeyboardFocus')
      .on('mousedown.fgnpKeyboardFocus', function (e) {
        lastMouse = new Date();
      });

    $(this).on('keydown.fgnpKeyboardFocus', function (e) {
      lastKey = new Date();
    });

    $(this).on('focusin.fgnpKeyboardFocus', function (e) {
      // Remove focus class
      $('.' + opts.keyFocusClass + ', .' + opts.mouseFocusClass).removeClass(opts.keyFocusClass + ' ' + opts.mouseFocusClass);

      if (lastMouse < lastKey) {
        // Add keyboard-focus class
        $(e.target).addClass(opts.keyFocusClass);
      } else {
        // Add mouse-focus class
        $(e.target).addClass(opts.mouseFocusClass);
      }
    });

    $(this).on('focusout.fgnpKeyboardFocus', function (e) {
      // Remove focus class
      $('.' + opts.keyFocusClass + ', .' + opts.mouseFocusClass).removeClass(opts.keyFocusClass + ' ' + opts.mouseFocusClass);
    });

    return this;
  };

})(jQuery);

/* Keyboard Focus Plugin ends here */