$(function() {
	$("#close_button").on("click", function() {
		window.close();
	    return false;
	});
});

$(document).ready(function() {
	
	$('input:visible').eq(0).focus();
});