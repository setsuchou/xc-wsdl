/**
 * 共通エラー処理
 */
window.onerror = function(message, url, line) {

	// 静的エラーページに遷移させる　定義が無い場合デフォルトの場所に遷移
	if(!$.trim(XFW_JS_ERROR_PAGE)) {
		location.href = "/html/jsError.html";
	} else {
		location.href = XFW_JS_ERROR_PAGE;
	}

	// エラーメッセージを表示しないため、trueを返す
	return true;
};

/**
 * 共通メソッド
 */
$.extend({

	/**
	 * Ajax共通メソッド
	 */
	xfwAjax: function(options) {

		/**
		 * URL取得メソッド
		 */
		var getUrl = function(protocol, path) {

			// ホストを取得
			var location = $(document).attr("location");
			var host = location.host;

			// コンテキストパスとRIDを取得
			var contextPath = $("#xfw_context_path").val();
			var rid = $("#xfw_rid").val();

			// プロトコルが指定されていなければ表示している画面と同じプロトコルを使用する
			if(!protocol) {
				protocol = location.protocol.replace(":", "");
			}

			var queryString = path.split("?");
			var url = protocol + "://" + host + contextPath + queryString[0] + "?xfw.rid=" + rid;

			// pathにクエリ文字列が含まれている場合、先頭にリクエストIDを追加する
			if(1 < queryString.length) {
				for(var i = 1;i < queryString.length;i++) {
					url += "&" + queryString[i];
				}
			}

			return url;
		};

		/**
		 * Ajaxオプション取得メソッド
		 */
		var getAjaxOptions = function(options) {

			var ajaxOptions = {
				async: true,
				cache: false,
				contentType: "application/json; charset=utf-8;",
				dataType: "json",
				ifModified: false,
				processData: false,
				type: "POST",
				url: options.url
			};

			// データが指定されていれば追加
			if(options.data) {
				ajaxOptions["data"] = JSON.stringify(options.data);
			}

			// 通信前処理が指定されていれば追加
			if(options.beforeSendMethod) {
				ajaxOptions["beforeSend"] = function(jqXHR, settings) {
					var result = options.beforeSendMethod(options.beforeSendArgs);
					if(typeof result == "boolean") {
						return result;
					}
				}
			}

			// 成功時処理が指定されていれば追加
			if (options.successMethod) {
				ajaxOptions["success"] = function(result, textStatus, jqXHR) {
					options.successMethod(result, options.successArgs);
				}
			}

			// タイムアウト値が指定されていれば追加
			if (options.timeout) {
				ajaxOptions["timeout"] = options.timeout;
			}

			// 失敗時処理が指定されていれば追加
			if(options.errorMethod && options.timeoutMethod) {
				// 失敗時処理・タイムアウト時の両方が指定されている場合、メソッドを呼び分ける
				ajaxOptions["error"] = function(jqXHR, textStatus, errorThrown) {
					if (textStatus == "timeout") {
						options.timeoutMethod(options.timeoutArgs);
					} else {
						options.errorMethod(jqXHR.responseJSON, options.errorArgs);
					}
				}
			} else if(options.errorMethod) {
				// 失敗時処理のみの場合、タイムアウトでなければ呼ぶ
				ajaxOptions["error"] = function(jqXHR, textStatus, errorThrown) {
					if(textStatus != "timeout") {
						options.errorMethod(jqXHR.responseJSON, options.errorArgs);
					}
				}
			} else if(options.timeoutMethod) {
				// タイムアウト時のみの場合、タイムアウトなら呼ぶ
				ajaxOptions["error"] = function(jqXHR, textStatus, errorThrown) {
					if (textStatus == "timeout") {
						options.timeoutMethod(options.timeoutArgs);
					}
				}
			}

			// 完了時の処理が指定されていれば追加
			if (options.completeMethod) {
				ajaxOptions["complete"] = function(jqXHR, textStatus) {
					options.completeMethod(jqXHR.responseJSON, options.completeArgs);
				}
			}

			return ajaxOptions;
		};

		/**
		 * 入力値エラーチェック
		 */
		var validateOptions = function(options) {

			// プロトコルが指定されていて、httpまたはhttps以外の場合はエラーとする
			if(options.protocol && (options.protocol != "http" && options.protocol != "https")) {
				throw new Error("protocolに不正な値が指定されています。");
			}

			// URLが指定されていない場合、エラーとする
			if(!$.trim(options.url)) {
				throw new Error("urlに不正な値が指定されています。");
			}

			// タイムアウト値が指定されていて数値でない場合、エラーとする
			if(options.timeout && !$.isNumeric(options.timeout)) {
				throw new Error("timeoutに不正な値が指定されています。");
			}

			// 通信前・成功時・失敗時・タイムアウト時・通信完了時に実行するメソッドが指定されていて関数でない場合、エラーとする
			if(options.beforeSendMethod && !$.isFunction(options.beforeSendMethod)) {
				throw new Error("beforeSendMethodに不正な値が指定されています。");
			}

			if(options.successMethod && !$.isFunction(options.successMethod)) {
				throw new Error("successMethodに不正な値が指定されています。");
			}

			if(options.errorMethod && !$.isFunction(options.errorMethod)) {
				throw new Error("errorMethodに不正な値が指定されています。");
			}

			if(options.timeoutMethod && !$.isFunction(options.timeoutMethod)) {
				throw new Error("timeoutMethodに不正な値が指定されています。");
			}

			if(options.completeMethod && !$.isFunction(options.completeMethod)) {
				throw new Error("completeMethodに不正な値が指定されています。");
			}
		};

		// デフォルト値
		var defaults = {
			protocol: undefined,
			url: "",
			data: undefined,
			timeout: undefined,
			beforeSendMethod: undefined,
			beforeSendArgs: undefined,
			successMethod: undefined,
			successArgs: undefined,
			errorMethod: undefined,
			errorArgs: undefined,
			timeoutMethod: undefined,
			timeoutArgs: undefined,
			completeMethod: undefined,
			completeArgs: undefined
		};

		// デフォルト値を指定値で書き換えし、最終的な設定値を取得
		var setting = $.extend(defaults, options);

		// エラーチェック
		validateOptions(options);

		// URLを組み立てる
		setting.url = getUrl(setting.protocol, setting.url);

		// Ajaxオプションを取得し、Ajax通信実行
		$.ajax(getAjaxOptions(setting));
	},
	/**
	 * リクエスト二重送信防止メソッド
	 */
	xfwPreventDoubleRequest: function(options) {

		// ロック状態かどうか
		var isLocked = false;

		// デフォルト値
		var defaults = {
			releaseTime: undefined,
			excludeForm: undefined,
			excludeA: undefined
		};

		/**
		 * 入力値エラーチェック
		 */
		var validateOptions = function(options) {
			// 時間が指定されていて数値でない場合、エラーとする
			if(options.releaseTime && !$.isNumeric(options.releaseTime)) {
				throw new Error("releaseTimeに不正な値が指定されています。");
			}
		};

		/**
		 * ロック解除
		 */
		var unlock = function() {
			isLocked = false;
		};

		/**
		 * ロック
		 */
		var lock = function() {
			isLocked = true;
			// 時間指定がある場合、一定時間後にロック状態を解除する
			if(setting.releaseTime) {
				setTimeout(unlock, setting.releaseTime);
			}
		};

		/**
		 * ロック状態を確認し、処理継続可能か判定する
		 */
		var isContinue = function() {
			if(isLocked) {
				// ロック状態の場合、継続不可
				return false;
			} else {
				// 非ロック状態の場合、ロックをかけて継続
				lock();
				return true;
			}
		};

		// デフォルト値を指定値で書き換えし、最終的な設定値を取得
		var setting = $.extend(defaults, options);

		// エラーチェック
		validateOptions(setting);

		// 画面表示に解除（画面表示時にjsが再読み込みされず、ロックしたままになるのを防ぐ）
		$(window).on("pageshow", function() {
			unlock();
		});

		// aタグクリック時、ロックされていたら処理中断
		$("a").not(setting.excludeA).on("click", function(event) {
			return isContinue();
		});

		// submitイベント発生時、ロックされていたら処理中断
		$("form").not(setting.excludeForm).on("submit", function(event) {
			return isContinue();
		});
	}
});