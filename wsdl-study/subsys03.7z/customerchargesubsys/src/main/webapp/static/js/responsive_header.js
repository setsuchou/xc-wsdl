$(function () {

    var wd_old_width; //ウィンドウ幅の拡大 or 縮小判定
    wd_old_width = $(window).width(); //ウィンドウ自体  
    var size = $('ul.fgnp-nav > li').length;//ナビゲーションバーのメニュー数(「詳細」含む)

    // ナビゲーションメニューの表示位置調整：初期		
    var i = 1;
    while (i < size) {
        if ($('.primary-drpdwn:nth-of-type(' + i + ') .secondary-drpdwn ul').width() !== null) {                        
            var primary_width = $('.primary-drpdwn:nth-of-type(' + i + ')').children("ul").outerWidth(true);
            if (primary_width > 150) {                
                $('.primary-drpdwn:nth-of-type(' + i + ') .secondary-drpdwn').children("ul").css({ 'left': primary_width + 'px' });
            }
        }
        i++;
    }

    var mobile_flag = false; //モバイル判定
    // モバイルヘッダー、デスクトップ用ヘッダー、タッチデバイス可否で処理分け
    $(window).on('load resize', function () {

        var wd = $(window); //ウィンドウ自体

        // モバイルヘッダー
        if (window.matchMedia('(max-width:880px)').matches) {
            
            if (mobile_flag === false) {
                /* Responsive Header */
                //ウィンドウ幅 880px以下ならば、モバイルビュー
                //fgnp-navの幅は、モバイルでは100%
                $('.fgnp-nav').css({ 'width': '100%' });

                //末尾「詳細」は、非表示でDOM上から削除する
                $('ul.fgnp-nav > li:nth-of-type(' + size + ')').addClass('nav-is-none');
                $('ul.fgnp-nav > li:nth-of-type(' + size + ')').removeClass('nav-is-hidden');

                //PCで、初期表示がモバイルビュー(880px以下)の場合
                if (!$('ul.fgnp-nav > li:nth-of-type(1)').hasClass('nav-is-none')) {
                    //PCビューに切り替わる時に備え、非表示クラスを付与
                    $('ul.fgnp-nav > li').addClass('nav-is-none');
                    //PCビューに切り替わる時に備え、「詳細」内のメニューの非表示クラスを削除
                    $('ul.fgnp-nav > li:last-child > ul > li').removeClass('nav-is-none');
                }
                mobile_flag = true;
            }


            // デスクトップ用ヘッダー
        } else {
            
            
            /* Responsive Header */
            //ウィンドウ幅 768pxより大きいければ、PCビュー
            var last = $('ul.fgnp-nav > li:nth-of-type(' + size + ')').offset().top;
            //ナビゲーションメニューの最大幅 = ウィンドウ幅 - (サービス名領域 + 表示時間 + 外部リンク)
            var nav_width = wd.width() - ($('.fgnp-nav-action.fgnp-control-group').outerWidth() + $('.another-service-link').outerWidth() + 50);
                                                                                       
            //末尾「詳細をDOM上に存在させる PCでPCビューとモバイルビューを切り替えがあるため
            $('ul.fgnp-nav > li:nth-of-type(' + size + ')').removeClass('nav-is-none');

            //ウィンドウ幅縮小時
            if (wd_old_width >= wd.width()) {                
                $('.fgnp-nav').css({ "width": nav_width });
                //「詳細」を除いた表示メニュー数 = 非表示の候補メニュー
                var i = $('ul.fgnp-nav > li:not(.nav-is-none)').length - 1;
                //末尾「詳細」の高さを再計算
                last = $('ul.fgnp-nav > li:nth-of-type(' + size + ')').offset().top;

                while (i >= 1) {

                    if ($('ul.fgnp-nav > li:nth-of-type(1)').offset().top !== last) {

                        //末尾「詳細」より手前のメニューを非表示にする事で、末尾「詳細」の表示順序を早められる場合（領域を詰められる）
                        if (!$('ul.fgnp-nav > li:nth-of-type(' + i + ')').hasClass('nav-is-none')) {
                            //末尾「詳細」の手前の表示されているメニューを非表示にする
                            $('ul.fgnp-nav > li:nth-of-type(' + i + ')').addClass('nav-is-none');
                            
                            //fgnp-currentが付いた primary-drpdwnを非表示にした場合、「詳細」のfgnp-currenを付与                                                       
                            if($('ul.fgnp-nav > li:nth-of-type(' + i + ')').hasClass('fgnp-current')){
                                    $('ul.fgnp-nav > li:nth-of-type(' + size + ')').addClass('fgnp-current');                                  
                            }
                            
                            //本来は、size-1の時だけ「詳細」を表示するべきかもしれない？
                            $('ul.fgnp-nav > li:nth-of-type(' + size + ')').removeClass('nav-is-hidden');

                            //非表示にしたメニューを末尾「詳細」内のメニューで表示する
                            $('ul.fgnp-nav > li:last-child > ul > li:nth-of-type(' + i + ')').removeClass('nav-is-none');

                            //末尾「詳細」の高さを再計算
                            last = $('ul.fgnp-nav > li:nth-of-type(' + size + ')').offset().top;

                            //「詳細」の.secondary-drpdwnの要素は変動する為、left位置を再計算							
                            var primary_width = $('.primary-drpdwn:nth-of-type(' + size + ')').children("ul").outerWidth(true);
                            //var secondary_width =$('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn ul:last').outerWidth(true);
                            
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul').addClass('show');
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul').addClass('show');
                            var secondary_width = $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul:last').outerWidth(true);  
                            //$('.primary-drpdwn:nth-of-type(' + size + ') .secondary-drpdwn').children("ul").outerWidth(true);                            
                            
                            if(primary_width > 150){
                                $('.primary-drpdwn:nth-of-type(' + size + ') .secondary-drpdwn').children("ul").css({ 'left': primary_width + 'px' });
                            }
                            if(secondary_width > 150){
                                $('.primary-drpdwn:nth-of-type(' + size + ') .secondary-drpdwn .secondary-drpdwn').children("ul").css({ 'left':  secondary_width + 'px' });
                            }
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul').removeClass('show');
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul').removeClass('show');
                            
                        }
                    }
                        //縮小してoverflowが発生しないなら、何もしない
                    else {
                        break;
                    }
                    i--;
                }
            }
                //ウィンドウ幅拡大時
            else {

                $('.fgnp-nav').css({ "width": nav_width });
                var i = $('ul.fgnp-nav > li:not(.nav-is-none)').length;
                
                //先頭から末尾-1まで
                while (i <= size - 1) {
                    if ($('ul.fgnp-nav > li:nth-of-type(' + i + ')').hasClass('nav-is-none')) {
                        // 非表示クラスを一旦削除し、末尾「詳細」がoverflowするか確認する
                        $('ul.fgnp-nav > li:nth-of-type(' + i + ')').removeClass('nav-is-none');
                        //末尾「詳細」の高さを再計算
                        last = $('ul.fgnp-nav > li:nth-of-type(' + size + ')').offset().top;

                        if ($('ul.fgnp-nav > li:nth-of-type(' + i + ')').offset().top !== last) {
                            //表示させた結果、末尾「詳細」がoverflowするなら、再び非表示にする
                            $('ul.fgnp-nav > li:nth-of-type(' + i + ')').addClass('nav-is-none');
                            break;
                        }

                        else {                            
                            //fgnp-currentが付いた primary-drpdwnを表示した場合、「詳細」のfgnp-currenを外す
                            if($('ul.fgnp-nav > li:nth-of-type(' + i + ')').hasClass('fgnp-current')){
                                    $('ul.fgnp-nav > li:nth-of-type(' + size + ')').removeClass('fgnp-current');                                   
                            }
                                                    
                            //表示させた結果、overflowしないなら、表示させたメニューが相当する末尾「詳細」のメニューは非表示にする
                            $('ul.fgnp-nav > li:last-child > ul > li:nth-of-type(' + i + ')').addClass('nav-is-none');
                            
                            //「詳細」の.secondary-drpdwnの要素は変動する為、left位置を再計算							
                            var primary_width = $('.primary-drpdwn:nth-of-type(' + size + ')').children("ul").outerWidth(true);                            
                            
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul').addClass('show');
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul').addClass('show');
                            var secondary_width = $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul:last').outerWidth(true);                                                   
                            
                            if(primary_width > 150){
                                $('.primary-drpdwn:nth-of-type(' + size + ') .secondary-drpdwn').children("ul").css({ 'left': primary_width + 'px' });
                            }
                            if(secondary_width > 150){
                                $('.primary-drpdwn:nth-of-type(' + size + ') .secondary-drpdwn .secondary-drpdwn').children("ul").css({ 'left':  secondary_width + 'px' });
                            }
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul').removeClass('show');
                            $('.primary-drpdwn:nth-of-type(' + size + ') > ul > .secondary-drpdwn > ul').removeClass('show');
                            
                            
                            if (i === (size - 1)) {
                                //末尾-1　のメニューを表示させた場合、表示させるメニューはないため末尾「詳細」を非表示にする
                                $('ul.fgnp-nav > li:nth-of-type(' + size + ')').addClass('nav-is-hidden');
                            }
                        }
                    }
                    i++;
                }
            }
			
            // ナビゲーションメニューの表示位置調整：モバイルビューからPCビューに切り替わった直後 
            if (mobile_flag === true) {
                
                var i = 1;
                while (i < size) {
                    if ($('.primary-drpdwn:nth-of-type(' + i + ') .secondary-drpdwn ul').width() !== null) {
                        
                        var primary_width = $('.primary-drpdwn:nth-of-type(' + i + ')').children("ul").outerWidth(true);
                                                
                        //モバイルからPCに切り替わる時に、表示のメニューを一旦表示して、幅を計測する必要がある
                        if( $('.primary-drpdwn:nth-of-type(' + i + ')').hasClass('nav-is-none') ){
                          $('.primary-drpdwn:nth-of-type(' + i + ')').removeClass('nav-is-none');
                          primary_width = $('.primary-drpdwn:nth-of-type(' + i + ')').children("ul").outerWidth(true);
                          $('.primary-drpdwn:nth-of-type(' + i + ')').addClass('nav-is-none');                        
                        } 
                        //親メニュー幅が150pxより大きい時だけ、子メニューのleftを定義する
                        if (primary_width > 150) {                            
                            $('.primary-drpdwn:nth-of-type(' + i + ') .secondary-drpdwn').children("ul").css({ 'left': primary_width + 'px' });
                        }
                    }
                    i++;
                }
                mobile_flag = false;
            }
        }

        wd_old_width = $(window).width(); //ウィンドウ幅の拡大or縮小の判定変数

    });
    
    // タッチデバイス判定
    function isTouchDevice() {
    var result = false;
    if (window.ontouchstart === null) {
      result = true;
    }
    return result;
    }

});