$(function() {

	// カレンダ（初期値：なし）
	$('.datepicker').datepicker();

	// カレンダ（初期値：当日）
	$('.datepicker-today').datepicker().datepicker('setDate','today');

	$('.hideFlg').hide();

});

