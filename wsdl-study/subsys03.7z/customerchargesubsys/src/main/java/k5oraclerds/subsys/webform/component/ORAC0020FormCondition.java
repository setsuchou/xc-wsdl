package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

public class ORAC0020FormCondition implements Serializable {

	private static final long serialVersionUID = 1L;

	// サービス申込番号
	@NotEmpty
	private String sabisuMoshikomiBango;

	// 注文・連番
	private String remban;

	// K5契約番号
	private String k5keiyakubango;

	// アイデンティティ・ドメイン
	private String aidenteiteiDmein;

	// サービス終了日(FROM)
	private String sabisushuryoBiFrom;
	
	// サービス終了日(TO)
	private String sabisushuryoBiTo;

	// 適用開始希望日（FROM）
	String tekiyokibobiFrom;

	// 適用開始希望日（TO）
	String tekiyokibobiTo;

	/**
	 * @return the sabisuMoshikomiBango
	 */
	public String getSabisuMoshikomiBango() {
		return sabisuMoshikomiBango;
	}

	/**
	 * @param sabisuMoshikomiBango
	 *            the sabisuMoshikomiBango to set
	 */
	public void setSabisuMoshikomiBango(String sabisuMoshikomiBango) {
		this.sabisuMoshikomiBango = sabisuMoshikomiBango;
	}

	/**
	 * @return the remban
	 */
	public String getRemban() {
		return remban;
	}

	/**
	 * @param remban
	 *            the remban to set
	 */
	public void setRemban(String remban) {
		this.remban = remban;
	}

	/**
	 * @return the k5keiyakubango
	 */
	public String getK5keiyakubango() {
		return k5keiyakubango;
	}

	/**
	 * @param k5keiyakubango
	 *            the k5keiyakubango to set
	 */
	public void setK5keiyakubango(String k5keiyakubango) {
		this.k5keiyakubango = k5keiyakubango;
	}

	/**
	 * @return the aidenteiteiDmein
	 */
	public String getAidenteiteiDmein() {
		return aidenteiteiDmein;
	}

	/**
	 * @param aidenteiteiDmein
	 *            the aidenteiteiDmein to set
	 */
	public void setAidenteiteiDmein(String aidenteiteiDmein) {
		this.aidenteiteiDmein = aidenteiteiDmein;
	}

	
	/**
	 * @return the sabisushuryoBiFrom
	 */
	public String getSabisushuryoBiFrom() {
		return sabisushuryoBiFrom;
	}

	/**
	 * @param sabisushuryoBiFrom the sabisushuryoBiFrom to set
	 */
	public void setSabisushuryoBiFrom(String sabisushuryoBiFrom) {
		this.sabisushuryoBiFrom = sabisushuryoBiFrom;
	}

	/**
	 * @return the sabisushuryoBiTo
	 */
	public String getSabisushuryoBiTo() {
		return sabisushuryoBiTo;
	}

	/**
	 * @param sabisushuryoBiTo the sabisushuryoBiTo to set
	 */
	public void setSabisushuryoBiTo(String sabisushuryoBiTo) {
		this.sabisushuryoBiTo = sabisushuryoBiTo;
	}

	/**
	 * @return the tekiyokibobiFrom
	 */
	public String getTekiyokibobiFrom() {
		return tekiyokibobiFrom;
	}

	/**
	 * @param tekiyokibobiFrom
	 *            the tekiyokibobiFrom to set
	 */
	public void setTekiyokibobiFrom(String tekiyokibobiFrom) {
		this.tekiyokibobiFrom = tekiyokibobiFrom;
	}

	/**
	 * @return the tekiyokibobiTo
	 */
	public String getTekiyokibobiTo() {
		return tekiyokibobiTo;
	}

	/**
	 * @param tekiyokibobiTo
	 *            the tekiyokibobiTo to set
	 */
	public void setTekiyokibobiTo(String tekiyokibobiTo) {
		this.tekiyokibobiTo = tekiyokibobiTo;
	}
}
