package k5oraclerds.subsys.webform;

public class ORAC0060Form {

}
