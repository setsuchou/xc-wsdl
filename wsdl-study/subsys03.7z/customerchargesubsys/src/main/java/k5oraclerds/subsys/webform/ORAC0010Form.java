package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;

public class ORAC0010Form implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public ORAC0010Form() {
	}
	/**
	 * @param keiyakuJoho
	 * @param chumonjoho
	 * @param chumonjohoMeisaiList
	 * @param shohinGataMap
	 * @param ryokimPuranMap
	 * @param chumonShubetsuMap
	 */
	public ORAC0010Form(Ｔ＿契約情報 keiyakuJoho, Ｔ＿注文情報 chumonjoho, List<Ｔ＿注文明細> chumonjohoMeisaiList,
			Map<String, String> shohinGataMap, Map<String, String> ryokimPuranMap,
			Map<String, String> chumonShubetsuMap) {
		super();
		this.keiyakuJoho = keiyakuJoho;
		this.chumonjoho = chumonjoho;
		this.chumonjohoMeisaiList = chumonjohoMeisaiList;
		this.shohinGataMap = shohinGataMap;
		this.ryokimPuranMap = ryokimPuranMap;
		this.chumonShubetsuMap = chumonShubetsuMap;
	}

	// 契約情報
	@Valid
	private Ｔ＿契約情報 keiyakuJoho;
	// 注文情報
	@Valid
	private Ｔ＿注文情報 chumonjoho;

	//  注文明細情報
	@Valid
	private List<Ｔ＿注文明細> chumonjohoMeisaiList;

	// 商品型マスタ情報
	private Map<String, String> shohinGataMap;
	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;
	// 注文種別情報
	private Map<String, String> chumonShubetsuMap;

	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}
	/**
	 * @param keiyakuJoho セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}
	/**
	 * @return chumonjoho
	 */
	public Ｔ＿注文情報 getChumonjoho() {
		return chumonjoho;
	}
	/**
	 * @param chumonjoho セットする chumonjoho
	 */
	public void setChumonjoho(Ｔ＿注文情報 chumonjoho) {
		this.chumonjoho = chumonjoho;
	}
	/**
	 * @return chumonjohoMeisaiList
	 */
	public List<Ｔ＿注文明細> getChumonjohoMeisaiList() {
		return chumonjohoMeisaiList;
	}
	/**
	 * @param chumonjohoMeisaiList セットする chumonjohoMeisaiList
	 */
	public void setChumonjohoMeisaiList(List<Ｔ＿注文明細> chumonjohoMeisaiList) {
		this.chumonjohoMeisaiList = chumonjohoMeisaiList;
	}
	/**
	 * @return shohinGataMap
	 */
	public Map<String, String> getShohinGataMap() {
		return shohinGataMap;
	}
	/**
	 * @param shohinGataMap セットする shohinGataMap
	 */
	public void setShohinGataMap(Map<String, String> shohinGataMap) {
		this.shohinGataMap = shohinGataMap;
	}
	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}
	/**
	 * @param ryokimPuranMap セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}
	/**
	 * @return chumonShubetsuMap
	 */
	public Map<String, String> getChumonShubetsuMap() {
		return chumonShubetsuMap;
	}
	/**
	 * @param chumonShubetsuMap セットする chumonShubetsuMap
	 */
	public void setChumonShubetsuMap(Map<String, String> chumonShubetsuMap) {
		this.chumonShubetsuMap = chumonShubetsuMap;
	}
	/**
	 * @return serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
