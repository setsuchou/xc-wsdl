package k5oraclerds.subsys.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

public interface ORAC0020Service {

	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

	public List<ORAC0020FormMeisai> selectKeiyakuMeisaiByCondition(String sabisuMoshikomiBango, String k5keiyakubango,
			String aidenteiteiDmein, String sabisushuryoBiFrom, String sabisushuryoBiTo);

	/*
	 * List<Ｔ＿契約情報> getAll();
	 * 
	 * List<Ｔ＿契約情報> getAll2();
	 * 
	 * List<Ｔ＿契約情報> getAll3();
	 */

}
