package k5oraclerds.subsys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

public interface ORAC0020FormMeisaiMapper {

	/**
	 *
	 */
	List<ORAC0020FormMeisai> selectKeiyakuMeisaiByCondition(@Param("サービス申込番号") String sabisuMoshikomiBango,
			@Param("ｋ５契約番号") String k5keiyakubango, @Param("アイデンティティドメイン") String aidenteiteiDmein,
			@Param("サービス終了日FROM") String sabisushuryoBiFrom, @Param("サービス終了日TO") String sabisushuryoBiTo);

}