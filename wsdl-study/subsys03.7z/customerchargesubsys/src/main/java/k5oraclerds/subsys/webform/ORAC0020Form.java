package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.webform.component.ORAC0020FormCondition;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

/**
 * 契約情報検索画面ORAC0020Formの専用エンティティを定義するクラス
 * 
 * @author setsuchou
 *
 */
public class ORAC0020Form implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public ORAC0020Form() {
	}

	// ORAC0020Form明細
	private List<ORAC0020FormMeisai> meisaiList;

	// ORAC0020Form条件
	@Valid
	private ORAC0020FormCondition condition;

	// 契約情報

	private Ｔ＿契約情報 keiyakuJoho;
	// 注文情報
	private Ｔ＿注文情報 chumonJoho;

	// 注文情報リスト
	private List<Ｔ＿契約情報> keiyakuJohoList;

	// 注文情報リスト
	private List<Ｔ＿注文情報> chumonJohoList;

	// 商品型マスタ情報
	private Map<String, String> shohinGataMap;
	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;
	// 注文種別情報
	private Map<String, String> chumonShubetsuMap;

	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	/**
	 * @param keiyakuJoho
	 *            セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	/**
	 * @return chumonJoho
	 */
	public Ｔ＿注文情報 getChumonJoho() {
		return chumonJoho;
	}

	/**
	 * @param chumonJoho
	 *            セットする chumonJoho
	 */
	public void setChumonJoho(Ｔ＿注文情報 chumonJoho) {
		this.chumonJoho = chumonJoho;
	}

	/**
	 * @return keiyakuJohoList
	 */
	public List<Ｔ＿契約情報> getKeiyakuJohoList() {
		return keiyakuJohoList;
	}

	/**
	 * @param keiyakuJohoList
	 *            セットする keiyakuJohoList
	 */
	public void setKeiyakuJohoList(List<Ｔ＿契約情報> keiyakuJohoList) {
		this.keiyakuJohoList = keiyakuJohoList;
	}

	/**
	 * @return chumonJohoList
	 */
	public List<Ｔ＿注文情報> getChumonJohoList() {
		return chumonJohoList;
	}

	/**
	 * @param chumonJohoList
	 *            セットする chumonJohoList
	 */
	public void setChumonJohoList(List<Ｔ＿注文情報> chumonJohoList) {
		this.chumonJohoList = chumonJohoList;
	}

	/**
	 * @return shohinGataMap
	 */
	public Map<String, String> getShohinGataMap() {
		return shohinGataMap;
	}

	/**
	 * @param shohinGataMap
	 *            セットする shohinGataMap
	 */
	public void setShohinGataMap(Map<String, String> shohinGataMap) {
		this.shohinGataMap = shohinGataMap;
	}

	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}

	/**
	 * @param ryokimPuranMap
	 *            セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}

	/**
	 * @return chumonShubetsuMap
	 */
	public Map<String, String> getChumonShubetsuMap() {
		return chumonShubetsuMap;
	}

	/**
	 * @param chumonShubetsuMap
	 *            セットする chumonShubetsuMap
	 */
	public void setChumonShubetsuMap(Map<String, String> chumonShubetsuMap) {
		this.chumonShubetsuMap = chumonShubetsuMap;
	}

	/**
	 * @return meisaiList
	 */
	public List<ORAC0020FormMeisai> getMeisaiList() {
		return meisaiList;
	}

	/**
	 * @param meisaiList
	 *            セットする meisaiList
	 */
	public void setMeisaiList(List<ORAC0020FormMeisai> meisaiList) {
		this.meisaiList = meisaiList;
	}

	/**
	 * @return the condition
	 */
	public ORAC0020FormCondition getCondition() {
		return condition;
	}

	/**
	 * @param condition
	 *            the condition to set
	 */
	public void setCondition(ORAC0020FormCondition condition) {
		this.condition = condition;
	}

}
