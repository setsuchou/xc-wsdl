package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

public class ORAC0020FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;

	// サービス申込番号
	private String sabisuMoshikomiBango;

	// Ｔ＿契約情報から取得する
	// ｋ５契約番号
	private String k5KeiyakuBango;

	// 連番
	private Short remban;

	// Ｔ＿契約情報から取得する
	// アイデンティティドメイン
	private String aidenteiteiDomein;

	// 料金プランｉｄ
	private String ryokimpuranId;

	// Ｍ＿注文種別の注文種別名を注文種別ｉｄキーで取得し表示する。
	// 料金プラン名
	private String ryokimpuramMei;

	// Ｔ＿契約情報から取得する
	// サービス開始日
	private String sabisuKaishibi;
	
	// サービス終了日
	private String sabisuShuryobi;

	// 注文種別ｉｄ
	private String chumonshubetsuId;

	// 契約単位の場合： 空白で表示
	// 注文単位の場合： Ｍ＿注文種別の注文種別名を注文種別ｉｄキーで取得し表示する。
	// 注文種別名
	private String chumomBetsumei;

	// 契約単位の場合： 空白で表示
	// 注文単位の場合： yyyy/mm/dd 形式で表示
	// 適用開始希望日
	private String tekiyoKaishiKibobi;

	/**
	 * @return the k5KeiyakuBango
	 */
	public String getK5KeiyakuBango() {
		return k5KeiyakuBango;
	}

	/**
	 * @param k5KeiyakuBango the k5KeiyakuBango to set
	 */
	public void setK5KeiyakuBango(String k5KeiyakuBango) {
		this.k5KeiyakuBango = k5KeiyakuBango;
	}

	/**
	 * @return the sabisuMoshikomiBango
	 */
	public String getSabisuMoshikomiBango() {
		return sabisuMoshikomiBango;
	}

	/**
	 * @param sabisuMoshikomiBango the sabisuMoshikomiBango to set
	 */
	public void setSabisuMoshikomiBango(String sabisuMoshikomiBango) {
		this.sabisuMoshikomiBango = sabisuMoshikomiBango;
	}

	/**
	 * @return the remban
	 */
	public Short getRemban() {
		return remban;
	}

	/**
	 * @param remban the remban to set
	 */
	public void setRemban(Short remban) {
		this.remban = remban;
	}

	/**
	 * @return the aidenteiteiDomein
	 */
	public String getAidenteiteiDomein() {
		return aidenteiteiDomein;
	}

	/**
	 * @param aidenteiteiDomein the aidenteiteiDomein to set
	 */
	public void setAidenteiteiDomein(String aidenteiteiDomein) {
		this.aidenteiteiDomein = aidenteiteiDomein;
	}

	/**
	 * @return the ryokimpuranId
	 */
	public String getRyokimpuranId() {
		return ryokimpuranId;
	}

	/**
	 * @param ryokimpuranId the ryokimpuranId to set
	 */
	public void setRyokimpuranId(String ryokimpuranId) {
		this.ryokimpuranId = ryokimpuranId;
	}

	/**
	 * @return the ryokimpuramMei
	 */
	public String getRyokimpuramMei() {
		return ryokimpuramMei;
	}

	/**
	 * @param ryokimpuramMei the ryokimpuramMei to set
	 */
	public void setRyokimpuramMei(String ryokimpuramMei) {
		this.ryokimpuramMei = ryokimpuramMei;
	}

	/**
	 * @return the sabisuShuryobi
	 */
	public String getSabisuShuryobi() {
		return sabisuShuryobi;
	}

	/**
	 * @param sabisuShuryobi the sabisuShuryobi to set
	 */
	public void setSabisuShuryobi(String sabisuShuryobi) {
		this.sabisuShuryobi = sabisuShuryobi;
	}

	/**
	 * @return the chumonshubetsuId
	 */
	public String getChumonshubetsuId() {
		return chumonshubetsuId;
	}

	/**
	 * @param chumonshubetsuId the chumonshubetsuId to set
	 */
	public void setChumonshubetsuId(String chumonshubetsuId) {
		this.chumonshubetsuId = chumonshubetsuId;
	}

	/**
	 * @return the chumomBetsumei
	 */
	public String getChumomBetsumei() {
		return chumomBetsumei;
	}

	/**
	 * @param chumomBetsumei the chumomBetsumei to set
	 */
	public void setChumomBetsumei(String chumomBetsumei) {
		this.chumomBetsumei = chumomBetsumei;
	}

	/**
	 * @return the tekiyoKaishiKibobi
	 */
	public String getTekiyoKaishiKibobi() {
		return tekiyoKaishiKibobi;
	}

	/**
	 * @param tekiyoKaishiKibobi the tekiyoKaishiKibobi to set
	 */
	public void setTekiyoKaishiKibobi(String tekiyoKaishiKibobi) {
		this.tekiyoKaishiKibobi = tekiyoKaishiKibobi;
	}

	/**
	 * @return the sabisuKaishibi
	 */
	public String getSabisuKaishibi() {
		return sabisuKaishibi;
	}

	/**
	 * @param sabisuKaishibi the sabisuKaishibi to set
	 */
	public void setSabisuKaishibi(String sabisuKaishibi) {
		this.sabisuKaishibi = sabisuKaishibi;
	}
}
