package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;

public class ORAC0030Form implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public ORAC0030Form() {
	}

	/**
	 * @param keiyakuJoho
	 * @param ryokimPuranMap
	 */
	public ORAC0030Form(Ｔ＿契約情報 keiyakuJoho,Map<String, String> ryokimPuranMap) {
		super();
		this.keiyakuJoho = keiyakuJoho;
		this.ryokimPuranMap = ryokimPuranMap;
	}

	/**
	 *  契約情報
	 */
	@Valid
	private Ｔ＿契約情報 keiyakuJoho;

	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;


	//ORAC0020FormのJson
	private String ORAC0020FormJson;

	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	/**
	 * @param keiyakuJoho セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}
	/**
	 * @param ryokimPuranMap セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}

	/**
	 * @return oRAC0020FormJson
	 */
	public String getORAC0020FormJson() {
		return ORAC0020FormJson;
	}

	/**
	 * @param oRAC0020FormJson セットする oRAC0020FormJson
	 */
	public void setORAC0020FormJson(String oRAC0020FormJson) {
		ORAC0020FormJson = oRAC0020FormJson;
	}
}
