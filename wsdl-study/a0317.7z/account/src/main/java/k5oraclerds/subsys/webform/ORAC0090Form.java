package k5oraclerds.subsys.webform;

import java.io.Serializable;

public class ORAC0090Form implements Serializable {

	private static final long serialVersionUID = 1L;
}
