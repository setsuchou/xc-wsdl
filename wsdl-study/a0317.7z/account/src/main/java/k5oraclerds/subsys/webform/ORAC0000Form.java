package k5oraclerds.subsys.webform;

import java.io.Serializable;

public class ORAC0000Form implements Serializable {

	private static final long serialVersionUID = 1L;
}
