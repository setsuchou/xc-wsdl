package k5oraclerds.subsys.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/ORAC0090Form", method = {RequestMethod.GET, RequestMethod.POST})
public class ORAC0090Controller {

	private static Logger logger = LoggerFactory.getLogger(ORAC0090Controller.class);

	@RequestMapping("/init")
	public String init() {
		logger.info("メソッド" + "init" + "：開始");
		logger.info("メソッド" + "init" + "：終了");
		return "ORAC0090Form";
	}

}
