package k5oraclerds.subsys.webform.component;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

public class ORAC0080FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;

	// チェックボックス
	private Boolean checkboxStatus;

	private int lineIndex;

	// 年月
	private String nengetsu;

	// 商品型ＩＤ
	private String shohinKataId;

	// 商品型名
	private String shohinKataMei;

	// Oracle請求額／超過使用ユニット
	@Valid
	@DecimalMax(value = "999999999999", message = "入力値は最大值「{value}」より大きいです。")
	@DecimalMin(value = "1", message = "入力値は最大值「{value}」より小さいです。")
	private BigDecimal oracleSeikyugaku;

	// FJ単価
	private BigDecimal fjTanka;

	// FJ売値
	private BigDecimal fjUrine;

	// 超過使用料
	private BigDecimal chokaShiyoryo;

	// ＰＡＡＳ連携済フラグ(隠し項目)
	private String paasRenkeiZumifuragu;

	/**
	 * @return oracleSeikyugaku
	 */
	public BigDecimal getOracleSeikyugaku() {
		return oracleSeikyugaku;
	}

	/**
	 * @param oracleSeikyugaku
	 *            セットする oracleSeikyugaku
	 */
	public void setOracleSeikyugaku(BigDecimal oracleSeikyugaku) {
		this.oracleSeikyugaku = oracleSeikyugaku;
	}

	/**
	 * @return fjTanka
	 */
	public BigDecimal getFjTanka() {
		return fjTanka;
	}

	/**
	 * @param fjTanka
	 *            セットする fjTanka
	 */
	public void setFjTanka(BigDecimal fjTanka) {
		this.fjTanka = fjTanka;
	}

	/**
	 * @return fjUrine
	 */
	public BigDecimal getFjUrine() {
		return fjUrine;
	}

	/**
	 * @param fjUrine
	 *            セットする fjUrine
	 */
	public void setFjUrine(BigDecimal fjUrine) {
		this.fjUrine = fjUrine;
	}

	/**
	 * @return checkboxStatus
	 */
	public Boolean getCheckboxStatus() {
		return checkboxStatus;
	}

	/**
	 * @param checkboxStatus
	 *            セットする checkboxStatus
	 */
	public void setCheckboxStatus(Boolean checkboxStatus) {
		this.checkboxStatus = checkboxStatus;
	}

	/**
	 * @return nengetsu
	 */
	public String getNengetsu() {
		return nengetsu;
	}

	/**
	 * @param nengetsu
	 *            セットする nengetsu
	 */
	public void setNengetsu(String nengetsu) {
		this.nengetsu = nengetsu;
	}

	/**
	 * @return shohinKataId
	 */
	public String getShohinKataId() {
		return shohinKataId;
	}

	/**
	 * @param shohinKataId
	 *            セットする shohinKataId
	 */
	public void setShohinKataId(String shohinKataId) {
		this.shohinKataId = shohinKataId;
	}

	/**
	 * @return shohinKataMei
	 */
	public String getShohinKataMei() {
		return shohinKataMei;
	}

	/**
	 * @param shohinKataMei
	 *            セットする shohinKataMei
	 */
	public void setShohinKataMei(String shohinKataMei) {
		this.shohinKataMei = shohinKataMei;
	}

	/**
	 * @return chokaShiyoryo
	 */
	public BigDecimal getChokaShiyoryo() {
		return chokaShiyoryo;
	}

	/**
	 * @param chokaShiyoryo
	 *            セットする chokaShiyoryo
	 */
	public void setChokaShiyoryo(BigDecimal chokaShiyoryo) {
		this.chokaShiyoryo = chokaShiyoryo;
	}

	/**
	 * @return paasRenkeiZumifuragu
	 */
	public String getPaasRenkeiZumifuragu() {
		return paasRenkeiZumifuragu;
	}

	/**
	 * @param paasRenkeiZumifuragu
	 *            セットする paasRenkeiZumifuragu
	 */
	public void setPaasRenkeiZumifuragu(String paasRenkeiZumifuragu) {
		this.paasRenkeiZumifuragu = paasRenkeiZumifuragu;
	}

	/**
	 * @return lineIndex
	 */
	public int getLineIndex() {
		return lineIndex;
	}

	/**
	 * @param lineIndex
	 *            セットする lineIndex
	 */
	public void setLineIndex(int lineIndex) {
		this.lineIndex = lineIndex;
	}
}
