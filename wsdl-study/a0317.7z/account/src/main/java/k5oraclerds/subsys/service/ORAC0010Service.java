package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;

public interface ORAC0010Service {

	public Ｔ＿契約情報 selectKeiyakuJohoByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

	public int insertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報);

	public List<Ｍ＿商品型> getShohinGata();

	public List<Ｍ＿料金プラン> getRyokimPuran();

	public List<Ｍ＿注文種別> getChumonShubetsu();

	public int updateKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報);

	public int updateInsertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報);

	public int insertChumonjoho(Ｔ＿注文情報 Ｔ＿注文情報);

	public int updateChumonjoho(Ｔ＿注文情報 Ｔ＿注文情報);

	public int updateInsertChumonjoho(Ｔ＿注文情報 Ｔ＿注文情報);

	public int insertChumonjohoMeisai(Ｔ＿注文明細 Ｔ＿注文明細);

	public int updateChumonjohoMeisai(Ｔ＿注文明細 Ｔ＿注文明細);

	public int updateInsertChumonjohoMeisai(Ｔ＿注文明細 Ｔ＿注文明細);

	public List<Ｍ＿商品型> selectShohinGataForChumonmesai(String 料金プランｉｄ, String 適用日);

	public boolean 契約情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号);

	public boolean 注文情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番);

	public boolean 注文明細論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番, String 商品型ｉｄ);

}
