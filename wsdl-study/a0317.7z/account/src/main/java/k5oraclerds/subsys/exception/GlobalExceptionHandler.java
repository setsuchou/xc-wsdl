package k5oraclerds.subsys.exception;

/**
 * 例外のハンドラクラスです。
 *
 */

//@ControllerAdvice
public class GlobalExceptionHandler {

//	@ExceptionHandler
//	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public String handleException(Exception e) {
		System.out.println(e.toString());
		return "error/systemError";
	}
}
