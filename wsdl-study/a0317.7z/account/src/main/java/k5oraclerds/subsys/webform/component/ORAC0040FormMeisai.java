package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿注文明細;

public class ORAC0040FormMeisai implements Serializable {

	private static final long serialVersionUID = 1L;
	// チェックボックス
	private boolean checkboxStatus;

	// 商品名
	private String shohinmei;

	// Ｔ＿注文明細
	@Valid
	private Ｔ＿注文明細 注文明細;

	//終了日（実績）の入力前の値
	private String syuryobiJissekiMae;

	//請求額チェック結果
	private String sekyugakuCheckKekka;

	//存在フラグ
	private String sonzaiFlag;

	/**
	 * @return checkboxStatus
	 */
	public boolean isCheckboxStatus() {
		return checkboxStatus;
	}

	/**
	 * @param checkboxStatus
	 *            セットする checkboxStatus
	 */
	public void setCheckboxStatus(boolean checkboxStatus) {
		this.checkboxStatus = checkboxStatus;
	}

	/**
	 * @return the shohinmei
	 */
	public String getShohinmei() {
		return shohinmei;
	}

	/**
	 * @param shohinmei
	 *            the shohinmei to set
	 */
	public void setShohinmei(String shohinmei) {
		this.shohinmei = shohinmei;
	}

	/**
	 * @return the 注文明細
	 */
	public Ｔ＿注文明細 get注文明細() {
		return 注文明細;
	}

	/**
	 * @param 注文明細
	 *            the 注文明細 to set
	 */
	public void set注文明細(Ｔ＿注文明細 注文明細) {
		this.注文明細 = 注文明細;
	}

	public String getSekyugakuCheckKekka() {
		return sekyugakuCheckKekka;
	}

	public void setSekyugakuCheckKekka(String sekyugakuCheckKekka) {
		this.sekyugakuCheckKekka = sekyugakuCheckKekka;
	}

	public String getSyuryobiJissekiMae() {
		return syuryobiJissekiMae;
	}

	public void setSyuryobiJissekiMae(String syuryobiJissekiMae) {
		this.syuryobiJissekiMae = syuryobiJissekiMae;
	}

	public String getSonzaiFlag() {
		return sonzaiFlag;
	}

	public void setSonzaiFlag(String sonzaiFlag) {
		this.sonzaiFlag = sonzaiFlag;
	}

}
