package k5oraclerds.subsys.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.webform.ORAC0010Form;
import k5oraclerds.subsys.webform.ORAC0020Form;

@Controller
@RequestMapping(value = "/ORAC0000Form", method = { RequestMethod.GET,RequestMethod.POST})
public class ORAC0000Controller {

	private static Logger logger = LoggerFactory.getLogger(ORAC0000Controller.class);


	@RequestMapping("/keiyakuJohoShinkiToroku")
	public String keiyakuJohoShinkiToroku(Model model) {

		logger.debug("メソッド" + "kensaku" + "：開始");

		// 画面フォームの初期化を行う
		ORAC0010Form ORAC0010Form = new ORAC0010Form();
		model.addAttribute("ORAC0010Form", ORAC0010Form);

		logger.debug("メソッド" + "kensaku" + "：終了");

		// ORAC0010画面へ遷移する
		return "forward:/ORAC0010Form/init";
	}


	@RequestMapping("/kensaku")
	public String kensaku(Model model) {

		logger.debug("メソッド" + "kensaku" + "：開始");

		// 画面フォームの初期化を行う
		ORAC0020Form ORAC0020Form = new ORAC0020Form();
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		logger.debug("メソッド" + "kensaku" + "：終了");

		// ORAC0010画面へ遷移する
		return "forward:/ORAC0020Form/init";
	}

}
