package k5oraclerds.subsys.model;

import java.util.Date;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Ｔ＿注文情報 {
    /* (非 Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((オラクルオーダーｉｄ == null) ? 0 : オラクルオーダーｉｄ.hashCode());
		result = prime * result + ((コメント == null) ? 0 : コメント.hashCode());
		result = prime * result + ((サービス申込番号 == null) ? 0 : サービス申込番号.hashCode());
		result = prime * result + ((ユーザｉｄ == null) ? 0 : ユーザｉｄ.hashCode());
		result = prime * result + ((料金プランｉｄ == null) ? 0 : 料金プランｉｄ.hashCode());
		result = prime * result + ((更新ユーザー == null) ? 0 : 更新ユーザー.hashCode());
		result = prime * result + ((更新日時 == null) ? 0 : 更新日時.hashCode());
		result = prime * result + ((最大開始日＿実績 == null) ? 0 : 最大開始日＿実績.hashCode());
		result = prime * result + ((注文種別ｉｄ == null) ? 0 : 注文種別ｉｄ.hashCode());
		result = prime * result + ((特別値引フラグ == null) ? 0 : 特別値引フラグ.hashCode());
		result = prime * result + ((申込請書発行日 == null) ? 0 : 申込請書発行日.hashCode());
		result = prime * result + ((登録ユーザー == null) ? 0 : 登録ユーザー.hashCode());
		result = prime * result + ((登録日時 == null) ? 0 : 登録日時.hashCode());
		result = prime * result + ((終了日＿実績 == null) ? 0 : 終了日＿実績.hashCode());
		result = prime * result + ((見積日 == null) ? 0 : 見積日.hashCode());
		result = prime * result + ((請求依頼抽出済フラグ == null) ? 0 : 請求依頼抽出済フラグ.hashCode());
		result = prime * result + ((論理削除フラグ == null) ? 0 : 論理削除フラグ.hashCode());
		result = prime * result + ((連番 == null) ? 0 : 連番.hashCode());
		result = prime * result + ((適用開始希望日 == null) ? 0 : 適用開始希望日.hashCode());
		result = prime * result + ((開始日＿実績 == null) ? 0 : 開始日＿実績.hashCode());
		result = prime * result + ((ｆｊ料金表適用日 == null) ? 0 : ｆｊ料金表適用日.hashCode());
		result = prime * result + ((ｋ５契約番号 == null) ? 0 : ｋ５契約番号.hashCode());
		result = prime * result + ((ｏｒａｃｌｅ料金表適用日 == null) ? 0 : ｏｒａｃｌｅ料金表適用日.hashCode());
		result = prime * result + ((ｐａａｓ連携済フラグ == null) ? 0 : ｐａａｓ連携済フラグ.hashCode());
		return result;
	}

	/* (非 Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ｔ＿注文情報 other = (Ｔ＿注文情報) obj;
		if (オラクルオーダーｉｄ == null) {
			if (other.オラクルオーダーｉｄ != null)
				return false;
		} else if (!オラクルオーダーｉｄ.equals(other.オラクルオーダーｉｄ))
			return false;
		if (コメント == null) {
			if (other.コメント != null)
				return false;
		} else if (!コメント.equals(other.コメント))
			return false;
		if (サービス申込番号 == null) {
			if (other.サービス申込番号 != null)
				return false;
		} else if (!サービス申込番号.equals(other.サービス申込番号))
			return false;
		if (ユーザｉｄ == null) {
			if (other.ユーザｉｄ != null)
				return false;
		} else if (!ユーザｉｄ.equals(other.ユーザｉｄ))
			return false;
		if (料金プランｉｄ == null) {
			if (other.料金プランｉｄ != null)
				return false;
		} else if (!料金プランｉｄ.equals(other.料金プランｉｄ))
			return false;
		if (更新ユーザー == null) {
			if (other.更新ユーザー != null)
				return false;
		} else if (!更新ユーザー.equals(other.更新ユーザー))
			return false;
		if (更新日時 == null) {
			if (other.更新日時 != null)
				return false;
		}
		if (最大開始日＿実績 == null) {
			if (other.最大開始日＿実績 != null)
				return false;
		} else if (!最大開始日＿実績.equals(other.最大開始日＿実績))
			return false;
		if (注文種別ｉｄ == null) {
			if (other.注文種別ｉｄ != null)
				return false;
		} else if (!注文種別ｉｄ.equals(other.注文種別ｉｄ))
			return false;
		if (特別値引フラグ == null) {
			if (other.特別値引フラグ != null)
				return false;
		} else if (!特別値引フラグ.equals(other.特別値引フラグ))
			return false;
		if (申込請書発行日 == null) {
			if (other.申込請書発行日 != null)
				return false;
		} else if (!申込請書発行日.equals(other.申込請書発行日))
			return false;
		if (登録ユーザー == null) {
			if (other.登録ユーザー != null)
				return false;
		} else if (!登録ユーザー.equals(other.登録ユーザー))
			return false;
		if (登録日時 == null) {
			if (other.登録日時 != null)
				return false;
		}
		if (終了日＿実績 == null) {
			if (other.終了日＿実績 != null)
				return false;
		} else if (!終了日＿実績.equals(other.終了日＿実績))
			return false;
		if (見積日 == null) {
			if (other.見積日 != null)
				return false;
		} else if (!見積日.equals(other.見積日))
			return false;
		if (請求依頼抽出済フラグ == null) {
			if (other.請求依頼抽出済フラグ != null)
				return false;
		} else if (!請求依頼抽出済フラグ.equals(other.請求依頼抽出済フラグ))
			return false;
		if (論理削除フラグ == null) {
			if (other.論理削除フラグ != null)
				return false;
		} else if (!論理削除フラグ.equals(other.論理削除フラグ))
			return false;
		if (連番 == null) {
			if (other.連番 != null)
				return false;
		} else if (!連番.equals(other.連番))
			return false;
		if (適用開始希望日 == null) {
			if (other.適用開始希望日 != null)
				return false;
		} else if (!適用開始希望日.equals(other.適用開始希望日))
			return false;
		if (開始日＿実績 == null) {
			if (other.開始日＿実績 != null)
				return false;
		} else if (!開始日＿実績.equals(other.開始日＿実績))
			return false;
		if (ｆｊ料金表適用日 == null) {
			if (other.ｆｊ料金表適用日 != null)
				return false;
		} else if (!ｆｊ料金表適用日.equals(other.ｆｊ料金表適用日))
			return false;
		if (ｋ５契約番号 == null) {
			if (other.ｋ５契約番号 != null)
				return false;
		} else if (!ｋ５契約番号.equals(other.ｋ５契約番号))
			return false;
		if (ｏｒａｃｌｅ料金表適用日 == null) {
			if (other.ｏｒａｃｌｅ料金表適用日 != null)
				return false;
		} else if (!ｏｒａｃｌｅ料金表適用日.equals(other.ｏｒａｃｌｅ料金表適用日))
			return false;
		if (ｐａａｓ連携済フラグ == null) {
			if (other.ｐａａｓ連携済フラグ != null)
				return false;
		} else if (!ｐａａｓ連携済フラグ.equals(other.ｐａａｓ連携済フラグ))
			return false;
		return true;
	}

	/**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.Ｋ５契約番号
     *
     * @mbg.generated
     */
    private String ｋ５契約番号;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.サービス申込番号
     *
     * @mbg.generated
     */
    private String サービス申込番号;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.連番
     *
     * @mbg.generated
     */
    private Short 連番;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.料金プランＩＤ
     *
     * @mbg.generated
     */
    private String 料金プランｉｄ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.注文種別ＩＤ
     *
     * @mbg.generated
     */
    @NotEmpty(message = "注文種別を選択してください。")
    private String 注文種別ｉｄ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.オラクルオーダーＩＤ
     *
     * @mbg.generated
     */
    @Size(max = 32, min = 0, message = "サイズが1と{max}の間ではないです。")
    private String オラクルオーダーｉｄ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.見積日
     *
     * @mbg.generated
     */
    @NotEmpty(message = "見積日が未入力です。")
    private String 見積日;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.ＦＪ料金表適用日
     *
     * @mbg.generated
     */
    private String ｆｊ料金表適用日;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.ＯＲＡＣＬＥ料金表適用日
     *
     * @mbg.generated
     */
    private String ｏｒａｃｌｅ料金表適用日;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.コメント
     *
     * @mbg.generated
     */
    @Size(max = 200, min = 0, message = "サイズが1と{max}の間ではないです。")
    private String コメント;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.適用開始希望日
     *
     * @mbg.generated
     */
    @NotEmpty(message = "適用開始希望日が未入力です。")
    private String 適用開始希望日;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.特別値引フラグ
     *
     * @mbg.generated
     */
    private String 特別値引フラグ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.開始日＿実績
     *
     * @mbg.generated
     */
    private String 開始日＿実績;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.終了日＿実績
     *
     * @mbg.generated
     */
    private String 終了日＿実績;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.最大開始日＿実績
     *
     * @mbg.generated
     */
    private String 最大開始日＿実績;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.ユーザＩＤ
     *
     * @mbg.generated
     */
    @Size(max = 256, min = 0, message = "サイズが1と{max}の間ではないです。")
    private String ユーザｉｄ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.ＰＡＡＳ連携済フラグ
     *
     * @mbg.generated
     */
    private String ｐａａｓ連携済フラグ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.請求依頼抽出済フラグ
     *
     * @mbg.generated
     */
    private String 請求依頼抽出済フラグ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.申込請書発行日
     *
     * @mbg.generated
     */
    private String 申込請書発行日;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.論理削除フラグ
     *
     * @mbg.generated
     */
    private String 論理削除フラグ;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.登録日時
     *
     * @mbg.generated
     */
    private Date 登録日時;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.登録ユーザー
     *
     * @mbg.generated
     */
    private String 登録ユーザー;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.更新日時
     *
     * @mbg.generated
     */
    private Date 更新日時;

    /**
     *
     * This field was generated by MyBatis Generator.
     * This field corresponds to the database column Ｔ＿注文情報.更新ユーザー
     *
     * @mbg.generated
     */
    private String 更新ユーザー;

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.Ｋ５契約番号
     *
     * @return the value of Ｔ＿注文情報.Ｋ５契約番号
     *
     * @mbg.generated
     */
    public String getＫ５契約番号() {
        return ｋ５契約番号;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.Ｋ５契約番号
     *
     * @param ｋ５契約番号 the value for Ｔ＿注文情報.Ｋ５契約番号
     *
     * @mbg.generated
     */
    public void setＫ５契約番号(String ｋ５契約番号) {
        this.ｋ５契約番号 = ｋ５契約番号 == null ? null : ｋ５契約番号.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.サービス申込番号
     *
     * @return the value of Ｔ＿注文情報.サービス申込番号
     *
     * @mbg.generated
     */
    public String getサービス申込番号() {
        return サービス申込番号;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.サービス申込番号
     *
     * @param サービス申込番号 the value for Ｔ＿注文情報.サービス申込番号
     *
     * @mbg.generated
     */
    public void setサービス申込番号(String サービス申込番号) {
        this.サービス申込番号 = サービス申込番号 == null ? null : サービス申込番号.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.連番
     *
     * @return the value of Ｔ＿注文情報.連番
     *
     * @mbg.generated
     */
    public Short get連番() {
        return 連番;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.連番
     *
     * @param 連番 the value for Ｔ＿注文情報.連番
     *
     * @mbg.generated
     */
    public void set連番(Short 連番) {
        this.連番 = 連番;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.料金プランＩＤ
     *
     * @return the value of Ｔ＿注文情報.料金プランＩＤ
     *
     * @mbg.generated
     */
    public String get料金プランｉｄ() {
        return 料金プランｉｄ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.料金プランＩＤ
     *
     * @param 料金プランｉｄ the value for Ｔ＿注文情報.料金プランＩＤ
     *
     * @mbg.generated
     */
    public void set料金プランｉｄ(String 料金プランｉｄ) {
        this.料金プランｉｄ = 料金プランｉｄ == null ? null : 料金プランｉｄ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.注文種別ＩＤ
     *
     * @return the value of Ｔ＿注文情報.注文種別ＩＤ
     *
     * @mbg.generated
     */
    public String get注文種別ｉｄ() {
        return 注文種別ｉｄ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.注文種別ＩＤ
     *
     * @param 注文種別ｉｄ the value for Ｔ＿注文情報.注文種別ＩＤ
     *
     * @mbg.generated
     */
    public void set注文種別ｉｄ(String 注文種別ｉｄ) {
        this.注文種別ｉｄ = 注文種別ｉｄ == null ? null : 注文種別ｉｄ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.オラクルオーダーＩＤ
     *
     * @return the value of Ｔ＿注文情報.オラクルオーダーＩＤ
     *
     * @mbg.generated
     */
    public String getオラクルオーダーｉｄ() {
        return オラクルオーダーｉｄ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.オラクルオーダーＩＤ
     *
     * @param オラクルオーダーｉｄ the value for Ｔ＿注文情報.オラクルオーダーＩＤ
     *
     * @mbg.generated
     */
    public void setオラクルオーダーｉｄ(String オラクルオーダーｉｄ) {
        this.オラクルオーダーｉｄ = オラクルオーダーｉｄ == null ? null : オラクルオーダーｉｄ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.見積日
     *
     * @return the value of Ｔ＿注文情報.見積日
     *
     * @mbg.generated
     */
    public String get見積日() {
        return 見積日;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.見積日
     *
     * @param 見積日 the value for Ｔ＿注文情報.見積日
     *
     * @mbg.generated
     */
    public void set見積日(String 見積日) {
        this.見積日 = 見積日 == null ? null : 見積日.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.ＦＪ料金表適用日
     *
     * @return the value of Ｔ＿注文情報.ＦＪ料金表適用日
     *
     * @mbg.generated
     */
    public String getＦｊ料金表適用日() {
        return ｆｊ料金表適用日;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.ＦＪ料金表適用日
     *
     * @param ｆｊ料金表適用日 the value for Ｔ＿注文情報.ＦＪ料金表適用日
     *
     * @mbg.generated
     */
    public void setＦｊ料金表適用日(String ｆｊ料金表適用日) {
        this.ｆｊ料金表適用日 = ｆｊ料金表適用日 == null ? null : ｆｊ料金表適用日.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.ＯＲＡＣＬＥ料金表適用日
     *
     * @return the value of Ｔ＿注文情報.ＯＲＡＣＬＥ料金表適用日
     *
     * @mbg.generated
     */
    public String getＯｒａｃｌｅ料金表適用日() {
        return ｏｒａｃｌｅ料金表適用日;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.ＯＲＡＣＬＥ料金表適用日
     *
     * @param ｏｒａｃｌｅ料金表適用日 the value for Ｔ＿注文情報.ＯＲＡＣＬＥ料金表適用日
     *
     * @mbg.generated
     */
    public void setＯｒａｃｌｅ料金表適用日(String ｏｒａｃｌｅ料金表適用日) {
        this.ｏｒａｃｌｅ料金表適用日 = ｏｒａｃｌｅ料金表適用日 == null ? null : ｏｒａｃｌｅ料金表適用日.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.コメント
     *
     * @return the value of Ｔ＿注文情報.コメント
     *
     * @mbg.generated
     */
    public String getコメント() {
        return コメント;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.コメント
     *
     * @param コメント the value for Ｔ＿注文情報.コメント
     *
     * @mbg.generated
     */
    public void setコメント(String コメント) {
        this.コメント = コメント == null ? null : コメント.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.適用開始希望日
     *
     * @return the value of Ｔ＿注文情報.適用開始希望日
     *
     * @mbg.generated
     */
    public String get適用開始希望日() {
        return 適用開始希望日;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.適用開始希望日
     *
     * @param 適用開始希望日 the value for Ｔ＿注文情報.適用開始希望日
     *
     * @mbg.generated
     */
    public void set適用開始希望日(String 適用開始希望日) {
        this.適用開始希望日 = 適用開始希望日 == null ? null : 適用開始希望日.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.特別値引フラグ
     *
     * @return the value of Ｔ＿注文情報.特別値引フラグ
     *
     * @mbg.generated
     */
    public String get特別値引フラグ() {
        return 特別値引フラグ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.特別値引フラグ
     *
     * @param 特別値引フラグ the value for Ｔ＿注文情報.特別値引フラグ
     *
     * @mbg.generated
     */
    public void set特別値引フラグ(String 特別値引フラグ) {
        this.特別値引フラグ = 特別値引フラグ == null ? null : 特別値引フラグ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.開始日＿実績
     *
     * @return the value of Ｔ＿注文情報.開始日＿実績
     *
     * @mbg.generated
     */
    public String get開始日＿実績() {
        return 開始日＿実績;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.開始日＿実績
     *
     * @param 開始日＿実績 the value for Ｔ＿注文情報.開始日＿実績
     *
     * @mbg.generated
     */
    public void set開始日＿実績(String 開始日＿実績) {
        this.開始日＿実績 = 開始日＿実績 == null ? null : 開始日＿実績.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.終了日＿実績
     *
     * @return the value of Ｔ＿注文情報.終了日＿実績
     *
     * @mbg.generated
     */
    public String get終了日＿実績() {
        return 終了日＿実績;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.終了日＿実績
     *
     * @param 終了日＿実績 the value for Ｔ＿注文情報.終了日＿実績
     *
     * @mbg.generated
     */
    public void set終了日＿実績(String 終了日＿実績) {
        this.終了日＿実績 = 終了日＿実績 == null ? null : 終了日＿実績.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.最大開始日＿実績
     *
     * @return the value of Ｔ＿注文情報.最大開始日＿実績
     *
     * @mbg.generated
     */
    public String get最大開始日＿実績() {
        return 最大開始日＿実績;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.最大開始日＿実績
     *
     * @param 最大開始日＿実績 the value for Ｔ＿注文情報.最大開始日＿実績
     *
     * @mbg.generated
     */
    public void set最大開始日＿実績(String 最大開始日＿実績) {
        this.最大開始日＿実績 = 最大開始日＿実績 == null ? null : 最大開始日＿実績.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.ユーザＩＤ
     *
     * @return the value of Ｔ＿注文情報.ユーザＩＤ
     *
     * @mbg.generated
     */
    public String getユーザｉｄ() {
        return ユーザｉｄ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.ユーザＩＤ
     *
     * @param ユーザｉｄ the value for Ｔ＿注文情報.ユーザＩＤ
     *
     * @mbg.generated
     */
    public void setユーザｉｄ(String ユーザｉｄ) {
        this.ユーザｉｄ = ユーザｉｄ == null ? null : ユーザｉｄ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.ＰＡＡＳ連携済フラグ
     *
     * @return the value of Ｔ＿注文情報.ＰＡＡＳ連携済フラグ
     *
     * @mbg.generated
     */
    public String getＰａａｓ連携済フラグ() {
        return ｐａａｓ連携済フラグ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.ＰＡＡＳ連携済フラグ
     *
     * @param ｐａａｓ連携済フラグ the value for Ｔ＿注文情報.ＰＡＡＳ連携済フラグ
     *
     * @mbg.generated
     */
    public void setＰａａｓ連携済フラグ(String ｐａａｓ連携済フラグ) {
        this.ｐａａｓ連携済フラグ = ｐａａｓ連携済フラグ == null ? null : ｐａａｓ連携済フラグ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.請求依頼抽出済フラグ
     *
     * @return the value of Ｔ＿注文情報.請求依頼抽出済フラグ
     *
     * @mbg.generated
     */
    public String get請求依頼抽出済フラグ() {
        return 請求依頼抽出済フラグ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.請求依頼抽出済フラグ
     *
     * @param 請求依頼抽出済フラグ the value for Ｔ＿注文情報.請求依頼抽出済フラグ
     *
     * @mbg.generated
     */
    public void set請求依頼抽出済フラグ(String 請求依頼抽出済フラグ) {
        this.請求依頼抽出済フラグ = 請求依頼抽出済フラグ == null ? null : 請求依頼抽出済フラグ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.申込請書発行日
     *
     * @return the value of Ｔ＿注文情報.申込請書発行日
     *
     * @mbg.generated
     */
    public String get申込請書発行日() {
        return 申込請書発行日;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.申込請書発行日
     *
     * @param 申込請書発行日 the value for Ｔ＿注文情報.申込請書発行日
     *
     * @mbg.generated
     */
    public void set申込請書発行日(String 申込請書発行日) {
        this.申込請書発行日 = 申込請書発行日 == null ? null : 申込請書発行日.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.論理削除フラグ
     *
     * @return the value of Ｔ＿注文情報.論理削除フラグ
     *
     * @mbg.generated
     */
    public String get論理削除フラグ() {
        return 論理削除フラグ;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.論理削除フラグ
     *
     * @param 論理削除フラグ the value for Ｔ＿注文情報.論理削除フラグ
     *
     * @mbg.generated
     */
    public void set論理削除フラグ(String 論理削除フラグ) {
        this.論理削除フラグ = 論理削除フラグ == null ? null : 論理削除フラグ.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.登録日時
     *
     * @return the value of Ｔ＿注文情報.登録日時
     *
     * @mbg.generated
     */
    public Date get登録日時() {
        return 登録日時;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.登録日時
     *
     * @param 登録日時 the value for Ｔ＿注文情報.登録日時
     *
     * @mbg.generated
     */
    public void set登録日時(Date 登録日時) {
        this.登録日時 = 登録日時;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.登録ユーザー
     *
     * @return the value of Ｔ＿注文情報.登録ユーザー
     *
     * @mbg.generated
     */
    public String get登録ユーザー() {
        return 登録ユーザー;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.登録ユーザー
     *
     * @param 登録ユーザー the value for Ｔ＿注文情報.登録ユーザー
     *
     * @mbg.generated
     */
    public void set登録ユーザー(String 登録ユーザー) {
        this.登録ユーザー = 登録ユーザー == null ? null : 登録ユーザー.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.更新日時
     *
     * @return the value of Ｔ＿注文情報.更新日時
     *
     * @mbg.generated
     */
    public Date get更新日時() {
        return 更新日時;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.更新日時
     *
     * @param 更新日時 the value for Ｔ＿注文情報.更新日時
     *
     * @mbg.generated
     */
    public void set更新日時(Date 更新日時) {
        this.更新日時 = 更新日時;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column Ｔ＿注文情報.更新ユーザー
     *
     * @return the value of Ｔ＿注文情報.更新ユーザー
     *
     * @mbg.generated
     */
    public String get更新ユーザー() {
        return 更新ユーザー;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column Ｔ＿注文情報.更新ユーザー
     *
     * @param 更新ユーザー the value for Ｔ＿注文情報.更新ユーザー
     *
     * @mbg.generated
     */
    public void set更新ユーザー(String 更新ユーザー) {
        this.更新ユーザー = 更新ユーザー == null ? null : 更新ユーザー.trim();
    }
}