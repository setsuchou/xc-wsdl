package k5oraclerds.subsys.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.common.Global;
import k5oraclerds.subsys.common.Constants.ORACConstants;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.ORAC0030Service;
import k5oraclerds.subsys.webform.ORAC0020Form;
import k5oraclerds.subsys.webform.ORAC0030Form;

@Controller
@RequestMapping(value = "/ORAC0030Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0030Controller {

	private static Logger logger = LoggerFactory.getLogger(ORAC0030Controller.class);

	@Resource
	private ORAC0030Service ORAC0030Service;

	// エラーメッセージ
	private List<String> errList;

	@RequestMapping(value = "/init", method = RequestMethod.GET)
	public String init(@ModelAttribute("ORAC0030Form") ORAC0030Form ORAC0030Form, Model model) {

		logger.info("メソッド" + "init" + "：開始");

		// 遷移元[契約検索画面ORAC0020Form]からサービス申込番号、K5契約番号を引継ぎ
		Ｔ＿契約情報 keiyakuJohoForm;
		if (ORAC0030Form.getKeiyakuJoho() == null) {
			ORAC0030Form = new ORAC0030Form();
			// フォームの初期化を行う
			// 契約情報を初期化する
			keiyakuJohoForm = new Ｔ＿契約情報();

		} else {
			Ｔ＿契約情報 keiyakuJoho = ORAC0030Form.getKeiyakuJoho();
			keiyakuJohoForm = ORAC0030Service.selectKeiyakuJohoByPrimaryKey(keiyakuJoho.getＫ５契約番号(),
					keiyakuJoho.getサービス申込番号());
		}
		ORAC0030Form.setKeiyakuJoho(keiyakuJohoForm);

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0030Form);

		model.addAttribute("ORAC0030Form", ORAC0030Form);

		logger.info("メソッド" + "init" + "：終了");

		return "ORAC0030Form";
	}

	/**
	 *
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("ORAC0030Form") ORAC0030Form ORAC0030Form, BindingResult result,
			Map<String, Object> map, Model model, @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form) {

		// チェックエラー発生時、更新処理を行わない
		if (result.hasErrors()) {
			result.getAllErrors().get(0).getCode();
			return "ORAC0030Form";
		}

		// 複合チェック
		if (compositeCheck(ORAC0030Form, map)) {
			model.addAttribute("ORAC0030Form", ORAC0030Form);
			return "ORAC0030Form";
		}

		// 画面から契約情報を取得する
		Ｔ＿契約情報 keiyakuJoho = ORAC0030Form.getKeiyakuJoho();

		// レコードが存在しない場合は、
		// エラーメッセージ[E010]をダイアログ表示し、OKボタン押下後は、更新ボタン押下前の状態に戻る。
		Ｔ＿契約情報 keiyakuJohoOld = ORAC0030Service.selectKeiyakuJohoByPrimaryKey(keiyakuJoho.getＫ５契約番号(),
				keiyakuJoho.getサービス申込番号());

		if ((keiyakuJohoOld != null) && ORACConstants.DEL_FLAG_DELETE.equals(keiyakuJohoOld.get論理削除フラグ())) {
			keiyakuJoho.set論理削除フラグ("0");
			keiyakuJoho.set更新ユーザー(Global.getConfig("USER"));
			keiyakuJoho.set登録ユーザー(Global.getConfig("USER"));
			ORAC0030Service.updateByPrimaryKey(keiyakuJoho);
			map.put("Message", Global.getMsg("I006"));
		} else {
			errList = new ArrayList<String>();
			errList.add(Global.getMsg("E010"));
			map.put("ErrorMessage", errList);
			model.addAttribute("ORAC0030Form", ORAC0030Form);
			return "ORAC0030Form";
		}

		return "ORAC0030Form";
	}

	@RequestMapping(value = "/modoru", method = RequestMethod.GET)
	public String modoru(@ModelAttribute("ORAC0030Form") ORAC0030Form ORAC0030Form, Model model) {
		model.addAttribute("ORAC0020FormJson", ORAC0030Form.getORAC0020FormJson());
		return "forward:/ORAC0020Form/modoruByKeiyakuCondition";
	}

	/**
	 * ORAC0030画面上の料金プランプルダウンリストの初期化を行う
	 *
	 * @param ORAC0030Form
	 */
	private void initPullDownList(ORAC0030Form ORAC0030Form) {

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0030Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0030Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

	};

	/**
	 * 複合チェックメソッド
	 *
	 * @param condition
	 * @param map
	 * @return
	 */
	private Boolean compositeCheck(ORAC0030Form ORAC0030Form, Map<String, Object> map) {
		errList = new ArrayList<String>();

		Ｔ＿契約情報 keiyakuJoho = ORAC0030Form.getKeiyakuJoho();

		// サービス終了日＜サービス開始日の場合はエラー
		if (keiyakuJoho.getサービス終了日().compareTo(keiyakuJoho.getサービス開始日()) > 0) {
			errList.add(Global.getMsg("E018"));
			map.put("ErrorMessage", errList);
		}

		// 環境削除日＜サービス終了日の場合はエラー
		if (keiyakuJoho.get環境削除日().compareTo(keiyakuJoho.getサービス終了日()) < 0) {
			errList.add(Global.getMsg("E019"));
			map.put("ErrorMessage", errList);
		}

		// Meteredの場合、キャンセル依頼日＞サービス終了日の場合はエラー
		if (ORACConstants.RATE_PLAN_METERED_ID.equals(keiyakuJoho.get料金プランｉｄ())
				&& keiyakuJoho.get環境削除日().compareTo(keiyakuJoho.getサービス終了日()) > 0) {
			errList.add(Global.getMsg("E020"));
			map.put("ErrorMessage", errList);
		}

		// Meteredの場合、キャンセル依頼日＞サービス終了日の場合はエラー
		if (ORACConstants.RATE_PLAN_NON_METERED_ID.equals(keiyakuJoho.get料金プランｉｄ())
				&& keiyakuJoho.getロスト処理依頼日().compareTo(keiyakuJoho.get環境削除日()) > 0) {
			errList.add(Global.getMsg("E020"));
			map.put("ErrorMessage", errList);
		}

		if (errList.size() > 0) {
			return true;
		}
		return false;
	}
}
