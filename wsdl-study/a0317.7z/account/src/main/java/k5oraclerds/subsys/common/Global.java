package k5oraclerds.subsys.common;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Maps;

import k5oraclerds.subsys.common.utils.PropertiesLoader;

/**
 * グローバル情報を設定するクラス
 *
 * @author setsuchou
 * @version 2017-03-06
 */

public class Global {

	/**
	 * インスタンスを生成する
	 */
	private static Global global = new Global();

	/**
	 * グロバール全領域に保持
	 */
	private static Map<String, String> map = Maps.newHashMap();

	/**
	 * ロード対象
	 */
	private static PropertiesLoader loader = new PropertiesLoader("subsys.properties");

	/**
	 *真偽を定義
	 */
	public static final String TRUE = "true";
	public static final String FALSE = "false";


	/**
	 * インスタンスを取得する
	 */
	public static Global getInstance() {
		return global;
	}

	/**
	 * 設定を取得する
	 *
	 */
	public static String getConfig(String key) {
		String value = map.get(key);
		if (value == null) {
			value = loader.getProperty(key);
			map.put(key, value != null ? value : StringUtils.EMPTY);
		}
		return value;
	}

	/**
	 * メッセージを取得する
	 *
	 */
	public static String getMsg(String key) {
		String value = map.get(key);
		if (value == null) {
			value = loader.getProperty(key);
			map.put(key, value != null ? value : StringUtils.EMPTY);
		}
		return value;
	}

	/**
	 * 定数を取得する
	 *
	 */
	public static Object getConst(String field) {
		try {
			return Global.class.getField(field).get(null);
		} catch (Exception e) {
		}
		return null;
	}
}
