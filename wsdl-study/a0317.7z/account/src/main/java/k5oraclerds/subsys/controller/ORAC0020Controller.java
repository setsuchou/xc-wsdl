package k5oraclerds.subsys.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import k5oraclerds.subsys.common.Global;
import k5oraclerds.subsys.common.Constants.ORACConstants;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.service.ORAC0020Service;
import k5oraclerds.subsys.webform.ORAC0020Form;
import k5oraclerds.subsys.webform.ORAC0030Form;
import k5oraclerds.subsys.webform.ORAC0040Form;
import k5oraclerds.subsys.webform.ORAC0060Form;
import k5oraclerds.subsys.webform.ORAC0080Form;
import k5oraclerds.subsys.webform.component.ORAC0020FormCondition;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

@Controller
@RequestMapping(value = "/ORAC0020Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0020Controller {

	private static Logger logger = LoggerFactory.getLogger(ORAC0020Controller.class);

	@Resource
	private ORAC0020Service ORAC0020Service;

	@Autowired
	private HttpServletRequest request;

	// エラーメッセージ
	private List<String> errList;

	// TODO modoru return "welcome";
	@RequestMapping(value = "/init", method = RequestMethod.GET)
	public String init(@ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, Model model,
			HttpServletResponse response) throws Exception {

		// 権限チェック
//		if(!authorityCheck(request)){
//
//			Exception ex = new Exception("ＰａａＳポータル運営者ではありません");
//			throw ex;
//		}

		// 画面フォームの初期化を行う
		ORAC0020Form = new ORAC0020Form();
		initForm(ORAC0020Form);
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// PrintWriter out = response.getWriter();
		// out.append("<script>parent.alert('サブメニューへようこそ');</script>");
		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/searchByChumonCondition", method = RequestMethod.GET)
	public String searchByChumonCondition(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form
			,@ModelAttribute("ORAC0020FormJson") String ORAC0020FormJson,
			BindingResult result, Map<String, Object> map, Model model) throws Exception {

		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 複合チェック
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面明細部を取得する
		List<ORAC0020FormMeisai> meisaiList = ORAC0020Service.selectMeisaiByChumonCondition(
				condition.getSabisuMoshikomiBango(), condition.getK5keiyakubango(), condition.getRemban(),
				condition.getAidenteiteiDmein(), condition.getSabisushuryoBiFrom(), condition.getSabisushuryoBiTo(),
				condition.getTekiyokibobiFrom(), condition.getTekiyokibobiTo());
		ORAC0020Form.setMeisaiList(meisaiList);

		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/modoruByChumonCondition", method = RequestMethod.GET)
	public String modoruByChumonCondition(@ModelAttribute("ORAC0020FormJson") String ORAC0020FormJson,
			Map<String, Object> map, Model model) throws Exception {

		ORAC0020Form ORAC0020Form = new ORAC0020Form();

		if(ORAC0020FormJson != null && !ORAC0020FormJson.equals("")){
			ORAC0020Form = paresJson(ORAC0020FormJson);
		}
		ORAC0020Form.setTanyi("chumonTanyi");

		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/searchByKeiyakuCondition", method = RequestMethod.POST)
	public String searchByKeiyakuCondition(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form,
			BindingResult result, Map<String, Object> map, Model model) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 画面明細部を取得する

		List<ORAC0020FormMeisai> meisaiList = ORAC0020Service.selectMeisaiByKeiyakuCondition(
				condition.getSabisuMoshikomiBango(), condition.getK5keiyakubango(), condition.getAidenteiteiDmein(),
				condition.getSabisushuryoBiFrom(), condition.getSabisushuryoBiTo());
		ORAC0020Form.setMeisaiList(meisaiList);
		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/modoruByKeiyakuCondition", method = RequestMethod.GET)
	public String modoruByKeiyakuCondition(@ModelAttribute("ORAC0020FormJson") String ORAC0020FormJson,
			Map<String, Object> map, Model model) throws Exception {

		ORAC0020Form ORAC0020Form = new ORAC0020Form();

		if(ORAC0020FormJson != null && !ORAC0020FormJson.equals("")){
			ORAC0020Form = paresJson(ORAC0020FormJson);
		}
		ORAC0020Form.setTanyi("keiyakuTanyi");

		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// ORAC0020画面へ遷移する
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/updateForKeiyaku", method = RequestMethod.POST)
	public String updateForKeiyaku(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form,
			BindingResult result, Map<String, Object> map, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約検索画面FORMを定義する
		ORAC0030Form ORAC0030Form = new ORAC0030Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
			keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
		}
		ORAC0030Form.setKeiyakuJoho(keiyakuJoho);

		// ORAC0020Formのjsonを保存する
		ORAC0030Form.setORAC0020FormJson(creatJson(ORAC0020Form));

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0030Form", ORAC0030Form);

		// ORAC0020画面へ遷移する
		return "redirect:/ORAC0030Form/init";
		// return "forward:/ORAC0030Form/init";

	}

	@RequestMapping(value = "/tyumonJohoTuika", method = RequestMethod.POST)
	public String tyumonJohoTuika(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form,
			BindingResult result, Map<String, Object> map, Model model, RedirectAttributes redirectAttributes)
					throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約追加画面FORMを定義する
		ORAC0040Form ORAC0040Form = new ORAC0040Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
			keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
		}
		ORAC0040Form.setKeiyakuJoho(keiyakuJoho);

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0040Form", ORAC0040Form);

		// ORAC0040画面へ遷移する
		return "redirect:/ORAC0040Form/init";
		// return "forward:/ORAC0040Form/init";

	}

	@RequestMapping(value = "/tyumonJohoSansyo", method = RequestMethod.GET)
	public String tyumonJohoSansyo(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form,
			BindingResult result, Map<String, Object> map, Model model, RedirectAttributes redirectAttributes)
					throws Exception {

		// 検索単位に注文単位を設定する
		ORAC0020Form.setTanyi("chumonTanyi");

		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約検索画面FORMを定義する
		ORAC0060Form ORAC0060Form = new ORAC0060Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		Ｔ＿注文情報 chumonJoho = new Ｔ＿注文情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			if (meisai.getCheckboxStatus()) {
				keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
				keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
				chumonJoho.set連番(meisai.getRemban());
			}
		}
		ORAC0060Form.setChumonjoho(chumonJoho);
		ORAC0060Form.setKeiyakuJoho(keiyakuJoho);

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0060Form", ORAC0060Form);

		//参照判断:1.参照2.参照しない.
		redirectAttributes.addFlashAttribute("sansyoAttr", "1");

		// ORAC0020画面へ遷移する
		return "redirect:/ORAC0060Form/init";
		// return "forward:/ORAC0040Form/init";

	}

	@RequestMapping(value = "/tyumonJohoKoushin", method = RequestMethod.POST)
	public String tyumonJohoKoushin(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form,
			BindingResult result, Map<String, Object> map, Model model, RedirectAttributes redirectAttributes)
					throws Exception {

		// 検索単位に契約単位を設定する
		ORAC0020Form.setTanyi("keiyakuTanyi");

		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約検索画面FORMを定義する
		ORAC0060Form ORAC0060Form = new ORAC0060Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		Ｔ＿注文情報 chumonJoho = new Ｔ＿注文情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			if (meisai.getCheckboxStatus()) {
				keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
				keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
				chumonJoho.set連番(meisai.getRemban());
			}
		}
		ORAC0060Form.setChumonjoho(chumonJoho);
		ORAC0060Form.setKeiyakuJoho(keiyakuJoho);

		// ORAC0020Formのjsonを保存する
		ORAC0060Form.setORAC0020FormJson(creatJson(ORAC0020Form));

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0060Form", ORAC0060Form);
		model.addAttribute("ORAC0060Form", ORAC0060Form);
		//参照判断:1.参照2.参照しない.
		redirectAttributes.addFlashAttribute("sansyoAttr", "0");
		model.addAttribute("sansyoAttr", "0");

		// ORAC0020画面へ遷移する
		return "redirect:/ORAC0060Form/init";
		// return "forward:/ORAC0040Form/init";

	}

	@RequestMapping(value = "/paygTouroku", method = RequestMethod.POST)
	public String paygTouroku(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, BindingResult result,
			Map<String, Object> map, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約検索画面FORMを定義する
		ORAC0080Form ORAC0080Form = new ORAC0080Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
			keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
		}
		ORAC0080Form.setKeiyakuJoho(keiyakuJoho);

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "redirect:/ORAC0080Form/init";
		// return "forward:/ORAC0080Form/init";
	}

	@RequestMapping(value = "/paygSansyo", method = RequestMethod.GET)
	public String paygSansyo(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, BindingResult result,
			Map<String, Object> map, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 契約検索画面FORMを定義する
		ORAC0080Form ORAC0080Form = new ORAC0080Form();
		Ｔ＿契約情報 keiyakuJoho = new Ｔ＿契約情報();
		List<ORAC0020FormMeisai> seletedMeisai = ORAC0020Form.getSeletedMeisai();
		for (ORAC0020FormMeisai meisai : seletedMeisai) {
			keiyakuJoho.setサービス申込番号(meisai.getSabisuMoshikomiBango());
			keiyakuJoho.setＫ５契約番号(meisai.getK5KeiyakuBango());
		}
		ORAC0080Form.setKeiyakuJoho(keiyakuJoho);

		// 画面フォーム条件をセットする
		redirectAttributes.addFlashAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "redirect:/ORAC0080Form/init";
		// return "forward:/ORAC0040Form/init";
	}

	@RequestMapping(value = "/sakujoForCheck", method = RequestMethod.POST)
	public String sakujoForCheck(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, BindingResult result,
			Map<String, Object> map, Model model) throws Exception {

		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		if (result.hasErrors()) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 画面上既存条件部を取得する
		ORAC0020FormCondition condition = ORAC0020Form.getCondition();

		// 入力内容のチェックを行う
		if (compositeCheck(condition, map)) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		if (multiCheck(ORAC0020Form, map, "updateForKeiyaku")) {
			model.addAttribute("ORAC0020Form", ORAC0020Form);
			return "ORAC0020Form";
		}

		// 削除確認メッセージ[I003]をダイアログ表示する。
		map.put("sakujoMessage", Global.getMsg("I003"));

		// 画面フォーム条件をセットする
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		// ORAC0020画面に戻す
		return "ORAC0020Form";
	}

	@RequestMapping(value = "/sakujo", method = RequestMethod.POST)
	public String sakujo(@Valid @ModelAttribute("ORAC0020Form") ORAC0020Form ORAC0020Form, BindingResult result,
			Map<String, Object> map, Model model, RedirectAttributes redirectAttributes) throws Exception {

		ORAC0020FormCondition condition = ORAC0020Form.getCondition();
		List<ORAC0020FormMeisai> meisaiList = ORAC0020Form.getMeisaiList();
		List<ORAC0020FormMeisai> seletedMeisai = new ArrayList<>();

		// 画面明細をループする
		for (ORAC0020FormMeisai orac0020FormMeisai : meisaiList) {
			if (orac0020FormMeisai.getCheckboxStatus()) {
				seletedMeisai.add(orac0020FormMeisai);
				if (isExist(condition.getK5keiyakubango(), condition.getSabisuMoshikomiBango(), condition.getRemban(),
						orac0020FormMeisai.getChumonShubetsuId())) {

					// レコードが既に存在しない場合は、エラーメッセージ[E010]をダイアログ表示し、
					// OKボタン押下後は、削除ボタン押下前の状態に戻る。
					map.put("sakujoMessage", Global.getMsg("E010"));

					// ORAC0020画面に戻す
					return "ORAC0020Form";
				}
			}
		}

		// 該当するレコードを削除する
		ORAC0020Service.sakujo(condition.getK5keiyakubango(), condition.getSabisuMoshikomiBango(),
				condition.getRemban());

		// ORAC0020画面に戻す
		return "ORAC0020Form";
	}

	/**
	 *
	 * @return
	 */
	@RequestMapping(value = "/modoru", method = RequestMethod.GET)
	public String modoru(Model model) {
		return "../../ORAC0000Form";
	}

	/**
	 * 契約情報、注文情報、注文明細情報レコードの存在性をチェックするメソッド。
	 *
	 * @param meisai
	 * @return
	 */
	private Boolean isExist(String K5KeiyakuBango, String sabisuMoshikomiBango, Short remban, String ChumonShubetsuId) {

		// 契約情報の存在性をチェックする
		// 注文種別「New」の場合、選択されたFJ注文番号（サービス申込番号＋連番）に紐付くレコードを取得する
		if ("01".equals(ChumonShubetsuId)) {
			Ｔ＿契約情報 keiyakuJoho = ORAC0020Service.getＴ＿契約情報ByPrimaryKey(K5KeiyakuBango,
					sabisuMoshikomiBango);
			if (keiyakuJoho != null) {
				return true;
			}
		}

		// 注文情報の存在性をチェックする
		Ｔ＿注文情報 chumonJoho = ORAC0020Service.selectByPrimaryKeyChumonJoho(K5KeiyakuBango, sabisuMoshikomiBango,
				remban);
		if (chumonJoho != null) {
			return true;
		}

		// 注文明細情報の存在性をチェックする
		List<Ｔ＿注文明細> chumonMeisaiList = ORAC0020Service.selectChomonListByKeys(K5KeiyakuBango, sabisuMoshikomiBango,
				remban);
		if (chumonMeisaiList != null && chumonMeisaiList.size() > 0) {
			return true;
		}

		return false;
	}

	/**
	 * 画面初期化時、フォームインスタンスを生成する。
	 *
	 * @param ORAC0020Form
	 */
	private void initForm(ORAC0020Form ORAC0020Form) {

		// 検索単位ラジオのデフォルト値を設定する
		ORAC0020Form.setTanyi("chumonTanyi");

		// 画面条件を初期化する
		ORAC0020FormCondition condition = new ORAC0020FormCondition();
		ORAC0020Form.setCondition(condition);

		// 料金プラン、注文種別プルダウンリストの初期化を行う
		initPullDownList(ORAC0020Form);
	}

	/**
	 * ORAC0020画面上の料金プラン、注文種別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0020Form
	 */
	private void initPullDownList(ORAC0020Form ORAC0020Form) {

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = ORAC0020Service.selectAllShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		// 商品型が存在する場合、フォーム情報に設定する
		if (shohinGatas.size() > 0) {
			ORAC0020Form.setShohinGataMap(Collections.unmodifiableMap(shohinGatas));
		}

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0020Service.selectAllRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0020Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuMap = ORAC0020Service.selectAllChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuMap) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}

		// 注文種別が存在する場合、フォーム情報に設定する
		if (chumonShubetsus.size() > 0) {
			ORAC0020Form.setChumonShubetsuMap(Collections.unmodifiableMap(chumonShubetsus));
		}
	}

	/**
	 * 複合チェックメソッド
	 *
	 * @param condition
	 * @param map
	 * @return
	 */
	private Boolean compositeCheck(ORAC0020FormCondition condition, Map<String, Object> map) {
		errList = new ArrayList<String>();

		// 検索ボタン押下時に、検索条件が一つも指定されていない場合はエラー
		if (StringUtils.isEmpty(condition.getK5keiyakubango()) && StringUtils.isEmpty(condition.getAidenteiteiDmein())
				&& StringUtils.isEmpty(condition.getSabisuMoshikomiBango())
				&& StringUtils.isEmpty(condition.getSabisushuryoBiFrom())
				&& StringUtils.isEmpty(condition.getSabisushuryoBiFrom())
				&& StringUtils.isEmpty(condition.getTekiyokibobiFrom())
				&& StringUtils.isEmpty(condition.getTekiyokibobiTo())) {
			errList.add(Global.getMsg("E022"));
			map.put("ErrorMessage", errList);
		}

		// 検索ボタン押下時に、サービス終了日（FROM）＞サービス終了日（TO）の場合はエラー
		if (condition.getSabisushuryoBiFrom().compareToIgnoreCase(condition.getSabisushuryoBiTo()) == 1) {
			errList.add(Global.getMsg("E006"));
			map.put("ErrorMessage", errList);
		}

		// 検索ボタン押下時に、適用開始希望日（FROM）＞適用開始希望日（TO）の場合はエラー
		if (condition.getTekiyokibobiFrom().compareToIgnoreCase(condition.getTekiyokibobiTo()) == 1) {
			errList.add(Global.getMsg("E006"));
			map.put("ErrorMessage", errList);
		}

		if (errList.size() > 0) {
			return true;
		}
		return false;
	}

	/**
	 * チェックボックス選択肢のチェック チェックボックスが選択されていない場合はエラー 複数のチェックボックスが選択されている場合はエラー
	 *
	 * @param condition
	 * @param map
	 * @return
	 */
	private Boolean multiCheck(ORAC0020Form ORAC0020Form, Map<String, Object> map, String methodName) {
		errList = new ArrayList<String>();

		List<ORAC0020FormMeisai> meisaiList = ORAC0020Form.getMeisaiList();
		List<ORAC0020FormMeisai> seletedMeisai = new ArrayList<ORAC0020FormMeisai>();
		// 明細データをループして判断する
		int count = 0;
		String sabisuMoshikomiBangoNew = "";
		for (ORAC0020FormMeisai meisai : meisaiList) {

			if (meisai.getCheckboxStatus()) {
				seletedMeisai.add(meisai);

				// ループにカウントを行う
				count = count + 1;
				if (ORACConstants.ORDER_TYPE_NEW.equals(meisai.getChumonShubetsuMei())) {
					sabisuMoshikomiBangoNew = meisai.getSabisuMoshikomiBango();
				}
			}

			// 削除ボタン押下時に、注文種別「New」が選択されている場合、同一サービス申込番号で注文種別「New」
			// 以外の選択されていない注文種別が存在する場合はエラー
			if ((!StringUtils.isBlank(sabisuMoshikomiBangoNew))
					&& sabisuMoshikomiBangoNew.equals(meisai.getSabisuMoshikomiBango())
					&& (!ORACConstants.ORDER_TYPE_NEW.equals(meisai.getChumonShubetsuMei()))) {
				errList.add(Global.getMsg("E009"));
				map.put("ErrorMessage", errList);
				return true;
			}
		}

		// 下記ボタン押下時に、チェックボックスが選択されていない場合はエラー
		// ・契約情報更新、注文情報追加、注文情報参照、注文情報更新、PAYG参照、PAYG登録、削除
		if (count == 0) {
			errList.add(Global.getMsg("E007"));
			map.put("ErrorMessage", errList);
			return true;
		}

		// 下記ボタン押下時に、複数のチェックボックスが選択されている場合はエラー
		// ・契約情報更新、注文情報追加、注文情報参照、注文情報更新、PAYG参照、PAYG登録
		if (count > 1) {
			if (!ORACConstants.ORDER_SERACH＿PAGE＿BUTTON_NAME_DELETE.equals(methodName)) {
				errList.add(Global.getMsg("E008"));
				map.put("ErrorMessage", errList);
				return true;
			}
		}

		// チェックエラーなければ選択肢を揃える
		if (seletedMeisai.size() > 0) {
			ORAC0020Form.setSeletedMeisai(seletedMeisai);
		}

		// デフォルド値を設定する
		return false;
	}

	public String creatJson(ORAC0020Form ORAC0020Form){
		String strJson = "";
		strJson = strJson
				+ ORAC0020Form.getTanyi() //検索単位
				+ ":"
				+ ORAC0020Form.getCondition().getSabisuMoshikomiBango()	//FJ注文番号
				+ ":"
				+ ORAC0020Form.getCondition().getRemban()				//連番
				+ ":"
				+ ORAC0020Form.getCondition().getK5keiyakubango()		//K5契約番号
				+ ":"
				+ ORAC0020Form.getCondition().getAidenteiteiDmein()		//アイデンティティ・ドメイン名
				+ ":"
				+ ORAC0020Form.getCondition().getSabisushuryoBiFrom()	//サービス終了日From
				+ ":"
				+ ORAC0020Form.getCondition().getSabisushuryoBiTo()		//サービス終了日To
				+ ":"
				+ ORAC0020Form.getCondition().getTekiyokibobiFrom()		//適用開始希望日From
				+ ":"
				+ ORAC0020Form.getCondition().getTekiyokibobiTo()		//適用開始希望日To
				+ ":";
		List<ORAC0020FormMeisai> meisaiList = ORAC0020Form.getMeisaiList();
		for(ORAC0020FormMeisai meisai : meisaiList){
			strJson = strJson
					+ meisai.getCheckboxStatus() 		//checkbox
					+ ";"
					+ meisai.getSabisuMoshikomiBango()	//FJ注文番号
					+ ";"
					+ meisai.getRemban()				//連番
					+ ";"
					+ meisai.getK5KeiyakuBango()		//K5契約番号
					+ ";"
					+ meisai.getAidenteiteiDomein()		//アイデンティティ・ドメイン名
					+ ";"
					+ meisai.getRyokimPuramMei()		//料金プラン
					+ ";"
					+ meisai.getSabisuShuryobi()		//サービス終了日
					+ ";"
					+ meisai.getChumonShubetsuMei()		//注文種別
					+ ";"
					+ meisai.getTekiyoKaishiKibobi()	//適用開始希望日
					+ "/";
		}

		return strJson;
	}

	public ORAC0020Form paresJson(String strJson){

		ORAC0020Form ORAC0020Form = new ORAC0020Form();

		if(strJson == null || strJson.length() == 0){
			return ORAC0020Form;
		}

		String[] conditionArray = strJson.split(":",10);
		ORAC0020FormCondition ORAC0020FormCondition = new ORAC0020FormCondition();
		ORAC0020Form.setTanyi(conditionArray[0]);	//検索単位
		ORAC0020FormCondition.setSabisuMoshikomiBango(conditionArray[1]);	//FJ注文番号
		if(!conditionArray[2].equals("null")){
			ORAC0020FormCondition.setRemban(new Short(conditionArray[2]));		//連番
		}
		ORAC0020FormCondition.setK5keiyakubango(conditionArray[3]);			//K5契約番号
		ORAC0020FormCondition.setAidenteiteiDmein(conditionArray[4]);		//アイデンティティ・ドメイン名
		ORAC0020FormCondition.setSabisushuryoBiFrom(conditionArray[5]);		//サービス終了日From
		ORAC0020FormCondition.setSabisushuryoBiTo(conditionArray[6]);		//サービス終了日To
		ORAC0020FormCondition.setTekiyokibobiFrom(conditionArray[7]);		//適用開始希望日From
		ORAC0020FormCondition.setTekiyokibobiTo(conditionArray[8]);			//適用開始希望日To

		ORAC0020Form.setCondition(ORAC0020FormCondition);
		List<ORAC0020FormMeisai> meisaiList = new ArrayList<ORAC0020FormMeisai>();
		String[] meisaiListArray = conditionArray[9].split("/");
		for(int i = 0; i < meisaiListArray.length; i++){
			String[] meisaiArray = meisaiListArray[i].split(";",9);
			ORAC0020FormMeisai meisai = new ORAC0020FormMeisai();
			//checkbox
			if(meisaiArray[0].equals("true")){
				meisai.setCheckboxStatus(true);
			}else if(meisaiArray[0].equals("false")){
				meisai.setCheckboxStatus(false);
			}
			meisai.setSabisuMoshikomiBango(meisaiArray[1]);		//FJ注文番号
			if(!meisaiArray[2].equals("null")){
				meisai.setRemban(new Short(meisaiArray[2]));		//連番
			}
			meisai.setK5KeiyakuBango(meisaiArray[3]);			//K5契約番号
			meisai.setAidenteiteiDomein(meisaiArray[4]);		//アイデンティティ・ドメイン名
			meisai.setRyokimPuramMei(meisaiArray[5]);			//料金プラン
			meisai.setSabisuShuryobi(meisaiArray[6]);			//サービス終了日
			meisai.setChumonShubetsuMei(meisaiArray[7]);		//注文種別
			meisai.setTekiyoKaishiKibobi(meisaiArray[8]);		//適用開始希望日
			meisaiList.add(meisai);
		}

		ORAC0020Form.setMeisaiList(meisaiList);

		return ORAC0020Form;

	}

	/**
	 * 権限チェックを行うクラス
	 *
	 * @param request
	 * @return
	 */
	private Boolean authorityCheck(HttpServletRequest request) {

		// ログイン時に認証OKの場合は、SSO認証連携の認証基盤より、
		// 以下の利用者情報が通知されるため、その情報（‘request.getHeader(利用者情報名)’）を取得する。

		// X-MCAC_ATTR_fjcontractuserid
		String fjcontractuserid = request.getHeader("X-MCAC_ATTR_fjcontractuserid");
		// X-MCAC_ATTR_fjuid
		String fjuid = request.getHeader("X-MCAC_ATTR_fjuid");
		// X-MCAC_ATTR_userid
		String userid = request.getHeader("X-MCAC_ATTR_userid");
		// X-MCAC_ATTR_fjroleid
		String fjroleid = request.getHeader("X-MCAC_ATTR_fjroleid");

		// ロールIDが、"000000000000004"（ＰａａＳポータル運営者）の場合、通常画面を表示する。
		// 次の処理を行う。
		if ("000000000000004".equals(fjroleid)) {
			return true;
		}

		return false;
	}
}
