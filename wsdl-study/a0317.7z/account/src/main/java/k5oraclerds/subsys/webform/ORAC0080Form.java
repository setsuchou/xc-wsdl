package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.webform.component.ORAC0080FormMeisai;

public class ORAC0080Form implements Serializable {
	private static final long serialVersionUID = 1L;

	// 契約検索画面情報
	private ORAC0020Form ORAC0020Form;

	private String jorac0020Form;

	// 契約情報
	private Ｔ＿契約情報 keiyakuJoho;

	// 画面明細
	@Valid
	private List<ORAC0080FormMeisai> tpaygMeisaiList;

	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;

	//ORAC0020FormのJson
	private String ORAC0020FormJson;

	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	/**
	 * @param keiyakuJoho
	 *            セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	/**
	 * @return tpaygMeisaiList
	 */
	public List<ORAC0080FormMeisai> getTpaygMeisaiList() {
		return tpaygMeisaiList;
	}

	/**
	 * @param tpaygMeisaiList
	 *            セットする tpaygMeisaiList
	 */
	public void setTpaygMeisaiList(List<ORAC0080FormMeisai> tpaygMeisaiList) {
		this.tpaygMeisaiList = tpaygMeisaiList;
	}

	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}

	/**
	 * @param ryokimPuranMap
	 *            セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}

	/**
	 * @return oRAC0020Form
	 */
	public ORAC0020Form getORAC0020Form() {
		return ORAC0020Form;
	}

	/**
	 * @param oRAC0020Form
	 *            セットする oRAC0020Form
	 */
	public void setORAC0020Form(ORAC0020Form oRAC0020Form) {
		ORAC0020Form = oRAC0020Form;
	}

	/**
	 * @return jorac0020Form
	 */
	public String getJorac0020Form() {
		return jorac0020Form;
	}

	/**
	 * @param jorac0020Form セットする jorac0020Form
	 */
	public void setJorac0020Form(String jorac0020Form) {
		this.jorac0020Form = jorac0020Form;
	}

	/**
	 * @return oRAC0020FormJson
	 */
	public String getORAC0020FormJson() {
		return ORAC0020FormJson;
	}

	/**
	 * @param oRAC0020FormJson セットする oRAC0020FormJson
	 */
	public void setORAC0020FormJson(String oRAC0020FormJson) {
		ORAC0020FormJson = oRAC0020FormJson;
	}


}
