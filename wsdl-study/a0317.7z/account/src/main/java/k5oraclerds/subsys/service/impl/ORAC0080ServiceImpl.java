package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｍ＿商品型Mapper;
import k5oraclerds.subsys.dao.Ｍ＿料金プランMapper;
import k5oraclerds.subsys.dao.Ｍ＿超過使用料Mapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.dao.Ｔ＿ｐａｙｇ情報Mapper;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿超過使用料;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿ｐａｙｇ情報;
import k5oraclerds.subsys.service.ORAC0080Service;

@Service("ORAC0080Service")
// @Transactional(readOnly = true)
public class ORAC0080ServiceImpl implements ORAC0080Service {

	public ORAC0080ServiceImpl() {
	}

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private Ｍ＿商品型Mapper Ｍ＿商品型Mapper;

	@Autowired
	private Ｍ＿料金プランMapper Ｍ＿料金プランMapper;

	@Autowired
	private Ｔ＿ｐａｙｇ情報Mapper Ｔ＿ｐａｙｇ情報Mapper;

	private Ｍ＿超過使用料Mapper  Ｍ＿超過使用料Mapper;

	@Override
	public Ｔ＿契約情報 selectKeiyakuJohoByPrimaryKey(String ｋ５契約番号, String サービス申込番号) {
		Ｔ＿契約情報 Ｔ＿契約情報 = Ｔ＿契約情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号);
		return Ｔ＿契約情報;
	}

	@Override
	public List<Ｔ＿ｐａｙｇ情報> selectTpaygJohoByKeys(String ｋ５契約番号, String サービス申込番号) {

		List<Ｔ＿ｐａｙｇ情報> list = Ｔ＿ｐａｙｇ情報Mapper.selectTpaygJohoByKeys(ｋ５契約番号, サービス申込番号);
		return list;
	}

	@Override
	public List<Ｍ＿商品型> getShohinGata() {

		List<Ｍ＿商品型> returnList = Ｍ＿商品型Mapper.selectAll();

		return returnList;
	}

	@Override
	public List<Ｍ＿料金プラン> getRyokimPuran() {
		List<Ｍ＿料金プラン> returnList = Ｍ＿料金プランMapper.selectAll();

		return returnList;
	}

	@Override
	public Ｍ＿商品型 getShohinKataMei(String shohinKataId, String ryokimpuranId, String nengetsu) {
		Ｍ＿商品型 shohinKata = Ｍ＿商品型Mapper.getShohinKataMei(shohinKataId, ryokimpuranId, nengetsu);
		return shohinKata;
	}

	@Override
	// @Transactional(readOnly = false)
	public int updateByPrimaryKey(Ｔ＿ｐａｙｇ情報 record) {
		return Ｔ＿ｐａｙｇ情報Mapper.updateByPrimaryKey(record);
	};

	@Override
	// @Transactional(readOnly = false)
	public int insert(Ｔ＿ｐａｙｇ情報 record) {
		return Ｔ＿ｐａｙｇ情報Mapper.insert(record);
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0080Service#selectTpayByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ｔ＿ｐａｙｇ情報 selectTpayByPrimaryKey(String ｋ５契約番号, String サービス申込番号, String 年月, String 商品型ｉｄ) {
		return Ｔ＿ｐａｙｇ情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 年月, 商品型ｉｄ);
	}

	@Override
	// @Transactional(readOnly = false)
	public int logicalDelete(Ｔ＿ｐａｙｇ情報 record) {
		return Ｔ＿ｐａｙｇ情報Mapper.updateByPrimaryKey(record);
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0080Service#getShohinKataByGamenNengetsu(
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ｍ＿商品型 getShohinKataByGamenNengetsu(String ryokimpuranId, String nengetsu) {
		Ｍ＿商品型 shohinKata = Ｍ＿商品型Mapper.getShohinKataByGamenNengetsu(ryokimpuranId, nengetsu);
		return shohinKata;
	}

	/* (非 Javadoc)
	 * @see k5oraclerds.subsys.service.ORAC0080Service#getChokaShiyoryo(java.lang.String, java.lang.String)
	 */
	@Override
	public Ｍ＿超過使用料 getChokaShiyoryoByNengetsu(String ryokimpuranId, String nengetsu) {
		Ｍ＿超過使用料 chokaShiyoryo = Ｍ＿超過使用料Mapper.getChokaShiyoryoByNengetsu(ryokimpuranId, nengetsu);
		return chokaShiyoryo;
	};


}
