package k5oraclerds.subsys.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import k5oraclerds.subsys.common.Global;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.service.ORAC0060Service;
import k5oraclerds.subsys.webform.ORAC0060Form;
import k5oraclerds.subsys.webform.component.ORAC0060FormMeisai;

@Controller
@RequestMapping(value = "/ORAC0060Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0060Controller {

	private static Logger logger = LoggerFactory.getLogger(ORAC0060Controller.class);

	@Resource
	private ORAC0060Service ORAC0060Service;

	@RequestMapping("/init")
	public String init(Model model, @ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form,
			@ModelAttribute("sansyoAttr") String sansyoAttr) {

		logger.info("メソッド" + "init" + "：開始");

		// 画面フォームの初期化を行う
		initForm(ORAC0060Form);
		model.addAttribute("ORAC0060Form", ORAC0060Form);

		model.addAttribute("sansyoAttr", sansyoAttr);

		logger.info("メソッド" + "init" + "：終了");

		// ORAC0060画面へ遷移する
		return "ORAC0060Form";
	}

	@RequestMapping("/checkForinsert")
	public String checkForinsert(@Valid @ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form, BindingResult result
			,Map<String, Object> map) {
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);
		if (result.hasErrors()) {
			return "ORAC0060Form";
		}

		if(!compositeCheck(ORAC0060Form, map)){
			return "ORAC0060Form";
		}

		String ryokinPuranId = ORAC0060Form.getKeiyakuJoho().get料金プランｉｄ();
		String chumonSyubetsuId = ORAC0060Form.getChumonjoho().get注文種別ｉｄ();

		if(ryokinPuranId.equals("02") && (chumonSyubetsuId.equals("01") || chumonSyubetsuId.equals("04"))){
			for(ORAC0060FormMeisai chumonjohoMeisai : ORAC0060Form.getChumonjohoMeisaiList()){
				if(!chumonjohoMeisai.getSyuryobiJissekiMae().equals(chumonjohoMeisai.get注文明細().get終了日＿実績())){
					map.put("Message", Global.getMsg("I010"));
					map.put("MessageCode", "I010");
					map.put("I005Message", Global.getMsg("I005"));
				}
			}
		}
		map.put("I005Message", Global.getMsg("I005"));
		return "ORAC0060Form";
	}

	/**
	 *
	 * @return
	 */
	@RequestMapping("/update")
	public String update(@ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form, BindingResult result
			,Map<String, Object> map) {
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);

		String errorCodeE010 = "E010";

		String k5KeyakuBango = ORAC0060Form.getKeiyakuJoho().getＫ５契約番号();
		String serviceMoshikomiBango = ORAC0060Form.getKeiyakuJoho().getサービス申込番号();
		Short renban = ORAC0060Form.getChumonjoho().get連番();
		String syohingataId = "";

		// List<Ｔ＿注文明細> chumonjohoMeisaiSelectedList =
		// commonSecletService.selectByPrimaryKeyChumonjohoMeisai(ｋ５契約番号,
		// サービス申込番号);
		List<ORAC0060FormMeisai> chumonjohoMeisaiCheckedList = new ArrayList<ORAC0060FormMeisai>();

		//Ｔ＿注文明細の更新、登録、削除
		String kingakutyoseFlag = "";
		for (ORAC0060FormMeisai chumonjohoMeisai : chumonjohoMeisaiCheckedList) {
			Ｔ＿注文明細 注文明細 = chumonjohoMeisai.get注文明細();
			syohingataId = 注文明細.get商品型ｉｄ();
			Ｔ＿注文明細 注文明細Selected = ORAC0060Service.selectChumonMesaiByPrimaryKey(k5KeyakuBango
					, serviceMoshikomiBango, renban, syohingataId);
			BigDecimal suryo = 注文明細.get数量();
			if(注文明細Selected != null){
				if(suryo.compareTo(BigDecimal.ONE) >= 0){
					注文明細Selected.set数量(suryo);
					注文明細Selected.set期間(注文明細.get期間());
					注文明細Selected.setＦｊ売値(注文明細.getＦｊ売値());
					注文明細Selected.setＦｊ単価(注文明細.getＦｊ単価());
					注文明細Selected.setＯｒａｃｌｅ単価(注文明細.getＯｒａｃｌｅ単価());
					// 画面の仕切り率÷100
					注文明細Selected.set仕切り率(注文明細.get仕切り率().divide(new BigDecimal(100)));
					注文明細Selected.setＦｊ想定仕入値(注文明細.getＦｊ想定仕入値());
					注文明細Selected.set開始日＿実績(dateReplace(注文明細.get開始日＿実績()));
					注文明細Selected.set終了日＿実績(dateReplace(注文明細.get終了日＿実績()));
					注文明細Selected.set開始日＿請求書(dateReplace(注文明細.get開始日＿請求書()));
					注文明細Selected.set終了日＿請求書(dateReplace(注文明細.get終了日＿請求書()));
					kingakutyoseFlag = chumonjohoMeisai.getSekyugakuCheckKekka();
					if(kingakutyoseFlag.equals("○") || kingakutyoseFlag.length() == 0){
						注文明細Selected.set金額調整フラグ("0");
					}else if(kingakutyoseFlag.equals("△") || kingakutyoseFlag.equals("×")){
						注文明細Selected.set金額調整フラグ("1");
					}
					注文明細Selected.setＯｒａｃｌｅ請求額(注文明細.getＯｒａｃｌｅ請求額());
				}else if(suryo.compareTo(BigDecimal.ZERO) == 0
						&& 注文明細Selected.get数量().compareTo(BigDecimal.ONE) >= 0){
					注文明細Selected.set論理削除フラグ("1");
				}
				注文明細Selected.set更新日時(new Date());
				注文明細Selected.set更新ユーザー(Global.getConfig("USER"));
				Ｔ＿注文明細 注文明細Tmp = ORAC0060Service.selectChumonMesaiByPrimaryKey(k5KeyakuBango
						, serviceMoshikomiBango, renban, syohingataId);
				if(注文明細Tmp != null){
					ORAC0060Service.updateChumonjohoMeisai(注文明細Selected);
				}else{
					map.put("Message", Global.getMsg(errorCodeE010));
					map.put("MessageCode", errorCodeE010);
					return "ORAC0060Form";
				}
			}else{
				if(suryo.compareTo(BigDecimal.ONE) >= 0){
					Ｔ＿注文明細 chumonjohoMeisaiInsert = new Ｔ＿注文明細();
					chumonjohoMeisaiInsert.setＫ５契約番号(k5KeyakuBango);
					chumonjohoMeisaiInsert.setサービス申込番号(serviceMoshikomiBango);
					chumonjohoMeisaiInsert.set連番(renban);
					chumonjohoMeisaiInsert.set商品型ｉｄ(syohingataId);
					chumonjohoMeisaiInsert.set料金プランｉｄ(ORAC0060Form.getKeiyakuJoho().get料金プランｉｄ());
					chumonjohoMeisaiInsert.set注文種別ｉｄ(ORAC0060Form.getChumonjoho().get注文種別ｉｄ());
					chumonjohoMeisaiInsert.set数量(注文明細.get数量());
					chumonjohoMeisaiInsert.set期間(注文明細.get期間());
					chumonjohoMeisaiInsert.setＦｊ売値(注文明細.getＦｊ売値());
					chumonjohoMeisaiInsert.setＦｊ単価(注文明細.getＦｊ単価());
					// Ｍ＿商品型のORACLE単価
					chumonjohoMeisaiInsert.setＯｒａｃｌｅ単価(注文明細.getＯｒａｃｌｅ単価());
					// 画面の仕切り率÷100
					chumonjohoMeisaiInsert.set仕切り率(注文明細.get仕切り率().divide(new BigDecimal(100)));
					chumonjohoMeisaiInsert.setＦｊ想定仕入値(注文明細.getＦｊ想定仕入値());
					chumonjohoMeisaiInsert.set開始日＿実績(dateReplace(注文明細.get開始日＿実績()));
					chumonjohoMeisaiInsert.set終了日＿実績(dateReplace(注文明細.get終了日＿実績()));
					chumonjohoMeisaiInsert.set開始日＿請求書(dateReplace(注文明細.get開始日＿請求書()));
					chumonjohoMeisaiInsert.set終了日＿請求書(dateReplace(注文明細.get終了日＿請求書()));
					kingakutyoseFlag = chumonjohoMeisai.getSekyugakuCheckKekka();
					if(kingakutyoseFlag.equals("○") || kingakutyoseFlag.length() == 0){
						chumonjohoMeisaiInsert.set金額調整フラグ("0");
					}else if(kingakutyoseFlag.equals("△") || kingakutyoseFlag.equals("×")){
						chumonjohoMeisaiInsert.set金額調整フラグ("1");
					}
					chumonjohoMeisaiInsert.set論理削除フラグ("0");
					chumonjohoMeisaiInsert.set登録日時(new Date());
					chumonjohoMeisaiInsert.set登録ユーザー(Global.getConfig("USER"));
					boolean 論理削除フラグ判断 = ORAC0060Service.注文明細論理削除フラグ判断ByKey(k5KeyakuBango
							, serviceMoshikomiBango, renban, syohingataId);
					if(論理削除フラグ判断){
						ORAC0060Service.updateInsertChumonjohoMeisai(chumonjohoMeisaiInsert);
					}else{
						map.put("Message", Global.getMsg("E015"));
						map.put("MessageCode", "E015");
						return "ORAC0060Form";
					}
				}
			}

		}


		// Ｔ＿注文情報の更新する
		Ｔ＿注文情報 chumonJoho = ORAC0060Service.selectChumonJohoByPrimaryKey(k5KeyakuBango, serviceMoshikomiBango, renban);
		if(chumonJoho != null){
			chumonJoho.setオラクルオーダーｉｄ(ORAC0060Form.getChumonjoho().getオラクルオーダーｉｄ());
			chumonJoho.set見積日(dateReplace(ORAC0060Form.getChumonjoho().get見積日()));
			chumonJoho.setＦｊ料金表適用日(dateReplace(ORAC0060Form.getChumonjoho().getＦｊ料金表適用日()));
			chumonJoho.setＯｒａｃｌｅ料金表適用日(dateReplace(ORAC0060Form.getChumonjoho().getＯｒａｃｌｅ料金表適用日()));
			chumonJoho.setコメント(ORAC0060Form.getChumonjoho().getコメント());
			chumonJoho.set適用開始希望日(dateReplace(ORAC0060Form.getChumonjoho().get適用開始希望日()));
			if(ORAC0060Form.isTokubetuWaribiki()){
				chumonJoho.set特別値引フラグ("1");
			}else{
				chumonJoho.set特別値引フラグ("0");
			}
			String kaishibiJissekiMin = "99991231";
			String syuryobiJissekiMax = "";
			String kaishibiJisseki = "";
			String syuryobiJisseki = "";
			BigDecimal suryo;
			boolean setteFlag = true;
			int num = 0;
			for(ORAC0060FormMeisai chumonjohoMeisai : chumonjohoMeisaiCheckedList){
				suryo = chumonjohoMeisai.get注文明細().get数量();
				if(suryo.compareTo(BigDecimal.ONE) < 0){
					continue;
				}
					num++;
				kaishibiJisseki = dateReplace(chumonjohoMeisai.get注文明細().get開始日＿実績());
				if(kaishibiJisseki == null || kaishibiJisseki.length() == 0){
					setteFlag = false;
					break;
				}
					syuryobiJisseki = dateReplace(chumonjohoMeisai.get注文明細().get終了日＿実績());
				if(syuryobiJisseki == null || syuryobiJisseki.length() == 0){
					setteFlag = false;
					break;
				}
				if(Long.parseLong(kaishibiJisseki) < Long.parseLong(kaishibiJissekiMin)){
					kaishibiJissekiMin = kaishibiJisseki;
				}
					if(Long.parseLong(syuryobiJisseki) > Long.parseLong(syuryobiJissekiMax)){
					syuryobiJissekiMax = syuryobiJisseki;
				}
			}
			if(num > 0 && setteFlag){
				chumonJoho.set開始日＿実績(kaishibiJissekiMin);
				chumonJoho.set終了日＿実績(syuryobiJissekiMax);
				chumonJoho.set最大開始日＿実績(kaishibiJissekiMin);
			}
			chumonJoho.setユーザｉｄ(ORAC0060Form.getChumonjoho().getユーザｉｄ());
			chumonJoho.set申込請書発行日(dateReplace(ORAC0060Form.getChumonjoho().get申込請書発行日()));
			chumonJoho.set更新日時(new Date());
			chumonJoho.set更新ユーザー(Global.getConfig("USER"));
			ORAC0060Service.updateChumonjoho(chumonJoho);
		}else{
			map.put("Message", Global.getMsg(errorCodeE010));
			map.put("MessageCode", errorCodeE010);
			return "ORAC0060Form";
		}

		// Ｔ＿契約情報の登録する
		String chumonSyubetsu = ORAC0060Form.getChumonjoho().get注文種別ｉｄ();
		if(chumonSyubetsu.equals("01")){
			Ｔ＿契約情報 keyakuJoho = ORAC0060Service.selectKeiyakuJohoByPrimaryKey(k5KeyakuBango, serviceMoshikomiBango);
			if(keyakuJoho != null){
				keyakuJoho.setサービス終了日(ORAC0060Form.getChumonjoho().get開始日＿実績());
				keyakuJoho.set更新日時(new Date());
				keyakuJoho.set更新ユーザー(Global.getConfig("USER"));
				ORAC0060Service.updateKeiyakuJoho(keyakuJoho);
			}else{
				map.put("Message", Global.getMsg(errorCodeE010));
				map.put("MessageCode", errorCodeE010);
				return "ORAC0060Form";
			}
		}

		// 全部の新規登録完了メッセージ[I002]をダイアログ表示する。
		//String エラーメッセージ文言 = commonSecletService.selectMessagesText("I002");
		String msgShinkinKanryo = Global.getMsg("I002");
		List<String> msgList = new ArrayList<String>();
		msgList.add(msgShinkinKanryo);
		map.put("Message", msgShinkinKanryo);
		map.put("MessageCode", "I002");
		return "ORAC0060Form";
	};

	/**
	 *
	 * @return
	 */
	@RequestMapping(value = "/modoru", method = RequestMethod.GET)
	public String modoru(@ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form, Model model,
			HttpSession httpSession) {

		model.addAttribute("ORAC0020FormJson", ORAC0060Form.getORAC0020FormJson());
		return "forward:/ORAC0020Form/modoruByChumonCondition";
	}

	/**
	 *
	 * @returns
	 * @throws IOException
	 */
	@RequestMapping("/sonzaiCheck")
	public String sonzaiCheck(@ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form, HttpServletRequest request,
			HttpServletResponse response ,Map<String, Object> map) throws Exception {
		Ｔ＿契約情報 keiyakuJoho = ORAC0060Form.getKeiyakuJoho();
		Ｔ＿契約情報 keiyakuJohoSelected = ORAC0060Service.selectKeiyakuJohoByPrimaryKey(keiyakuJoho.getＫ５契約番号(),
				keiyakuJoho.getサービス申込番号());
		if (keiyakuJohoSelected != null) {
			List<String> errMsgList = new ArrayList<String>();
			String strErrorMessage = Global.getMsg("E005");
			errMsgList.add(strErrorMessage);
			map.put("Message", errMsgList);
			map.put("MessageCode", "E005");
		}
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);
		request.setAttribute("ORAC0060Form", ORAC0060Form);
		return "ORAC0060Form";
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/selectchumonList")
	public String selectchumonList(@ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form,Model model){
		String 料金プランID = ORAC0060Form.getKeiyakuJoho().get料金プランｉｄ();
		String 見積日 = ORAC0060Form.getChumonjoho().get見積日();
		String FJ料金表適用日 = ORAC0060Form.getChumonjoho().getＦｊ料金表適用日();
		String Oracle料金表適用日 = ORAC0060Form.getChumonjoho().getＯｒａｃｌｅ料金表適用日();


		ORAC0060Form.setChumonjohoMeisaiList(selectChumonMesaiList(料金プランID,見積日,FJ料金表適用日,Oracle料金表適用日));
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);
		model.addAttribute("ORAC0060Form", ORAC0060Form);
		return "ORAC0060Form";
	}

	/**
	 *
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/clearchumonList")
	public String clearchumonList(@ModelAttribute("ORAC0060Form") ORAC0060Form ORAC0060Form,Model model){

		List<ORAC0060FormMeisai>  注文明細List = new ArrayList<ORAC0060FormMeisai>();
		ORAC0060Form.setChumonjohoMeisaiList(注文明細List);
		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);
		model.addAttribute("ORAC0060Form", ORAC0060Form);
		return "ORAC0060Form";
	}

	private void initForm(ORAC0060Form ORAC0060Form) {

		String k5KeyakuBango = ORAC0060Form.getKeiyakuJoho().getＫ５契約番号();
		String serviceMoshikomiBango = ORAC0060Form.getKeiyakuJoho().getサービス申込番号();
		Short renban = ORAC0060Form.getChumonjoho().get連番();

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0060Form);
		// 契約情報を初期化する
		Ｔ＿契約情報 契約情報 = ORAC0060Service.selectKeiyakuJohoByPrimaryKey(k5KeyakuBango, serviceMoshikomiBango);

		ORAC0060Form.setRyokinPuranmei(ORAC0060Form.getRyokimPuranMap().get(契約情報.get料金プランｉｄ()));
		契約情報.setサービス開始日(dateFormat(契約情報.getサービス開始日()));
		契約情報.setサービス終了日(dateFormat(契約情報.getサービス終了日()));
		契約情報.set環境削除日(dateFormat(契約情報.get環境削除日()));
		契約情報.setキャンセル依頼日(dateFormat(契約情報.getキャンセル依頼日()));
		契約情報.setロスト処理依頼日(dateFormat(契約情報.getロスト処理依頼日()));
		契約情報.set解約申込請書発行日(dateFormat(契約情報.get解約申込請書発行日()));
		ORAC0060Form.setKeiyakuJoho(契約情報);

		// 注文情報を初期化する
		Ｔ＿注文情報 注文情報 = ORAC0060Service.selectChumonJohoByPrimaryKey(k5KeyakuBango, serviceMoshikomiBango, renban);
		ORAC0060Form.setChumonSyubetumei(ORAC0060Form.getChumonShubetsuMap().get(注文情報.get注文種別ｉｄ()));
		注文情報.set申込請書発行日(dateFormat(注文情報.get申込請書発行日()));
		注文情報.set適用開始希望日(dateFormat(注文情報.get適用開始希望日()));
		注文情報.set見積日(dateFormat(注文情報.get見積日()));
		注文情報.setＦｊ料金表適用日(dateFormat(注文情報.getＦｊ料金表適用日()));
		注文情報.setＯｒａｃｌｅ料金表適用日(dateFormat(注文情報.getＯｒａｃｌｅ料金表適用日()));
		ORAC0060Form.setChumonjoho(注文情報);

		String fJ注文番号 = 契約情報.getサービス申込番号() + "-" + String.format("%03d", 注文情報.get連番());
		ORAC0060Form.setFJChumonBango(fJ注文番号);

		if(注文情報.get特別値引フラグ().equals("1")){
			ORAC0060Form.setTokubetuWaribiki(true);
		}

		List<Ｔ＿注文明細> 注文明細List = ORAC0060Service.selectChumonMesaiListByPrimaryKey(k5KeyakuBango, serviceMoshikomiBango, renban);

		List<ORAC0060FormMeisai> chumonjohoMeisaiList = new ArrayList<ORAC0060FormMeisai>();

		if(注文明細List == null || 注文明細List.size() == 0){
			String 料金プランID = ORAC0060Form.getKeiyakuJoho().get料金プランｉｄ();
			String 見積日 = ORAC0060Form.getChumonjoho().get見積日();
			String FJ料金表適用日 = ORAC0060Form.getChumonjoho().getＦｊ料金表適用日();
			String Oracle料金表適用日 = ORAC0060Form.getChumonjoho().getＯｒａｃｌｅ料金表適用日();

			chumonjohoMeisaiList = selectChumonMesaiList(料金プランID,見積日,FJ料金表適用日,Oracle料金表適用日);

		}else{
			BigDecimal bigDecimal100 = new BigDecimal(100);
			//FJ売値合計
			BigDecimal FJUrineGokei = BigDecimal.ZERO;
			//FJ想定仕入値合計
			BigDecimal FJSoteShireneGokei = BigDecimal.ZERO;
			//Oracle請求額合計
			BigDecimal OracleSekyugakuGokei = BigDecimal.ZERO;
			for(Ｔ＿注文明細 注文明細 : 注文明細List){
				String syohingataId = 注文明細.get商品型ｉｄ();
				ORAC0060FormMeisai ORAC0060FormMeisai = new ORAC0060FormMeisai();
				if(syohingataId != null && !syohingataId.equals("")){
					ORAC0060FormMeisai.setShohinmei(ORAC0060Form.getShohinGataMap().get(syohingataId));
				}
				ORAC0060FormMeisai.setSekyugakuCheckKekka(getSekyugakuCheckKekka(注文明細));
				FJUrineGokei = FJUrineGokei.add(注文明細.getＦｊ売値());
				FJSoteShireneGokei = FJSoteShireneGokei.add(注文明細.getＦｊ想定仕入値());
				OracleSekyugakuGokei = OracleSekyugakuGokei.add(注文明細.getＯｒａｃｌｅ請求額());
				注文明細.set仕切り率(注文明細.get仕切り率().multiply(bigDecimal100));
				ORAC0060FormMeisai.set注文明細(注文明細);
				ORAC0060FormMeisai.setSyuryobiJissekiMae(注文明細.get終了日＿実績());
				ORAC0060FormMeisai.setSonzaiFlag("1");
				chumonjohoMeisaiList.add(ORAC0060FormMeisai);
			}
			ORAC0060Form.setFJUrineGokei(FJUrineGokei);
			ORAC0060Form.setFJSoteShireneGokei(FJSoteShireneGokei);
			ORAC0060Form.setOracleSekyugakuGokei(OracleSekyugakuGokei);
		}

		ORAC0060Form.setChumonjohoMeisaiList(chumonjohoMeisaiList);


		// 注文明細を初期化する
//		List<ORAC0060FormChumonMeisai> chumonjohoMesaiList = new ArrayList<ORAC0060FormChumonMeisai>();
//		Ｔ＿注文明細 注文明細 = new Ｔ＿注文明細();
//		注文明細.setＦｊ単価(new BigDecimal("1000"));
//		ORAC0060FormChumonMeisai chumonjohoMesai = new ORAC0060FormChumonMeisai();
//		chumonjohoMesai.setStrCheckbox(true);
//		chumonjohoMesaiList.add(chumonjohoMesai);
//		ORAC0060Form.setChumonjohoMeisaiList(chumonjohoMesaiList);

	}

	/**
	 * ORAC0060画面上の料金プラン、注文種別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0060Form
	 */
	private void initPullDownList(ORAC0060Form ORAC0060Form) {

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = ORAC0060Service.getShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		// 商品型が存在する場合、フォーム情報に設定する
		if (shohinGatas.size() > 0) {
			ORAC0060Form.setShohinGataMap(Collections.unmodifiableMap(shohinGatas));
		}

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0060Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0060Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuMap = ORAC0060Service.getChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuMap) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}

		// 注文種別が存在する場合、フォーム情報に設定する
		if (chumonShubetsus.size() > 0) {
			ORAC0060Form.setChumonShubetsuMap(Collections.unmodifiableMap(chumonShubetsus));
		}
	}

	private String getSekyugakuCheckKekka(Ｔ＿注文明細 注文明細){
		String kekka = "";
		BigDecimal oracleSekyugaku = 注文明細.getＯｒａｃｌｅ請求額();
		BigDecimal FJSoteShinyune = 注文明細.getＦｊ想定仕入値();
		if(oracleSekyugaku != null && FJSoteShinyune != null){
			if(oracleSekyugaku.compareTo(FJSoteShinyune) == 0){
				kekka = "○";
			}
			FJSoteShinyune = FJSoteShinyune.divide(new BigDecimal(100));

			if(oracleSekyugaku.compareTo(FJSoteShinyune) < 0){
				kekka = "△";
			}else{
				kekka = "×";
			}
		}
		return kekka;
	}

	private Boolean compositeCheck(ORAC0060Form ORAC0060Form, Map<String, Object> map) {
		List<String> errMsgList = new ArrayList<String>();

		//元注文の取得
		String サービス申込番号 = ORAC0060Form.getKeiyakuJoho().getサービス申込番号();
		//Short 連番 = ORAC0060Form.getChumonjoho().get連番();
		Short 連番 = new Short("2");

		Ｔ＿注文情報 motochumonJoho = ORAC0060Service.selectMotochumon(サービス申込番号, 連番).get(0);
		String motochumonJohoKaishibi = dateReplace(motochumonJoho.get開始日＿実績());
		String motochumonJohoSyuryobi = dateReplace(motochumonJoho.get終了日＿実績());

		String kaishibiErrorIndex = "";
		String syuryobiErrorIndex = "";
		String kaishiSekyusyobiErrorIndex = "";
		String syuryoSekyusyobiErrorIndex = "";

		boolean E006ErrorFlag = false;
		boolean E012ErrorFlag = false;
		boolean E013ErrorFlag = false;
		boolean E014ErrorFlag = false;

		String ryokinPuranId = ORAC0060Form.getKeiyakuJoho().get料金プランｉｄ();
		String chumonSyubetuId = ORAC0060Form.getChumonjoho().get注文種別ｉｄ();

		//数量未入力チェック
		//開始日(実績)チェック１,開始日(実績)チェック２,終了日(実績)チェック,開始日(請求書)チェック１
		//開始日(請求書)チェック２,終了日(請求書)チェック,
		List<ORAC0060FormMeisai> chumonjohoMeisaiList = ORAC0060Form.getChumonjohoMeisaiList();
		BigDecimal suryoSum = BigDecimal.ZERO;
		int meisaiListSize = 0;
		for(ORAC0060FormMeisai chumonjohoMeisai : chumonjohoMeisaiList){
			meisaiListSize = meisaiListSize + 1;
			if(chumonjohoMeisai.get注文明細().get数量() != null){
				suryoSum = suryoSum.add(chumonjohoMeisai.get注文明細().get数量());
			}

			String 開始日実績 = dateReplace(chumonjohoMeisai.get注文明細().get開始日＿実績());
			if(開始日実績 != null && 開始日実績.length() > 0){
				if(((ryokinPuranId.equals("01") && chumonSyubetuId.equals("02"))
						|| (ryokinPuranId.equals("02") && chumonSyubetuId.equals("03")))
						&& Long.parseLong(motochumonJohoKaishibi) > Long.parseLong(開始日実績)){
					//errMsgList.add(Global.getMsg("E012"));
					kaishibiErrorIndex = kaishibiErrorIndex + meisaiListSize +":";
					E012ErrorFlag = true;
				}

				if(ryokinPuranId.equals("02") && chumonSyubetuId.equals("04")
						&& Long.parseLong(motochumonJohoKaishibi) > Long.parseLong(開始日実績)){
					kaishibiErrorIndex = kaishibiErrorIndex + meisaiListSize +":";
					E014ErrorFlag = true;
				}

			}

			String 終了日実績 = dateReplace(chumonjohoMeisai.get注文明細().get終了日＿実績());
			if(終了日実績 != null && 終了日実績.length() > 0){
				if(ryokinPuranId.equals("02") && chumonSyubetuId.equals("04")
						&& Long.parseLong(motochumonJohoSyuryobi) != Long.parseLong(終了日実績)){
					syuryobiErrorIndex = syuryobiErrorIndex + meisaiListSize +":";
					E013ErrorFlag = true;
				}

				if(開始日実績 != null && 開始日実績.length() > 0
						&& Long.parseLong(開始日実績) > Long.parseLong(終了日実績)){
					kaishibiErrorIndex = kaishibiErrorIndex + meisaiListSize +":";
					syuryobiErrorIndex = syuryobiErrorIndex + meisaiListSize +":";
					E006ErrorFlag = true;
				}
			}

			String 開始日請求書 = dateReplace(chumonjohoMeisai.get注文明細().get開始日＿請求書());
			if(開始日請求書 != null && 開始日請求書.length() > 0){
				if(((ryokinPuranId.equals("01") && chumonSyubetuId.equals("02"))
						|| (ryokinPuranId.equals("02") && chumonSyubetuId.equals("03")))
						&& Long.parseLong(motochumonJohoKaishibi) > Long.parseLong(開始日請求書)){
					//errMsgList.add(Global.getMsg("E012"));
					kaishiSekyusyobiErrorIndex = kaishiSekyusyobiErrorIndex + meisaiListSize +":";
					E012ErrorFlag = true;
				}

				if(ryokinPuranId.equals("02") && chumonSyubetuId.equals("04")
						&& Long.parseLong(motochumonJohoKaishibi) > Long.parseLong(開始日請求書)){
					kaishiSekyusyobiErrorIndex = kaishiSekyusyobiErrorIndex + meisaiListSize +":";
					E014ErrorFlag = true;
				}
			}

			String 終了日請求書 = dateReplace(chumonjohoMeisai.get注文明細().get終了日＿請求書());
			if(終了日請求書 != null && 終了日請求書.length() > 0){
				if(ryokinPuranId.equals("02") && chumonSyubetuId.equals("04")
						&& Long.parseLong(motochumonJohoSyuryobi) != Long.parseLong(終了日請求書)){
					syuryoSekyusyobiErrorIndex = syuryoSekyusyobiErrorIndex + meisaiListSize +":";
					E013ErrorFlag = true;
				}

				if(開始日請求書 != null && 開始日請求書.length() > 0
						&& Long.parseLong(開始日請求書) > Long.parseLong(終了日請求書)){
					kaishiSekyusyobiErrorIndex = kaishiSekyusyobiErrorIndex + meisaiListSize +":";
					syuryoSekyusyobiErrorIndex = syuryoSekyusyobiErrorIndex + meisaiListSize +":";
					E006ErrorFlag = true;
				}
			}

		}
		if(suryoSum.compareTo(BigDecimal.ZERO) <= 0){
			errMsgList.add(Global.getMsg("E004"));
		}

		//見積日チェック
		Ｔ＿注文情報 chumonJoho = ORAC0060Form.getChumonjoho();
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date nowDate = new Date();
		int intNowDate = Integer.parseInt(format.format(nowDate));
		int int見積日 = Integer.parseInt(dateReplace(chumonJoho.get見積日()));
		if(int見積日 > intNowDate){
			E012ErrorFlag = true;
		}

		//料金表適用日チェック
		String FJ料金表適用日 = chumonJoho.getＦｊ料金表適用日();
		String Oracle料金表適用日 = chumonJoho.getＯｒａｃｌｅ料金表適用日();

		if(FJ料金表適用日.length() == 0 && Oracle料金表適用日.length() > 0){
			errMsgList.add(Global.getMsg("E025"));
		}else if(FJ料金表適用日.length() > 0 && Oracle料金表適用日.length() == 0){
			errMsgList.add(Global.getMsg("E025"));
		}

		if(E006ErrorFlag){
			errMsgList.add(Global.getMsg("E006"));
		}
		if(E012ErrorFlag){
			errMsgList.add(Global.getMsg("E012"));
		}
		if(E013ErrorFlag){
			errMsgList.add(Global.getMsg("E013"));
		}
		if(E014ErrorFlag){
			errMsgList.add(Global.getMsg("E014"));
		}

		if(errMsgList.size() > 0){
			map.put("ErrorMessage", errMsgList);
			//model.addAttribute("ORAC0060Form", ORAC0060Form);
			map.put("KaishibiErrorIndex", kaishibiErrorIndex);
			map.put("SyuryobiErrorIndex", syuryobiErrorIndex);
			map.put("KaishiSekyusyobiErrorIndex", kaishiSekyusyobiErrorIndex);
			map.put("SyuryoSekyusyobiErrorIndex", syuryoSekyusyobiErrorIndex);
			map.put("mesaiListSize", meisaiListSize);
			return false;
		}

		return true;
	}


	private List<ORAC0060FormMeisai> selectChumonMesaiList(String 料金プランID, String 見積日
			,String FJ料金表適用日, String Oracle料金表適用日){
		見積日 = dateReplace(見積日);

		List<ORAC0060FormMeisai>  注文明細List = new ArrayList<ORAC0060FormMeisai>();
		List<Ｍ＿商品型> 商品型List;
		if(!FJ料金表適用日.isEmpty() && FJ料金表適用日.length() == 10){
			FJ料金表適用日 = dateReplace(FJ料金表適用日);
			商品型List = ORAC0060Service.selectShohinGataForChumonmesai(料金プランID, FJ料金表適用日);
		}else{
			商品型List = ORAC0060Service.selectShohinGataForChumonmesai(料金プランID, 見積日);
		}

		List<ORAC0060FormMeisai> ORAC0060FormMeisaiList = set注文明細List(注文明細List,商品型List);

		if(!Oracle料金表適用日.isEmpty() && Oracle料金表適用日.length() == 10){
			Oracle料金表適用日 = dateReplace(Oracle料金表適用日);
			商品型List = ORAC0060Service.selectShohinGataForChumonmesai(料金プランID, Oracle料金表適用日);
		}

		ORAC0060FormMeisaiList = set注文明細List(注文明細List,商品型List);

		return ORAC0060FormMeisaiList;
	}

	private List<ORAC0060FormMeisai> set注文明細List(List<ORAC0060FormMeisai> 注文明細List, List<Ｍ＿商品型> 商品型List){
		BigDecimal DECIMAL100 = new BigDecimal(100);
		for(Ｍ＿商品型 商品型 : 商品型List){
			Ｔ＿注文明細 注文明細 = new Ｔ＿注文明細();
			注文明細.setＦｊ単価(商品型.getＦｊ単価());
			注文明細.set仕切り率(商品型.get仕切り率().multiply(DECIMAL100));
			注文明細.set商品型ｉｄ(商品型.get商品型ｉｄ());
			注文明細.setＯｒａｃｌｅ単価(商品型.getＯｒａｃｌｅ単価());
			注文明細.set期間(new Short("12"));
			ORAC0060FormMeisai chumonMeisai = new ORAC0060FormMeisai();
			chumonMeisai.set注文明細(注文明細);
			chumonMeisai.setSyuryobiJissekiMae("");
//			if(料金プラン.equals("01")){
//				BigDecimal FJ想定仕入値 =
//			}else if(料金プラン.equals("02")){
//
//			}
			chumonMeisai.setShohinmei(商品型.get商品型名());
			chumonMeisai.setSonzaiFlag("0");
			注文明細List.add(chumonMeisai);
		}
		return 注文明細List;
	}

	private String dateReplace(String strDate){

		return strDate == null ? strDate : strDate.replaceAll("/", "");
	}

	private String dateFormat(String strDate){
		if(strDate == null || strDate.length() == 0){
			return "";
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date date = null;
		try {
			date = sdf.parse(strDate);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		sdf = new SimpleDateFormat("yyyy/MM/dd");
		return sdf.format(date);

	}

}
