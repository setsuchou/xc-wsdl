package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

/**
 *
 *[契約情報検索]画面処理を行うサービスクラス
 * @author setsuchou
 * @version 2017-03-03
 *
 */
public interface ORAC0020Service {

	/**
	 *  契約情報、契約に紐付く注文情報、契約に紐付く注文明細を削除する
	 */
	//@Transactional
	public void sakujo(String ｋ５契約番号, String サービス申込番号, Short 連番);


	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

	public Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号, Short 連番);

	public Ｔ＿注文明細 selectByPrimaryKeyChumonjohoMeisai(String ｋ５契約番号, String サービス申込番号, Short 連番, String 商品型ｉｄ);

	public List<Ｔ＿注文明細> selectChomonListByKeys(String ｋ５契約番号, String サービス申込番号, Short 連番);


	public List<ORAC0020FormMeisai> selectMeisaiByKeiyakuCondition(String サービス申込番号, String Ｋ５契約番号, String アイデンティティドメイン,
			String サービス終了日FROM, String サービス終了日TO);

	// selectMeisaiByChumonCondition

	public List<ORAC0020FormMeisai> selectMeisaiByChumonCondition(String サービス申込番号, String Ｋ５契約番号, Short 連番,
			String アイデンティティドメイン, String サービス終了日FROM, String サービス終了日TO, String 適用開始希望日FROM, String 適用開始希望日TO);

	public List<Ｍ＿商品型> selectAllShohinGata();

	public List<Ｍ＿料金プラン> selectAllRyokimPuran();

	public List<Ｍ＿注文種別> selectAllChumonShubetsu();

}
