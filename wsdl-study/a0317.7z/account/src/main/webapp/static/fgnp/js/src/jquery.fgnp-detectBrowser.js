/*
 * jquery.fgnp-detectBrowser.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/


(function ($)
{
	/**
	 * Return an integer based on if the device is tablet, phone or desktop
	 * If you call it on an object (or multiple objects, such as $("body").detectBrowser()
	 * it'll add classes to that object automatically. Default classes are in $.fn.detectBrowser.defaults,
	 * but can be overridden by { mobileClass : mobileClass, tabletClass : tabletClass, desktopClass : desktopClass }
	 *
	 * You can also call it's methods as such $.fn.detectBrowser('isMobile');
	 *
	 * Methods you can call:
	 *      isWindows
	 *      isAndroid
	 *      isIphone
	 *      isIpad
	 *      isPlayBook
	 *      isWebOs
	 *      isDesktop
	 *      isMobile
	 *      isTablet
	 *      isTouch
	 *      init
	 *
	 * Return Meanings:
	 * 1: It's a mobile device
	 * 2: It's a tablet device
	 * 3: It's a desktop device
	 *
	 * @method detectBrowser
	 * @return int
	 */
	$.fn.detectBrowser = function (method, opts)
	{
		var defaults = {
			mobileClass : 'fgnp-device-mobile',
			tabletClass : 'fgnp-device-tablet',
			desktopClass: 'fgnp-device-desktop'
		};

		if(!options && typeof method === 'object')
		{
			opts = method;
			method = null;
		}

		var options = $.extend({}, defaults, opts);
		var arguments = [ options ];

		if (methods[method])
		{
			return methods[method].apply(this, arguments);
		}
		else if (typeof method === 'object' || !method)
		{
			return methods.init.apply(this, arguments);
		}
	};

	var methods = {
		/**
		 * Returns true or false depending on if the device is has Windows installed on it
		 *
		 * @method isWindows
		 * @return boolean
		 */
		"isWindows": function ()
		{
			return /Windows NT/i.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device has Android installed on it
		 *
		 * @method isAndroid
		 * @return boolean
		 */
		"isAndroid": function ()
		{
			return /Android/i.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device is an iPhone
		 *
		 * @method isIphone
		 * @return boolean
		 */
		"isIphone": function ()
		{
			return /iPhone/.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device is an iPad
		 *
		 * @method isIpad
		 * @return boolean
		 */
		"isIpad": function ()
		{
			return /iPad/.test(navigator.userAgent);
		},

		/**
		 * Returns true or falser depending on if the device is an iPod
		 *
		 * @method isIpod
		 * @return boolean
		 */
		"isIpod": function ()
		{
			return /iPod/.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device is a RIM Tablet (Blackberry Playbook)
		 *
		 * @method isPlayBook
		 * @reutrn boolean
		 */
		"isPlayBook": function ()
		{
			return /RIM Tablet/.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device is a webOS device.
		 * Since there are no webOS phones, it can be assumed to be a tablet
		 *
		 * @method isWebOs
		 * @return boolean
		 */
		"isWebOs": function ()
		{
			return /hpwOS/.test(navigator.userAgent);
		},

		/**
		 * Returns true or false depending on if the device is a desktop or not
		 * This is determined by lack of it being a mobile device, and lack of it being a touch device
		 * For laptops that have touch enabled, we want to give them the tablet layout to utalise that touch
		 *
		 * @method isDesktop
		 * @return boolean
		 */
		"isDesktop": function ()
		{
			if (methods.isTablet())
				return false;

			if (!methods.isTouch() && !methods.isMobile())
				return true;

			if ($(window).height() >= 1200 && $(window).height() >= 600)
				return true;

			return false;
		},

		/**
		 * Returns true or false depending on if the device is a mobile or not
		 *
		 * @method isMobile
		 * @return boolean
		 */
		"isMobile": function ()
		{
			//For some reason the iPad has "Mobile" in it's useragent, while all Android tablet's do not
			return /Mobile/.test(navigator.userAgent) && !methods.isIpad();
		},

		/**
		 * Returns true or false depending on if the device is a tablet
		 * This returns true for all androids that aren't phones, for RIM Tablet,
		 * for WebOS, for Ipad, for windows touch devices and for devices that aren't mobile
		 * but have touch capabilities
		 *
		 * @method isTablet
		 * @return boolean
		 */
		"isTablet": function ()
		{
			if (/Android/.test(navigator.userAgent) && !methods.isMobile())
				return true;

			if (methods.isPlayBook())
				return true;

			if (methods.isWebOs())
				return true;

			if (methods.isIpad())
				return true;

			if (methods.isWindows() && methods.isTouch())
				return true;

			if (!methods.isMobile() && methods.isTouch())
				return true;

			return false;
		},

		/**
		 * Returns true or false depending on if the device has touch capabilities
		 *
		 * @method isTouch
		 * @return boolean
		 */
		"isTouch": function ()
		{
			//Here we create an element, then whether or not the element has an "ontouchstart" attribute to it, and whether or not
			//we can assign a function it, thereby knowing whether the browser will let people touch elements
			var element = document.createElement('i');
			return "ontouchstart"in element || element.setAttribute && element.setAttribute("ontouchstart", "return;") || false;
		},

		"init": function (options)
		{
		    if($('body').data("device-support") !== undefined){
			methods.detect(options, parseInt($('body').data("device-support")));
		    } else {
			methods.detect(options);
		    }
		},
		"detect": function(options, patternNumber){

		    var $body = $('body');

		    if (methods.isMobile()) $body.addClass(options.mobileClass);
		    if (methods.isTablet())  $body.addClass(options.tabletClass);
		    if (methods.isDesktop())  $body.addClass(options.desktopClass);

		    switch(patternNumber){
			case 1: //Desktop, tablet and mobile devices are supported - and selected/detected automatically
			    break;

			case 2: // Desktop and tablet devices are supported, mobile devices use tablet layout
			    if (methods.isMobile()) $body.removeClass(options.mobileClass + " " + options.tabletClass).addClass(options.tabletClass);
			    break;

			case 3: // Desktop and mobile devices are supported, tablet devices use desktop layout
			    if (methods.isTablet())  $body.removeClass(options.tabletClass + " " + options.desktopClass).addClass(options.desktopClass);
			    break;

			case 4: // Desktop and mobile devices are supported, tablet devices use mobile layout
			    if (methods.isTablet())  $body.removeClass(options.tabletClass + " " + options.mobileClass).addClass(options.mobileClass);
			    break;

			case 5: // Tablet and mobile devices are supported, desktop devices use tablet layout
			    if (methods.isDesktop())  $body.removeClass(options.desktopClass + " " + options.tabletClass).addClass(options.tabletClass);
			    break;

			case 6: // Desktop only mode
			    $body.removeClass(options.desktopClass + " " + options.tabletClass + " " +options.mobileClass).addClass(options.desktopClass);
			    break;

			case 7: // Tablet only mode
			    $body.removeClass(options.desktopClass + " " + options.tabletClass + " " + options.mobileClass).addClass(options.tabletClass);
			    break;

			case 8: // Mobile only mode
			    $body.removeClass(options.desktopClass + " " + options.tabletClass + " " + options.mobileClass).addClass(options.mobileClass);
			    break;
		    }
		}
	};

})(jQuery);

(function ($)
{
	var pluginName = 'fgnpDetectOrientation';

	var methods =
	{
		"isLandscape": function(obj, options)
		{
			var ua = navigator.userAgent.toLowerCase();
			var isAndroid = ua.indexOf("android") > -1;

			if (isAndroid) {
				if(window.innerWidth >= window.innerHeight * (4/3))
					return true;

			} else {
				if(window.orientation !== undefined &&
					(window.orientation === 90 || window.orientation === -90))
					return true

				if(window.innerWidth >= window.innerHeight * (4/3))
					return true;
			}

			return false;
		},

		"isPortrait": function(obj, options)
		{
			var ua = navigator.userAgent.toLowerCase();
			var isAndroid = ua.indexOf("android") > -1;

			if (isAndroid) {
			   if(window.innerWidth < window.innerHeight * (4/3))
					return true;

			} else {
				if(window.orientation !== undefined &&
					(window.orientation === 0 || window.orientation === 180))
					return true;

				if(window.innerWidth < window.innerHeight * (4/3))
					return true;
			}

			return false;
		},

		"init": function(obj, options)
		{
            if(obj.hasClass(options.desktopClass)) {
                return;
            }

			$(obj).removeClass(options.landscapeClass)
				.removeClass(options.portraitClass)
				;

			if(methods.isLandscape(obj, options))
			{
				$(obj).addClass(options.landscapeClass);
			}
			else if(methods.isPortrait(obj, options))
			{
				$(obj).addClass(options.portraitClass);
			}
		}
	};

	$.fn[pluginName] = function(method, opts)
	{

		var defaults = {
			landscapeClass : 'fgnp-device-landscape',
			portraitClass: 'fgnp-device-portrait',
			desktopClass: 'fgnp-device-desktop'
		};

		if(!options && typeof method === 'object')
		{
			opts = method;
			method = null;
		}

		var options = $.extend({}, defaults, opts);

		if(options.methods)
			$.extend(methods, opts.methods);

		var arguments = [ this, options ];

		if (methods[method])
		{
			return methods[method].apply(this, arguments);
		}
		else if (typeof method === 'object' || !method)
		{
			return methods.init.apply(this, arguments);
		}
	};

})(jQuery);

/* DetectBrowser Plugin ends here */

