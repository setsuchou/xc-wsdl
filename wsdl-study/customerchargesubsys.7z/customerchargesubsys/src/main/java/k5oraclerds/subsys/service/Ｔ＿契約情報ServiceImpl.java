package k5oraclerds.subsys.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿契約情報Key;

@Service("Ｔ＿契約情報Service")
public class Ｔ＿契約情報ServiceImpl implements Ｔ＿契約情報Service {

	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	public Ｔ＿契約情報Mapper getＴ＿契約情報Mapper() {
		return Ｔ＿契約情報Mapper;
	}

	@Autowired
	public void setＴ＿契約情報Mapper(Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper) {
		this.Ｔ＿契約情報Mapper = Ｔ＿契約情報Mapper;
	}

	@Override
	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(Ｔ＿契約情報Key key) {
		return Ｔ＿契約情報Mapper.selectByPrimaryKey(key);
	}

/*	@Override
	public List<Ｔ＿契約情報> getAll() {
		return Ｔ＿契約情報Mapper.getAll();
	}

	@Override
	public List<Ｔ＿契約情報> getAll2() {
		return Ｔ＿契約情報Mapper.getAll2();
	}

	@Override
	public List<Ｔ＿契約情報> getAll3() {
		return Ｔ＿契約情報Mapper.getAll3();
	}
*/
}
