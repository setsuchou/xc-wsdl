package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿契約情報Key;

public interface Ｔ＿契約情報Service {

	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(Ｔ＿契約情報Key key);

/*	List<Ｔ＿契約情報> getAll();

	List<Ｔ＿契約情報> getAll2();

	List<Ｔ＿契約情報> getAll3();*/

}
