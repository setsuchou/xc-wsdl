package k5oraclerds.subsys.service;

import static org.junit.Assert.fail;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿契約情報Key;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring.xml", "classpath:spring-mybatis.xml" })
public class Ｔ＿契約情報ServiceImplTest {

	private static final Logger logger = Logger.getLogger(Ｔ＿契約情報ServiceImplTest.class);

	private Ｔ＿契約情報Service t＿契約情報Service;

	public Ｔ＿契約情報Service getT＿契約情報Service() {
		return t＿契約情報Service;
	}

	@Autowired
	public void setT＿契約情報Service(Ｔ＿契約情報Service t＿契約情報Service) {
		this.t＿契約情報Service = t＿契約情報Service;
	}

	@Test
	public void test1() {
		Ｔ＿契約情報Key key = new Ｔ＿契約情報Key();
		key.setサービス申込番号("000000000000001");
		key.setＫ５契約番号("00000001");
		Ｔ＿契約情報 returnEntity = t＿契約情報Service.getＴ＿契約情報ByPrimaryKey(key);
		logger.info(JSON.toJSONStringWithDateFormat(returnEntity, "yyyy-MM-dd HH:mm:ss"));
	}


}
