package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;

public class ORAC0030Form implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public ORAC0030Form() {
	}

	/**
	 * @param keiyakuJoho
	 * @param ryokimPuranMap
	 */
	public ORAC0030Form(Ｔ＿契約情報 keiyakuJoho,Map<String, String> ryokimPuranMap) {
		super();
		this.keiyakuJoho = keiyakuJoho;
		this.ryokimPuranMap = ryokimPuranMap;
	}

	/**
	 *  契約情報
	 */
	@Valid
	private Ｔ＿契約情報 keiyakuJoho;

	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;


	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	/**
	 * @param keiyakuJoho セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}
	/**
	 * @param ryokimPuranMap セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}

}
