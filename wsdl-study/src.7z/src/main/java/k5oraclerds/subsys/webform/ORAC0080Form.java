package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.webform.component.ORAC0080FormMeisai;

public class ORAC0080Form implements Serializable {
	private static final long serialVersionUID = 1L;

	// 契約情報
	private Ｔ＿契約情報 keiyakuJoho;

	//  画面明細
	@Valid
	private List<ORAC0080FormMeisai> tpaygMeisaiList;

	// 料金マスタ情報
	private Map<String, String> ryokimPuranMap;
	/**
	 * @return keiyakuJoho
	 */
	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	/**
	 * @param keiyakuJoho セットする keiyakuJoho
	 */
	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	/**
	 * @return tpaygMeisaiList
	 */
	public List<ORAC0080FormMeisai> getTpaygMeisaiList() {
		return tpaygMeisaiList;
	}

	/**
	 * @param tpaygMeisaiList セットする tpaygMeisaiList
	 */
	public void setTpaygMeisaiList(List<ORAC0080FormMeisai> tpaygMeisaiList) {
		this.tpaygMeisaiList = tpaygMeisaiList;
	}

	/**
	 * @return ryokimPuranMap
	 */
	public Map<String, String> getRyokimPuranMap() {
		return ryokimPuranMap;
	}

	/**
	 * @param ryokimPuranMap セットする ryokimPuranMap
	 */
	public void setRyokimPuranMap(Map<String, String> ryokimPuranMap) {
		this.ryokimPuranMap = ryokimPuranMap;
	}

}
