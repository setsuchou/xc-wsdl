package k5oraclerds.subsys.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import k5oraclerds.subsys.common.Global;
import k5oraclerds.subsys.common.Constants.ORACConstants;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿ｐａｙｇ情報;
import k5oraclerds.subsys.service.CommonSecletService;
import k5oraclerds.subsys.service.ORAC0080Service;
import k5oraclerds.subsys.webform.ORAC0020Form;
import k5oraclerds.subsys.webform.ORAC0080Form;
import k5oraclerds.subsys.webform.component.ORAC0080FormMeisai;

@Controller
@RequestMapping(value = "/ORAC0080Form", method = { RequestMethod.GET, RequestMethod.POST })
public class ORAC0080Controller {

	@Resource
	private ORAC0080Service ORAC0080Service;

	@Resource
	private CommonSecletService commonSecletService;

	Ｔ＿ｐａｙｇ情報 tpay = null;

	@RequestMapping("/init")
	public String init(@ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form, Model model,
			Map<String, Object> map) {

		// 遷移元[契約検索画面ORAC0020Form]からサービス申込番号、K5契約番号を引継ぎ
		Ｔ＿契約情報 keiyakuJohoForm;
		List<ORAC0080FormMeisai> tpaygMeisaiList = new ArrayList<ORAC0080FormMeisai>();
		if (ORAC0080Form.getKeiyakuJoho() == null) {
			ORAC0080Form = new ORAC0080Form();
			// フォームの初期化を行う
			// 契約情報を初期化する
			keiyakuJohoForm = new Ｔ＿契約情報();
		} else {

			// 検索画面より引き継がれたサービス申込番号、K5契約番号に該当する情報を、
			// Ｔ＿契約情報、Ｔ＿PAYG情報から取得し、画面項目を表示する。
			Ｔ＿契約情報 keiyakuJoho = ORAC0080Form.getKeiyakuJoho();
			keiyakuJohoForm = ORAC0080Service.selectKeiyakuJohoByPrimaryKey(keiyakuJoho.getＫ５契約番号(),
					keiyakuJoho.getサービス申込番号());
			List<Ｔ＿ｐａｙｇ情報> tpayList = ORAC0080Service.selectTpaygJohoByKeys(keiyakuJoho.getＫ５契約番号(),
					keiyakuJoho.getサービス申込番号());
			for (Ｔ＿ｐａｙｇ情報 tpay : tpayList) {
				ORAC0080FormMeisai meisai = new ORAC0080FormMeisai();
				// 商品型ｉｄ
				meisai.setShohinKataId(tpay.get商品型ｉｄ());
				// 商品型名を取得する
				Ｍ＿商品型 shohinKata = ORAC0080Service.getShohinKataMei(tpay.get商品型ｉｄ(), keiyakuJohoForm.get料金プランｉｄ(),
						tpay.get年月());
				if (shohinKata != null && (!StringUtils.isEmpty(shohinKata.get商品型名()))) {
					meisai.setShohinKataMei(shohinKata.get商品型名());
				} else {
					List<String> errList = new ArrayList<String>();
					errList.add(Global.getMsg("E011"));
					meisai.setShohinKataMei(null);
					map.put("ErrorMessage", errList);
				}

				// 年月
				meisai.setNengetsu(tpay.get年月());
				// Ｏｒａｃｌｅ請求額
				meisai.setOracleSeikyugaku(tpay.getＯｒａｃｌｅ請求額());
				// Ｆｊ単価
				meisai.setFjTanka(tpay.getＦｊ単価());
				// Ｆｊ売値
				meisai.setFjUrine(tpay.getＦｊ売値());
				// ＰＡＡＳ連携済フラグ(隠し項目)
				meisai.setPaasRenkeiZumifuragu(tpay.getＰａａｓ連携済フラグ());
				tpaygMeisaiList.add(meisai);
			}
		}

		// 最終に空白行を追加する
		ORAC0080FormMeisai meisai = new ORAC0080FormMeisai();
		meisai.setCheckboxStatus(false);
		meisai.setChokaShiyoryo(new BigDecimal(0));
		meisai.setFjTanka(new BigDecimal(0));
		meisai.setFjUrine(new BigDecimal(0));
		meisai.setNengetsu("");
		meisai.setOracleSeikyugaku(new BigDecimal(0));
		meisai.setShohinKataId("");
		meisai.setShohinKataMei("");
		tpaygMeisaiList.add(meisai);

		// 整理されたデータを画面に設定する
		ORAC0080Form.setKeiyakuJoho(keiyakuJohoForm);
		ORAC0080Form.setTpaygMeisaiList(tpaygMeisaiList);

		// 画面上のプルダウンリストの初期化を行う
		initPullDownList(ORAC0080Form);

		model.addAttribute("ORAC0080Form", ORAC0080Form);
		return "ORAC0080Form";
	}

	@RequestMapping("/tourokuForCheck")
	public String tourokuForCheck(@Valid @ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form,
			BindingResult result, Map<String, Object> map, Model model) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		List<String> errList = new ArrayList<String>();
		if (result.hasErrors()) {
			initPullDownList(ORAC0080Form);
			model.addAttribute("ORAC0080Form", ORAC0080Form);
			return "ORAC0080Form";
		}

		// 画面上から契約情報を取得する
		Ｔ＿契約情報 keiyakuJoho = ORAC0080Form.getKeiyakuJoho();

		// 画面上から明細一覧を取得する
		List<ORAC0080FormMeisai> tpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		List<ORAC0080FormMeisai> seletedTpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		// 複合チェック
		// 選択されたcheckbox数をカウントする
		for (ORAC0080FormMeisai orac0080FormMeisai : tpaygMeisaiList) {
			if (orac0080FormMeisai.getCheckboxStatus()) {
				seletedTpaygMeisaiList.add(orac0080FormMeisai);
				int hikakuKeka = BigDecimal.ZERO.compareTo(orac0080FormMeisai.getOracleSeikyugaku());
				if ((hikakuKeka == 0) || (StringUtils.isEmpty(orac0080FormMeisai.getNengetsu()))) {
					errList.add(Global.getMsg("E002"));
					map.put("ErrorMessage", errList);
				}
			}
		}
		if (seletedTpaygMeisaiList.size() == 0) {
			errList.add(Global.getMsg("E002"));
			map.put("ErrorMessage", errList);
		}

		// 業務チェック
		// 選択された明細行のＴ＿PAYG情報の項目「ＰＡＡＳ連携済フラグ」が"1"の場合、
		// ワーニングメッセージ[W002]をダイアログ表示する。
		if (errList.size() == 0) {
			for (ORAC0080FormMeisai selectedMeisai : seletedTpaygMeisaiList) {
				if ("1".equals(selectedMeisai.getPaasRenkeiZumifuragu())) {
					map.put("warmMessage", Global.getMsg("W002"));
					// ORAC0020画面へ遷移する
					return "ORAC0080Form";
				}
			}
		}

		// 上記以外の場合、登録確認メッセージ[I005]をダイアログ表示する。
		map.put("tourokuMessage", Global.getMsg("I005"));
		// 画面明細部を取得する
		// 画面フォーム条件をセットする
		initPullDownList(ORAC0080Form);
		model.addAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "ORAC0080Form";
	}

	@RequestMapping(value = "/touroku", method = { RequestMethod.POST })
	public String touroku(@ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form, Map<String, Object> map,
			Model model) throws Exception {

		// 画面上から契約情報を取得する
		Ｔ＿契約情報 keiyakuJoho = ORAC0080Form.getKeiyakuJoho();

		// 画面上から明細一覧を取得する
		List<ORAC0080FormMeisai> tpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		// 明細りストをループして行数をアカウントする
		ORAC0080FormMeisai meisaiForm = new ORAC0080FormMeisai();
		int gyousuCount = 0;
		for (ORAC0080FormMeisai tpayMeisai : tpaygMeisaiList) {
			gyousuCount = gyousuCount + 1;
			if (tpayMeisai.getCheckboxStatus()) {
				meisaiForm = tpayMeisai;
				break;
			}
		}

		// レコードが存在しない場合は、エラーメッセージ[E010]をダイアログ表示し、
		// OKボタン押下後は、登録ボタン押下前の状態に戻る。
		tpay = ORAC0080Service.selectTpayByPrimaryKey(keiyakuJoho.getＫ５契約番号(), keiyakuJoho.getサービス申込番号(),
				meisaiForm.getNengetsu(), meisaiForm.getShohinKataId());

		// TODO mybatisの返却値はnullですか。確認必要です。
		if (tpay == null) {
			map.put("tourokuErrMessage", Global.getMsg("E010"));
			// 処理を終了して、ORAC0020画面へ遷移する
			return "ORAC0080Form";
		}

		// 更新、登録を分岐に処理する
		tpay = new Ｔ＿ｐａｙｇ情報();
		if (gyousuCount != 0 && gyousuCount < tpaygMeisaiList.size()) {
			// 更新処理を行う
			tpay.setサービス申込番号(keiyakuJoho.getサービス申込番号());
			tpay.setＫ５契約番号(keiyakuJoho.getＫ５契約番号());
			tpay.set年月(meisaiForm.getNengetsu());
			tpay.set商品型ｉｄ(meisaiForm.getShohinKataId());
			tpay.setＦｊ売値(meisaiForm.getFjUrine());
			tpay.set超過使用料(meisaiForm.getChokaShiyoryo());
			tpay.set更新ユーザー(Global.getConfig("USER"));
			ORAC0080Service.updateByPrimaryKey(tpay);

		} else if (gyousuCount == tpaygMeisaiList.size()) {
			// 登録処理を行う
			tpay.setサービス申込番号(keiyakuJoho.getサービス申込番号());
			tpay.setＫ５契約番号(keiyakuJoho.getＫ５契約番号());
			tpay.setアイデンティティドメイン(keiyakuJoho.getアイデンティティドメイン());
			tpay.set年月(meisaiForm.getNengetsu());
			tpay.set商品型ｉｄ(meisaiForm.getShohinKataId());
			tpay.setＦｊ売値(meisaiForm.getFjUrine());
			tpay.setＦｊ単価(meisaiForm.getFjTanka());
			tpay.set超過使用料(meisaiForm.getChokaShiyoryo());
			tpay.setＰａａｓ連携済フラグ("0");
			tpay.set請求依頼抽出済フラグ("0");
			tpay.set論理削除フラグ(ORACConstants.DEL_FLAG_NORMAL);
			tpay.set登録ユーザー(Global.getConfig("USER"));
			tpay.set更新ユーザー(Global.getConfig("USER"));
			ORAC0080Service.insert(tpay);
		}
		//

		// 画面明細部を取得する
		// 画面フォーム条件をセットする
		map.put("Message", Global.getMsg("I006"));
		initPullDownList(ORAC0080Form);
		model.addAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "ORAC0080Form";
	}

	@RequestMapping("/sakujyoForCheck")
	public String sakujyo(@Valid @ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form, BindingResult result,
			Map<String, Object> map, Model model) throws Exception {
		// 画面チェックにエラー発生時に元の画面に戻り、エラーを表示する。
		List<String> errList = new ArrayList<String>();
		if (result.hasErrors()) {
			initPullDownList(ORAC0080Form);
			model.addAttribute("ORAC0080Form", ORAC0080Form);
			return "ORAC0080Form";
		}

		// 画面上から明細一覧を取得する
		List<ORAC0080FormMeisai> tpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		List<ORAC0080FormMeisai> seletedTpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		// 複合チェック
		// 選択されたcheckbox数をカウントする
		for (ORAC0080FormMeisai orac0080FormMeisai : tpaygMeisaiList) {
			if (orac0080FormMeisai.getCheckboxStatus()) {
				seletedTpaygMeisaiList.add(orac0080FormMeisai);
				int hikakuKeka = BigDecimal.ZERO.compareTo(orac0080FormMeisai.getOracleSeikyugaku());
				if ((hikakuKeka == 0) || (StringUtils.isEmpty(orac0080FormMeisai.getNengetsu()))) {
					errList.add(Global.getMsg("E002"));
					map.put("ErrorMessage", errList);
				}
			}
		}
		if (seletedTpaygMeisaiList.size() == 0) {
			errList.add(Global.getMsg("E002"));
			map.put("ErrorMessage", errList);
		}

		// 削除確認メッセージ[I003]をダイアログ表示する。
		map.put("sakujyoMessage", Global.getMsg("I003"));

		// 画面明細部を取得する
		// 画面フォーム条件をセットする
		initPullDownList(ORAC0080Form);
		model.addAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "ORAC0080Form";
	}

	@RequestMapping(value = "/sakujyo", method = { RequestMethod.POST })
	public String sakujyo(@ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form, Map<String, Object> map,
			Model model) throws Exception {

		// 画面上から契約情報を取得する
		Ｔ＿契約情報 keiyakuJoho = ORAC0080Form.getKeiyakuJoho();

		// 画面上から明細一覧を取得する
		List<ORAC0080FormMeisai> tpaygMeisaiList = ORAC0080Form.getTpaygMeisaiList();

		// 明細りストをループして行数をアカウントする
		ORAC0080FormMeisai meisaiForm = new ORAC0080FormMeisai();
		int gyousuCount = 0;
		for (ORAC0080FormMeisai tpayMeisai : tpaygMeisaiList) {
			gyousuCount = gyousuCount + 1;
			if (tpayMeisai.getCheckboxStatus()) {
				meisaiForm = tpayMeisai;
				break;
			}
		}

		// レコードが存在しない場合は、エラーメッセージ[E010]をダイアログ表示し、
		// OKボタン押下後は、登録ボタン押下前の状態に戻る。
		tpay = ORAC0080Service.selectTpayByPrimaryKey(keiyakuJoho.getＫ５契約番号(), keiyakuJoho.getサービス申込番号(),
				meisaiForm.getNengetsu(), meisaiForm.getShohinKataId());

		// TODO mybatisの返却値はnullですか。確認必要です。
		if (tpay == null) {
			map.put("tourokuErrMessage", Global.getMsg("E010"));
			// 処理を終了して、ORAC0020画面へ遷移する
			return "ORAC0080Form";
		}

		// 更新、登録を分岐に処理する
		Ｔ＿ｐａｙｇ情報 tpay = new Ｔ＿ｐａｙｇ情報();
		if (gyousuCount != 0 && gyousuCount < tpaygMeisaiList.size()) {
			// 更新処理を行う
			tpay.setサービス申込番号(keiyakuJoho.getサービス申込番号());
			tpay.setＫ５契約番号(keiyakuJoho.getＫ５契約番号());
			tpay.set年月(meisaiForm.getNengetsu());
			tpay.set商品型ｉｄ(meisaiForm.getShohinKataId());
			tpay.set論理削除フラグ(ORACConstants.DEL_FLAG_DELETE);
			tpay.set更新ユーザー(Global.getConfig("USER"));
			ORAC0080Service.logicalDelete(tpay);
		}

		// 画面明細部を取得する
		// 画面フォーム条件をセットする
		map.put("Message", Global.getMsg("I004"));
		initPullDownList(ORAC0080Form);
		model.addAttribute("ORAC0080Form", ORAC0080Form);

		// ORAC0020画面へ遷移する
		return "ORAC0080Form";
	}

	/**
	 *
	 * @return
	 */
	@RequestMapping(value = "/modoru", method = RequestMethod.GET)
	public String modoru(@ModelAttribute("ORAC0080Form") ORAC0080Form ORAC0080Form,
			RedirectAttributes redirectAttributes, Model model, HttpSession httpSession) {

		ORAC0020Form ORAC0020Form = (ORAC0020Form) httpSession.getAttribute("ORAC0020Form");
		// if (ORAC0080Form != null)) {
		// Ｔ＿契約情報 keiyakuJoho = ORAC0020Form.getKeiyakuJoho();
		// ORAC0020Form ORAC0020Form = new ORAC0020Form();
		// ORAC0020FormCondition condition = new ORAC0020FormCondition();
		// condition.setK5keiyakubango(keiyakuJoho.getＫ５契約番号());
		// condition.setSabisuMoshikomiBango(keiyakuJoho.getサービス申込番号());
		// condition.setAidenteiteiDmein(keiyakuJoho.getアイデンティティドメイン());
		// condition.setSabisushuryoBiFrom("ORAC0020Form",ORAC0020Form);// TODO
		// 設定方法分からない
		// redirectAttributes.addFlashAttribute("ORAC0020Form", ORAC0020Form);
		// return "redict:/ORAC0020Form/searchByKeiyakuCondition";
		// }
		model.addAttribute("ORAC0020Form", ORAC0020Form);

		return "redict:/ORAC0020Form/searchByKeiyakuCondition";
	}

	/**
	 * ORAC0080画面上の料金プラン別プルダウンリストの初期化を行う
	 *
	 * @param ORAC0010Form
	 */
	private void initPullDownList(ORAC0080Form ORAC0080Form) {

		// 料金プランのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORAC0080Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}

		// 料金プランが存在する場合、フォーム情報に設定する
		if (ryokimPurans.size() > 0) {
			ORAC0080Form.setRyokimPuranMap(Collections.unmodifiableMap(ryokimPurans));
		}
	}
}
