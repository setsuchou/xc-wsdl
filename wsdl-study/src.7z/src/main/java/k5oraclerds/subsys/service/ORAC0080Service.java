package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿ｐａｙｇ情報;

public interface ORAC0080Service {

	public Ｔ＿契約情報 selectKeiyakuJohoByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

	public List<Ｔ＿ｐａｙｇ情報> selectTpaygJohoByKeys(String ｋ５契約番号, String サービス申込番号);

	public Ｔ＿ｐａｙｇ情報 selectTpayByPrimaryKey(String ｋ５契約番号, String サービス申込番号,String 年月,String 商品型ｉｄ);

	public List<Ｍ＿商品型> getShohinGata();

	public List<Ｍ＿料金プラン> getRyokimPuran();

	public Ｍ＿商品型 getShohinKataMei(String shohinKataId,String ryokimpuran ,String nengetsu);

	int updateByPrimaryKey(Ｔ＿ｐａｙｇ情報 record);

	int insert(Ｔ＿ｐａｙｇ情報 record);

	int logicalDelete(Ｔ＿ｐａｙｇ情報 record);
}
