package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.Ｍ＿商品型Mapper;
import k5oraclerds.subsys.dao.Ｍ＿料金プランMapper;
import k5oraclerds.subsys.dao.Ｍ＿注文種別Mapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.dao.Ｔ＿注文情報Mapper;
import k5oraclerds.subsys.dao.Ｔ＿注文明細Mapper;
import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.service.ORAC0060Service;

@Service("ORAC0060Service")
public class ORAC0060ServiceImpl implements ORAC0060Service {

	public ORAC0060ServiceImpl() {
	}

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private Ｍ＿商品型Mapper Ｍ＿商品型Mapper;

	@Autowired
	private Ｍ＿注文種別Mapper Ｍ＿注文種別Mapper;

	@Autowired
	private Ｍ＿料金プランMapper Ｍ＿料金プランMapper;

	@Autowired
	private Ｔ＿注文情報Mapper Ｔ＿注文情報Mapper;

	@Autowired
	private Ｔ＿注文明細Mapper Ｔ＿注文明細Mapper;

	@Override
	public int insertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報) {
		int result = Ｔ＿契約情報Mapper.insert(Ｔ＿契約情報);
		System.out.println("ORAC0060ServiceImplの新規結果：" + result);
		return result;
	}
	@Override
	public Ｔ＿契約情報 selectKeiyakuJohoByPrimaryKey(String ｋ５契約番号, String サービス申込番号) {
		Ｔ＿契約情報 Ｔ＿契約情報 = Ｔ＿契約情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号);
		return Ｔ＿契約情報;
	}

	@Override
	public Ｔ＿注文情報 selectChumonJohoByPrimaryKey(String ｋ５契約番号, String サービス申込番号, Short 連番){
		Ｔ＿注文情報 注文情報 = Ｔ＿注文情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番);
		return 注文情報;

	}

	@Override
	public List<Ｔ＿注文情報> selectMotochumon(String サービス申込番号, Short 連番){
		List<Ｔ＿注文情報> Ｔ＿注文情報List = Ｔ＿注文情報Mapper.selectMotochumon(サービス申込番号, 連番);
		return Ｔ＿注文情報List;
	}

	@Override
	public List<Ｔ＿注文明細> selectChumonMesaiListByPrimaryKey(String ｋ５契約番号, String サービス申込番号, Short 連番){
		List<Ｔ＿注文明細> 注文明細List = Ｔ＿注文明細Mapper.selectListByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番);
		return 注文明細List;
	}

	@Override
	public Ｔ＿注文明細 selectChumonMesaiByPrimaryKey(String ｋ５契約番号, String サービス申込番号, Short 連番,String 商品型ｉｄ){
		Ｔ＿注文明細 注文明細 = Ｔ＿注文明細Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番,商品型ｉｄ);
		return 注文明細;
	}

	@Override
	public List<Ｍ＿商品型> getShohinGata() {

		List<Ｍ＿商品型> returnList = Ｍ＿商品型Mapper.selectAll();

		return returnList;
	}

	@Override
	public List<Ｍ＿料金プラン> getRyokimPuran() {
		List<Ｍ＿料金プラン> returnList = Ｍ＿料金プランMapper.selectAll();

		return returnList;
	}

	@Override
	public List<Ｍ＿注文種別> getChumonShubetsu() {

		List<Ｍ＿注文種別> returnList = Ｍ＿注文種別Mapper.selectAll();
		return returnList;
	}

	/*
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0030Service#getＴ＿契約情報ByPrimaryKey(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public int updateKeiyakuJoho(Ｔ＿契約情報 record) {

		return Ｔ＿契約情報Mapper.updateByPrimaryKey(record);
	}

	@Override
	public int updateInsertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報){
		Ｔ＿契約情報 KeiyakuJoho = selectKeiyakuJohoByPrimaryKey(Ｔ＿契約情報.getＫ５契約番号(),Ｔ＿契約情報.getサービス申込番号());
		if(KeiyakuJoho == null){
			return insertKeiyakuJoho(Ｔ＿契約情報);
		}else{
			return updateKeiyakuJoho(Ｔ＿契約情報);
		}
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.Short)
	 */
	private Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号, Short 連番) {
		Ｔ＿注文情報 Ｔ＿注文情報 = Ｔ＿注文情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番);
		return Ｔ＿注文情報;
	}

	@Override
	public int insertChumonjoho(Ｔ＿注文情報 Ｔ＿注文情報) {
		int result = Ｔ＿注文情報Mapper.insert(Ｔ＿注文情報);
		System.out.println("ORAC0060ServiceImplの新規結果：" + result);
		return result;
	}

	/*
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0030Service#getＴ＿契約情報ByPrimaryKey(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public int updateChumonjoho(Ｔ＿注文情報 record) {

		return Ｔ＿注文情報Mapper.updateByPrimaryKey(record);
	}

	@Override
	public int updateInsertChumonjoho(Ｔ＿注文情報 Ｔ＿注文情報){
		Ｔ＿注文情報 chumonJoho = selectByPrimaryKeyChumonJoho(Ｔ＿注文情報.getＫ５契約番号(),Ｔ＿注文情報.getサービス申込番号(),
				Ｔ＿注文情報.get連番());
		if(chumonJoho == null){
			return insertChumonjoho(Ｔ＿注文情報);
		}else{
			return updateChumonjoho(Ｔ＿注文情報);
		}
	}


	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.commonSecletService#selectByPrimaryKey(java.
	 * lang.String, java.lang.String, java.lang.Short, java.lang.String)
	 */
	private Ｔ＿注文明細 selectByPrimaryKeyChumonjohoMeisai(String ｋ５契約番号, String サービス申込番号, Short 連番, String 商品型ｉｄ) {
		Ｔ＿注文明細 Ｔ＿注文明細 = Ｔ＿注文明細Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号, 連番, 商品型ｉｄ);
		return Ｔ＿注文明細;
	}

	/*
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0030Service#getＴ＿契約情報ByPrimaryKey(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public int insertChumonjohoMeisai(Ｔ＿注文明細 Ｔ＿注文明細){
		int result = Ｔ＿注文明細Mapper.insert(Ｔ＿注文明細);
		System.out.println("ORAC0060ServiceImplの新規結果：" + result);
		return result;
	}


	@Override
	public int updateChumonjohoMeisai(Ｔ＿注文明細 record) {

		return Ｔ＿注文明細Mapper.updateByPrimaryKey(record);
	}

	@Override
	public int updateInsertChumonjohoMeisai(Ｔ＿注文明細 Ｔ＿注文明細){
		Ｔ＿注文明細 chumonjohoMeisai = selectByPrimaryKeyChumonjohoMeisai(Ｔ＿注文明細.getＫ５契約番号(),Ｔ＿注文明細.getサービス申込番号(),
				Ｔ＿注文明細.get連番(),Ｔ＿注文明細.get商品型ｉｄ());
		if(chumonjohoMeisai == null){
			return insertChumonjohoMeisai(Ｔ＿注文明細);
		}else{
			return updateChumonjohoMeisai(Ｔ＿注文明細);
		}
	}


}
