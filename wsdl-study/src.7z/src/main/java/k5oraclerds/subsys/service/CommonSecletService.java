package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿期間調整商品型;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｍ＿超過使用料;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;
import k5oraclerds.subsys.model.Ｔ＿注文明細;
import k5oraclerds.subsys.model.Ｔ＿無効化対象;
import k5oraclerds.subsys.model.Ｔ＿ｐａｙｇ情報;

public interface CommonSecletService {

	public Ｔ＿契約情報 selectByPrimaryKeyKeiyakuJoho(String ｋ５契約番号, String サービス申込番号);

	public Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号, Short 連番);

	public Ｔ＿注文情報 selectByPrimaryKeyChumonJoho(String ｋ５契約番号, String サービス申込番号);

	public Ｔ＿注文明細 selectByPrimaryKeyChumonjohoMeisai(String ｋ５契約番号, String サービス申込番号, Short 連番, String 商品型ｉｄ);

	public List<Ｔ＿注文明細> selectChomonListByKeys(String ｋ５契約番号, String サービス申込番号, Short 連番);

	public Ｔ＿ｐａｙｇ情報 selectByPrimaryKey(String ｋ５契約番号, String サービス申込番号, String 年月, String 商品型ｉｄ);

	public Ｍ＿超過使用料 selectByPrimaryKey(String 料金プランｉｄ, String 適用開始年月, String 適用終了年月);

	public Ｍ＿期間調整商品型 selectByPrimaryKey(String 商品型ｉｄ);

	List<Ｔ＿無効化対象> selectAllMukokaTaisho();

	public List<Ｍ＿商品型> selectAllShohinGata();

	public List<Ｍ＿商品型> selectShohinGataForChumonmesai(String 料金プランｉｄ, String 適用日);

	public List<Ｍ＿料金プラン> selectAllRyokimPuran();

	public List<Ｍ＿注文種別> selectAllChumonShubetsu();

	public boolean 契約情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号);

	public boolean 注文情報論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番);

	public boolean 注文明細論理削除フラグ判断ByKey(String ｋ５契約番号, String サービス申込番号,Short 連番, String 商品型ｉｄ);

	public String selectMessagesText(String messageId);

}
