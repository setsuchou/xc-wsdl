/*
 * jquery.fgnp-accordion.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/


(function ( $ )
{
	/**
	 * $(element).accordion();
	 * @param options
	 * @param options.divSelector - The jQuery selector to find what divs are content divs
	 * @param options.linkSelector - The jQuery selector to find the links that open/close divs
	 * @param options.partnerSelector - Find the partner div to the link clicked
	 * @param options.currentSelector - Find the current div
	 * @param options.collapsible - Can the accordion be collapsed?
	 * @param options.currentClass - The class name for panels and tabs that are selected
	 * @param options.singleClass - The class to add if the accordion is single only
	 * @param options.multiple - Boolean, whether or not multiple tabs can be opened at once
	 * @returns {*}
	 */
	$.fn.fgnpAccordion = function( options )
	{
		var defaults = {
			divSelector: ' > .fgnp-accordion-header + ',
			linkSelector: ' > .fgnp-accordion-header',
			partnerSelector: ' + ',
			currentSelector: ' > .fgnp-current',
			collapsible: false,
			currentClass: 'fgnp-current',
			singleClass: 'fgnp-single',
			scrollableClass: 'fgnp-scrollable2',
			multiple: true
		};

        var isMobile = !$('body').hasClass('fgnp-device-desktop');

		var opts = $.extend({ }, defaults, options);

		return $(this).each(function()
		{
			var opts = $.extend({ }, defaults, options);
			var data = $(this).data('accordion');

			var instOptions = $.extend( true, opts, data );

			if(instOptions.multiple)
				instOptions.collapsible = true;
			else
				$(this).addClass(instOptions.singleClass);

			$(this).data('accordion', $.extend(true, {}, instOptions));

			//Go through all links, if they're not marked as current, hide their partner
			var $links = $(this).find(instOptions.linkSelector);
			$links.each(function()
			{
				var $partner = $(this).find(instOptions.partnerSelector);
				if(!instOptions.multiple)
					$partner.addClass(instOptions.scrollableClass);

				if(!$(this).hasClass(instOptions.currentClass))
				{
					$partner.hide();
				}
			});

//			$(this).find('.' + instOptions.scrollableClass).fgnpScrollable();

			//Store the container in a local variable
			var $container = $(this);
			//When a link is clicked
			$links.on('click', function()
			{
				var instOptions = $container.data('accordion');
				//Get the div that the link is meant to open/close
				var $partner = $(this).find(instOptions.partnerSelector);

				//Check if it's already open, so that we can determine whether or not to collapse it
				if($(this).hasClass(instOptions.currentClass))
				{
					if(!instOptions.collapsible)
						return false;
					else
					{
						$(this).removeClass(instOptions.currentClass);
                        if(!isMobile){
    						$partner.slideUp().removeClass(instOptions.currentClass);
                        } else {
                            $partner.hide();
                        }
						return false;
					}
				}

				function linearStep(now, animation){
					var animationStart = animation.start;
					if (animationStart === 1){
						animationStart = 0;
					}
					animation.now = (animation.end - animationStart ) * animation.pos + animationStart;
				}

				var toClose = false;

				if(!instOptions.multiple)
				{
					//Deactivate currently activated divs, then activate the correct one
					var $active = $container.find(instOptions.currentSelector);
					var $activePartner = $active.find(instOptions.partnerSelector);

					$active.removeClass(instOptions.currentClass);
                    if(!isMobile){
    					toClose = $activePartner.slideUp({ easing: 'linear', step: linearStep});
                    } else {
                        toClose = $activePartner.hide();
                        if ($active.offset()){
                            if( $('body').scrollTop() > $active.offset().top){
                                $('body').animate({ scrollTop: $(this).offset().top - 100 });
                            }
                        }
                    }
				}
                if(!isMobile){
    				$partner.slideDown({ easing: 'linear', step: linearStep});
                } else {
                    $partner.show();
                }
				$(this).addClass(instOptions.currentClass);

				return true;
			});
		});
	};

})(jQuery);

/* Accordion Plugin ends here */
