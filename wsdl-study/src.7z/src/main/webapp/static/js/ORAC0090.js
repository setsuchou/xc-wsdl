$(function() {

	// カレンダ（初期値：なし）
	$('.datepicker').datepicker();

	// カレンダ（初期値：当日）
	$('.datepicker-today').datepicker().datepicker('setDate','today');

	$('.hideFlg').hide();

});

var setEvents = function() {
	// 契約単位のラジオボタンイベント設定
	$(".target_radio").on("change", function() {
		// まず全て押下不可にする
		$(".change_disabled").prop("disabled", true);
		$(".change_disabled2").prop("disabled", true);
		// チェックされたら契約単位関連ボタンを押下可能にする
		var value = true;
		if ($(this).prop("checked")) {
			value = false;
		}
		$(".change_disabled").prop("disabled", value);
	});

	// 注文単位のラジオボタンイベント設定
	$(".target_radio2").on("change", function() {
		// まず全て押下不可にする
		$(".change_disabled").prop("disabled", true);
		$(".change_disabled2").prop("disabled", true);
		// チェックされたら注文単位関連ボタンを押下可能にする
		var value = true;
		if ($(this).prop("checked")) {
			value = false;
		}
		$(".change_disabled2").prop("disabled", value);
	});
}

$(function() {
	// イベント設定
	setEvents();
});