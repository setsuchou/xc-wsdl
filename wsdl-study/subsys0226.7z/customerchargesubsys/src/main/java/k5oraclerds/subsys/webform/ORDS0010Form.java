package k5oraclerds.subsys.webform;

import java.io.Serializable;
import java.util.Map;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.model.Ｔ＿注文情報;

public class ORDS0010Form implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Valid
	private Ｔ＿契約情報 keiyakuJoho;
	@Valid
	private Ｔ＿注文情報 chumonjoho;
	
	private Ｍ＿商品型 shohyogata;

	private Map<String, String> shohinGataList;
	// 料金プランリスト
	private Map<String, String> ryokimPuranList;
	private Map<String, String> chumonShubetsuList;

	public Map<String, String> getShohinGataList() {
		return shohinGataList;
	}

	public void setShohinGataList(Map<String, String> shohinGataList) {
		this.shohinGataList = shohinGataList;
	}

	public Map<String, String> getRyokimPuranList() {
		return ryokimPuranList;
	}

	public void setRyokimPuranList(Map<String, String> ryokimPuranList) {
		this.ryokimPuranList = ryokimPuranList;
	}

	public Map<String, String> getChumonShubetsuList() {
		return chumonShubetsuList;
	}

	public void setChumonShubetsuList(Map<String, String> chumonShubetsuList) {
		this.chumonShubetsuList = chumonShubetsuList;
	}

	public Ｔ＿契約情報 getKeiyakuJoho() {
		return keiyakuJoho;
	}

	public void setKeiyakuJoho(Ｔ＿契約情報 keiyakuJoho) {
		this.keiyakuJoho = keiyakuJoho;
	}

	public Ｔ＿注文情報 getChumonjoho() {
		return chumonjoho;
	}

	public void setChumonjoho(Ｔ＿注文情報 chumonjoho) {
		this.chumonjoho = chumonjoho;
	}

	public Ｍ＿商品型 getShohyogata() {
		return shohyogata;
	}

	public void setShohyogata(Ｍ＿商品型 shohyogata) {
		this.shohyogata = shohyogata;
	}
}
