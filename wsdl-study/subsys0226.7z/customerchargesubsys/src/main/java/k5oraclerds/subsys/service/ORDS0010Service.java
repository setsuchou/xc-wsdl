package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;

public interface ORDS0010Service {

	public void insertKeiyakuJoho(Ｔ＿契約情報 Ｔ＿契約情報);

	public Ｔ＿契約情報 selectByPrimaryKey(String ｋ５契約番号, String サービス申込番号);

	public List<Ｍ＿商品型> getShohinGata();

	public List<Ｍ＿料金プラン> getRyokimPuran();

	public List<Ｍ＿注文種別> getChumonShubetsu();

}
