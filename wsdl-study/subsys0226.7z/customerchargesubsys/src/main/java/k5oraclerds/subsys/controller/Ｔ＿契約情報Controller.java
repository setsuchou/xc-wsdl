package k5oraclerds.subsys.controller;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.Ｔ＿契約情報Service;

@Controller
@RequestMapping("/keiyakuJohoController")
public class Ｔ＿契約情報Controller {

	@Resource
	private Ｔ＿契約情報Service t＿契約情報Service;

	@RequestMapping("/showKeiyakuJohoForm")
	public String showＴ＿契約情報(@Valid @ModelAttribute Ｔ＿契約情報 keiyakuJoho, BindingResult result, Model model) {
		Ｔ＿契約情報 returnEntity = t＿契約情報Service.getＴ＿契約情報ByPrimaryKey("00000001","000000000000001");
		model.addAttribute("keiyakuJoho", returnEntity);
		return "keiyakuJohoForm";
	}

	@RequestMapping("/checkKeiyakuJohoForm")
	public String checkＴ＿契約情報(@Valid @ModelAttribute Ｔ＿契約情報 keiyakuJoho, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println("errors size:"+result.getAllErrors().size());
			return "/keiyakuJohoForm";
		}
		return "keiyakuJohoForm";
	}

}
