package k5oraclerds.subsys.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import k5oraclerds.subsys.model.Ｍ＿商品型;
import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｍ＿注文種別;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.ORDS0010Service;
import k5oraclerds.subsys.webform.ORDS0010Form;

@Controller
@RequestMapping("/ORDS0010Controller")
public class ORDS0010Controller {

	private ORDS0010Form ORDS0010Form;

	@Resource
	private ORDS0010Service ORDS0010Service;

	@RequestMapping("/initORDS0010Form")
	public String initORDS0010Form(HttpServletRequest request, HttpServletResponse response, Model model) {
		ORDS0010Form = new ORDS0010Form();

		Ｔ＿契約情報 keiyakuJoho = ORDS0010Service.selectByPrimaryKey("00000001", "000000000000001");
		ORDS0010Form.setKeiyakuJoho(keiyakuJoho);

		// 商品型マスタのデータを取得する
		List<Ｍ＿商品型> shohinGataList = ORDS0010Service.getShohinGata();

		Map<String, String> shohinGatas = new LinkedHashMap<>();
		for (Ｍ＿商品型 shohinGata : shohinGataList) {
			shohinGatas.put(shohinGata.get商品型ｉｄ(), shohinGata.get商品型名());
		}
		ORDS0010Form.setShohinGataList(Collections.unmodifiableMap(shohinGatas));

		// 料金プランマスタのデータを取得する
		List<Ｍ＿料金プラン> ryokimPuranList = ORDS0010Service.getRyokimPuran();
		Map<String, String> ryokimPurans = new LinkedHashMap<>();
		for (Ｍ＿料金プラン ryokimPuran : ryokimPuranList) {
			ryokimPurans.put(ryokimPuran.get料金プランｉｄ(), ryokimPuran.get料金プラン名());
		}
		ORDS0010Form.setRyokimPuranList(Collections.unmodifiableMap(ryokimPurans));

		// 注文種別マスタのデータを取得する
		List<Ｍ＿注文種別> chumonShubetsuList = ORDS0010Service.getChumonShubetsu();
		Map<String, String> chumonShubetsus = new LinkedHashMap<>();
		for (Ｍ＿注文種別 chumonShubetsu : chumonShubetsuList) {
			chumonShubetsus.put(chumonShubetsu.get注文種別ｉｄ(), chumonShubetsu.get注文種別名());
		}
		ORDS0010Form.setChumonShubetsuList(Collections.unmodifiableMap(chumonShubetsus));

		model.addAttribute("ORDS0010Form", ORDS0010Form);
		return "ORDS0010Form";
	}

	@RequestMapping("/createORDS0010Form")
	public String createORDS0010Form(@Valid @ModelAttribute ORDS0010Form ORDS0010Form, BindingResult result,
			Model model) {
		Ｔ＿契約情報 keiyakuJoho = ORDS0010Form.getKeiyakuJoho();
		setCommonItem(keiyakuJoho);
		ORDS0010Service.insertKeiyakuJoho(keiyakuJoho);
		return "/../../submenu";
	}

	@RequestMapping("/validateORDS0010Form")
	public String validateORDS0010Form(@Valid @ModelAttribute ORDS0010Form ORDS0010Form, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			return "/ORDS0010Form";
		}
		return "redirect:/ORDS0010Controller/createORDS0010Form";
//		return "redirect:/createORDS0010Form";
	}
	
	@RequestMapping("/leaveORDS0010Form")
	public String createORDS0010Form(HttpServletResponse response)throws IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print("<script language=\"javascript\">alert('サブメニューに戻ります。');</script>");
		return "/../../submenu";
	}

	private void setCommonItem(Ｔ＿契約情報 keiyakuJoho) {
		keiyakuJoho.set論理削除フラグ("0");
		keiyakuJoho.set登録ユーザー("testuser001");
		keiyakuJoho.set更新ユーザー("testuser001");
		keiyakuJoho.set登録日時(new Date());
		keiyakuJoho.set更新日時(new Date());
	}

}
