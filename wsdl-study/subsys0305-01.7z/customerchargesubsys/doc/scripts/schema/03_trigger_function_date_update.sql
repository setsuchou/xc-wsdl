-- Function: trigger_function_date_update()

DROP FUNCTION trigger_function_date_update();

CREATE OR REPLACE FUNCTION trigger_function_date_update()
  RETURNS trigger AS
$BODY$BEGIN
IF TG_OP = 'INSERT' THEN
NEW."更新日時" := current_timestamp;
NEW."登録日時" := current_timestamp;
ELSE
IF TG_OP = 'UPDATE' THEN
NEW."更新日時" := current_timestamp;
END IF ;
END IF ;
RETURN NEW;
END ;$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION trigger_function_date_update()
  OWNER TO postgres;

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿料金プラン"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿注文種別"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿料金注文相関"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿商品型"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿超過使用料"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿期間調整商品型"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｍ＿メッセージ"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｔ＿契約情報"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｔ＿注文情報"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｔ＿注文明細"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｔ＿ＰＡＹＧ情報"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

CREATE TRIGGER trigger_date_update
  BEFORE INSERT OR UPDATE
  ON "Ｔ＿無効化対象"
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_function_date_update();

  