--DROP TABLE "Ｍ＿料金プラン";
--DROP TABLE "Ｍ＿注文種別";
--DROP TABLE "Ｍ＿料金注文相関";
--DROP TABLE "Ｍ＿商品型";
--DROP TABLE "Ｍ＿超過使用料";
--DROP TABLE "Ｍ＿期間調整商品型";
--DROP TABLE "Ｍ＿メッセージ";
--DROP TABLE "Ｔ＿契約情報";
--DROP TABLE "Ｔ＿注文情報";
--DROP TABLE "Ｔ＿注文明細";
--DROP TABLE "Ｔ＿ＰＡＹＧ情報";
--DROP TABLE "Ｔ＿無効化対象";

/* Ｍ＿料金プラン */
CREATE TABLE "Ｍ＿料金プラン" (
    "料金プランＩＤ" CHAR (2) NOT NULL
  , "料金プラン名" VARCHAR (32) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("料金プランＩＤ")
);
/* Ｍ＿注文種別 */
CREATE TABLE "Ｍ＿注文種別" (
    "注文種別ＩＤ" CHAR (2) NOT NULL
  , "注文種別名" VARCHAR (32) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("注文種別ＩＤ")
);
/* Ｍ＿料金注文相関 */
CREATE TABLE "Ｍ＿料金注文相関" (
    "料金プランＩＤ" CHAR (2) NOT NULL
  , "注文種別ＩＤ" CHAR (2) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("料金プランＩＤ","注文種別ＩＤ")
);
/* Ｍ＿商品型 */
CREATE TABLE "Ｍ＿商品型" (
    "商品型ＩＤ" CHAR (10) NOT NULL
  , "料金プランＩＤ" CHAR (2) NOT NULL
  , "適用開始年月日" CHAR (8) NOT NULL
  , "適用終了年月日" CHAR (8) NOT NULL
  , "ＰＡＹＧフラグ" CHAR (1) NOT NULL
  , "ＦＪ単価変更契機" CHAR (1) NOT NULL
  , "ＯＲＡＣＬＥ単価変更契機" CHAR (1) NOT NULL
  , "商品型名" VARCHAR (256) NOT NULL
  , "ＦＪ単価" NUMERIC(18,6) NOT NULL
  , "ＯＲＡＣＬＥ単価" NUMERIC(18,6) NOT NULL
  , "仕切り率" NUMERIC(7,6) NOT NULL
  , "ＯＲＡＣＬＥ側商品型ＩＤ" CHAR (6)
  , "表示順" NUMERIC(3,0) NOT NULL
  , "利用単位" VARCHAR (64) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("商品型ＩＤ","料金プランＩＤ","適用開始年月日","適用終了年月日")
);
/* Ｍ＿超過使用料 */
CREATE TABLE "Ｍ＿超過使用料" (
    "料金プランＩＤ" CHAR (2) NOT NULL
  , "適用開始年月" CHAR (6) NOT NULL
  , "適用終了年月" CHAR (6) NOT NULL
  , "商品型ＩＤ" CHAR (10) NOT NULL
  , "商品型名" VARCHAR (256) NOT NULL
  , "超過使用料単価" NUMERIC(18,6) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("料金プランＩＤ","適用開始年月","適用終了年月")
);
/* Ｍ＿期間調整商品型 */
CREATE TABLE "Ｍ＿期間調整商品型" (
    "商品型ＩＤ" CHAR (10) NOT NULL
  , "期間調整商品型ＩＤ" CHAR (10) NOT NULL
  , "期間調整商品型名" VARCHAR (256) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("商品型ＩＤ")
);
/* Ｍ＿メッセージ */
CREATE TABLE "Ｍ＿メッセージ" (
    "メッセージＩＤ" CHAR (4) NOT NULL
  , "メッセージ文言" VARCHAR (256) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
  , PRIMARY KEY ("メッセージＩＤ")
);
/* Ｔ＿契約情報 */
CREATE TABLE "Ｔ＿契約情報" (
    "Ｋ５契約番号" CHAR(8) NOT NULL
  , "サービス申込番号" CHAR(15) NOT NULL
  , "料金プランＩＤ" CHAR(2) NOT NULL
  , "アイデンティティドメイン" VARCHAR (32)
  , "サービス開始日" CHAR(8)
  , "サービス終了日" CHAR(8)
  , "ＣＳＩ" VARCHAR (16)
  , "オーダーＮＯ" VARCHAR (32)
  , "キャンセル依頼日" CHAR(8)
  , "ロスト処理依頼日" CHAR(8)
  , "解約申込請書発行日" CHAR(8)
  , "環境削除日" CHAR(8)
  , "論理削除フラグ" CHAR(1) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "登録ユーザー" VARCHAR (15) NOT NULL
  , "更新日時" TIMESTAMP
  , "更新ユーザー" VARCHAR (15)
  , PRIMARY KEY ("Ｋ５契約番号","サービス申込番号")
);
/* Ｔ＿注文情報 */
CREATE TABLE "Ｔ＿注文情報" (
    "Ｋ５契約番号" CHAR(8) NOT NULL
  , "サービス申込番号" CHAR(15) NOT NULL
  , "連番" NUMERIC(3) NOT NULL
  , "料金プランＩＤ" CHAR(2) NOT NULL
  , "注文種別ＩＤ" CHAR(2) NOT NULL
  , "オラクルオーダーＩＤ" VARCHAR (32)
  , "見積日" CHAR(8) NOT NULL
  , "ＦＪ料金表適用日" CHAR(8)
  , "ＯＲＡＣＬＥ料金表適用日" CHAR(8)
  , "コメント" VARCHAR (300)
  , "適用開始希望日" CHAR(8)
  , "特別値引フラグ" CHAR(1)
  , "開始日＿実績" CHAR(8)
  , "終了日＿実績" CHAR(8)
  , "最大開始日＿実績" CHAR(8)
  , "ユーザＩＤ" VARCHAR (256)
  , "ＰＡＡＳ連携済フラグ" CHAR(1) NOT NULL
  , "請求依頼抽出済フラグ" CHAR(1) NOT NULL
  , "申込請書発行日" CHAR(8)
  , "論理削除フラグ" CHAR(1) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "登録ユーザー" VARCHAR (15) NOT NULL
  , "更新日時" TIMESTAMP
  , "更新ユーザー" VARCHAR (15)
  , PRIMARY KEY ("Ｋ５契約番号","サービス申込番号","連番")
);
/* Ｔ＿注文明細 */
CREATE TABLE "Ｔ＿注文明細" (
    "Ｋ５契約番号" CHAR(8) NOT NULL
  , "サービス申込番号" CHAR(15) NOT NULL
  , "連番" NUMERIC(3) NOT NULL
  , "商品型ＩＤ" CHAR(10) NOT NULL
  , "料金プランＩＤ" CHAR(2) NOT NULL
  , "注文種別ＩＤ" CHAR(2) NOT NULL
  , "数量" NUMERIC(18,6) NOT NULL
  , "期間" NUMERIC(2,0) NOT NULL
  , "ＦＪ売値" NUMERIC(18,6) NOT NULL
  , "ＦＪ単価" NUMERIC(18,6) NOT NULL
  , "ＯＲＡＣＬＥ単価" NUMERIC(18,6) NOT NULL
  , "仕切り率" NUMERIC(7,6) NOT NULL
  , "ＦＪ想定仕入値" NUMERIC(18,6) NOT NULL
  , "開始日＿実績" CHAR(8)
  , "終了日＿実績" CHAR(8)
  , "開始日＿請求書" CHAR(8)
  , "終了日＿請求書" CHAR(8)
  , "金額調整フラグ" CHAR(1)
  , "ＯＲＡＣＬＥ請求額" NUMERIC(18,6)
  , "売上計上残金額" NUMERIC(18,6)
  , "原価計上残金額" NUMERIC(18,6)
  , "残数量" NUMERIC(18,6)
  , "論理削除フラグ" CHAR(1) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "登録ユーザー" VARCHAR (15) NOT NULL
  , "更新日時" TIMESTAMP
  , "更新ユーザー" VARCHAR (15)
  , PRIMARY KEY ("Ｋ５契約番号","サービス申込番号","連番","商品型ＩＤ")
);
/* Ｔ＿ＰＡＹＧ情報 */
CREATE TABLE "Ｔ＿ＰＡＹＧ情報" (
    "Ｋ５契約番号" CHAR(8) NOT NULL
  , "サービス申込番号" CHAR(15) NOT NULL
  , "アイデンティティドメイン" VARCHAR (32)
  , "年月" CHAR (6) NOT NULL
  , "商品型ＩＤ" CHAR (10) NOT NULL
  , "ＯＲＡＣＬＥ請求額" NUMERIC(18,6) NOT NULL
  , "ＦＪ単価" NUMERIC(18,6) NOT NULL
  , "ＦＪ売値" NUMERIC(18,6) NOT NULL
  , "超過使用料" NUMERIC(18,6) NOT NULL
  , "ＰＡＡＳ連携済フラグ" CHAR(1) NOT NULL
  , "請求依頼抽出済フラグ" CHAR(1) NOT NULL
  , "論理削除フラグ" CHAR(1) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "登録ユーザー" VARCHAR (15) NOT NULL
  , "更新日時" TIMESTAMP
  , "更新ユーザー" VARCHAR (15)
  , PRIMARY KEY ("Ｋ５契約番号","サービス申込番号","年月","商品型ＩＤ")
);
/* Ｔ＿無効化対象 */
CREATE TABLE "Ｔ＿無効化対象" (
    "利用実績番号" CHAR(15) NOT NULL
  , "サービス申込番号" CHAR(15) NOT NULL
  , "無効化済フラグ" CHAR(1) NOT NULL
  , "登録日時" TIMESTAMP NOT NULL
  , "更新日時" TIMESTAMP
);
