var XFW_JS_ERROR_PAGE = "/html/jsError.html";

var CORRELATION_VERIFICATION = "/correlationVerificationAjax/";