/*
 * jquery.fgnp-responsive-tables.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/

(function($)
{
    $.fn.fgnpResponsiveTables = function(options){
		$(".fgnp-device-mobile .fgnp-data-table").each(function()
		{
			var $this = $(this);

			//Wrap the table in a div
			var $container = $("<div class='fgnp-data-table-wrap'></div>");
			$this.wrap($container);

		});


		//If it's a block, not a table, we add a data-title attribute to each td so that the CSS will display nicely
		$(".fgnp-device-mobile .fgnp-data-table-block").each(function()
		{
			var headers = [];
			$(this).find('th').each(function()
			{
				headers.push($(this).text());
			});

			$(this).find('tr').each(function()
			{
				var i = 0;
				$(this).find('td').each(function()
				{
					$(this).attr('data-title', headers[i]);
					i++;
				});
			});
		});

/*		//If it's a full responsive table for desktop
		$(".fgnp-device-desktop .fgnp-table-responsive-full").each(function()
		{
			var $this = $(this);

			//Wrap the table in a div
			var $container = $("<div class='fgnp-table-responsive-full-wrap'></div>");
			$this.wrap($container);

			//Get a count of the columns to be fixed
			var count = $("tr:first .fgnp-table-fixed", $this).length;
			var left = 0;

			//Loop through the count
			for(var i = 0; i < count; i++)
			{
				var width = 0;
				var outerWidth = 0;
				var index = i + 1;

				//Go through each td in the column to get it's width, and increment the left variable
				$("tr .fgnp-table-fixed:nth-child(" + index + ")", $this).each(function()
				{
					if(width === 0)
					{
						width = $(this).width();
						outerWidth = $(this).outerWidth(true);
					}

					$(this).css({ width: width, left: left, position: 'absolute' });
				});

				left += outerWidth;
			}


			$this.parent().css('margin-left', left);

		});*/
    };
})(jQuery);

/* Responsive Tables Plugin ends here */
