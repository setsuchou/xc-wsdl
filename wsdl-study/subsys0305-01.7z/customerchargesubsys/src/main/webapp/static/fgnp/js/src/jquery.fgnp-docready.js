/*
 * jquery.fgnp-docready.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/

$(document).ready(function()
{
    docready();

});

function docready()
{

	// ---------------------------------------- Browser Detection START---------------------------------------------

	    //Detect the browser on load
	    $("body").detectBrowser();
	    $("body").fgnpDetectOrientation();

	    $(window).on('orientationchange, resize', function(event) {
            $("body").fgnpDetectOrientation();
	    });

//	    $(window).on('orientationchange', function(event) {
//            setTimeout(function() {
//                if($('body').hasClass('fgnp-device-tablet') && $('div').hasClass('fgnp-no-border-layout')){
//                    $('.fgnp-layout').css("min-height", $(window).outerHeight());
//                    relayout();
//                }
//            }, 500);
//	    });


	// ---------------------------------------- Browser Detection END-----------------------------------------------



	// ---------------------------------------- Android stock browser issue START ----------------------------------

	    //http://getbootstrap.com/getting-started/#support-android-stock-browser
	    var nua = navigator.userAgent;
	    var is_android = ((nua.indexOf('Mozilla/5.0') > -1 && nua.indexOf('Android ') > -1 && nua.indexOf('AppleWebKit') > -1) && !(nua.indexOf('Chrome') > -1));
	    if(is_android) {
		    $('select.fgnp-select').removeClass('fgnp-select').addClass('fgnp-select-android');
            $('ul.fgnp-dropdown').addClass('fgnp-dropdown-android');
	    }

	// ---------------------------------------- Android stock browser issue START ----------------------------------



	// ---------------------------------------- SVG support START --------------------------------------------------

	    //replacing svg images with png ones in case the browser doesn't support it
	    function supportsSVG() {
		return !! document.createElementNS && !! document.createElementNS('http://www.w3.org/2000/svg','svg').createSVGRect;
	    }
	    if (!supportsSVG() && $('body').hasClass('fgnp-svg')) {
		$('img[src$=".svg"]').attr('src', function() {
		    return $(this).attr('src').replace('.svg', '.png');
		});
	    }

	// ---------------------------------------- SVG support END ----------------------------------------------------



	// ---------------------------------------- General Functions START --------------------------------------------

	    // Ensuring the same order of the panes in every cases
//	    $('.fgnp-layout').append($('.fgnp-pane-left')).append($('.fgnp-pane-center')).append($('.fgnp-pane-right')).append($('.fgnp-pane-bottom'));

	    $(".fgnp-pager").fgnpPager();

		$(".fgnp-control-group > li").wrapInner("<div></div>");

	    $(".fgnp-overlay").on("click", function() {
		    $(".fgnp-overlay").css("display", "none");
	    });

	    if($('body').hasClass('fgnp-device-tablet')){
		$('body').css({"min-height": $('body').outerHeight()});
		$('.fgnp-layout').css({"min-height": $('.fgnp-layout').outerHeight()});
	    }

	    $('.fgnp-service-bar .fgnp-system-info').hide();

	    // Clear button hide or show
	    $("input[type=text].fgnp-input").on("keyup", function() {
		    if(!$(this).parent().has('.fgnp-clear')) {
			    return;
		    }
		    if($(this).val() === "") {
			    $(this).parent().children('.fgnp-clear').hide();
		    } else {
			    $(this).parent().children('.fgnp-clear').css('display', 'block');
		    }
	    });

	    // Clear button functionality
	    if($('body').hasClass('fgnp-device-mobile')){
		$(".fgnp-search .fgnp-clear, .fgnp-input-search .fgnp-clear").on("touchstart, click", function() {
			$(this).parent().children('.fgnp-input').val('').keyup();
		});
	    } else {
		 $(".fgnp-search .fgnp-clear, .fgnp-input-search .fgnp-clear").on("click", function() {
			$(this).parent().children('.fgnp-input').val('').keyup();
		});
	    }



	    // Add a $.support.placeholder() function
	    jQuery.support.placeholder = (function(){
		    var i = document.createElement('input');
		    return 'placeholder' in i;
	    })();

	    // If browser doesn't support placeholders, simulate it
	    if(!$.support.placeholder) {
		    $("input[placeholder]").each(function() {
			if($(this).parents().hasClass('fgnp-placeholder-input')) return;
			if($(this).val() === '') $(this).val($(this).attr('placeholder'));
		    });

		    $(document).on("focusin focusout", "input[placeholder]", function(event) {
			    if($(this).parents().hasClass('fgnp-placeholder-input')) return;
			    if(event.type === "focusin") {
				    if($(this).val() === $(this).attr('placeholder')) {
					$(this).val('');
				    }
			    } else  {
				    if($(this).val() === '') {
					$(this).val($(this).attr('placeholder'));
				    }
			    }
		    });

		    $('form').on("submit", function () {
			    $(this).find('[placeholder]').each(function() {
				    if($(this).val() === $(this).attr('placeholder'))
				    $(this).val('');
			    });
		    });
	    }

        // Add fgnp-active class
        var touch_target = '.fgnp-button, .fgnp-flat-button';
        $(document).on('touchstart touchend', touch_target, function (event)
        {
		    switch(event.type)
		    {
			    case "touchstart":
				    $(this).addClass('fgnp-touch-active');
				    break;

			    case "touchend":
				    $(this).removeClass('fgnp-touch-active');
				    break;
		    }
        });

        // Add fgnp-focus class
        if($('body').hasClass('fgnp-device-desktop')){
            $('body').fgnpKeyboardFocus();
        }

	    // Add fgnp-focus to input containers
	    $(document).on('focusin focusout', '.fgnp-search input, .fgnp-input-search input', function(event)
	    {
		    switch(event.type)
		    {
			    case "focusin":
				    $(this).parent().addClass('fgnp-focus');
				    break;

			    case "focusout":
				    $(this).parent().removeClass('fgnp-focus');
				    break;
		    }
	    });

	    // Add fgnp-hover to li elements
	    if(!$('body').hasClass('fgnp-device-mobile')){
		$(document).on('mouseover mouseout', '.fgnp-listview.fgnp-hover li', function(event)
		{
			switch(event.type)
			{
				case "mouseover":
					$(this).addClass('fgnp-hover-item').parents().removeClass('fgnp-hover-item');
					event.stopPropagation();
					break;

				case "mouseout":
					$(this).removeClass('fgnp-hover-item');
					break;
			}

			return false;
		});
	    }


	// ---------------------------------------- General Functions END ----------------------------------------------

	// ---------------------------------------- Layout Functions START ---------------------------------------------


	    if($("body").hasClass('fgnp-device-mobile') || $("body").hasClass('fgnp-device-tablet'))
	    {
		if($('.fgnp-service-bar').length > 0 || $('.fgnp-navbar').length > 0){

		    //creating and populating the offcanvas panel
		    if(!$('.fgnp-offcanvas').length)
		    {
			$('body').append('<div class="fgnp-offcanvas"></div>');
		    }
		    //moving the service bar and navbar contents to the mobile header section in fgnp-pane-top
		    $('body').addClass('fgnp-body-offcanvas').prepend('<div class="fgnp-mobile-header"><span class="fgnp-offcanvas-switch"></span></div>');

		    var $productname = $('.fgnp-service-bar .fgnp-product-name');
		    var $files = $productname.find('img');

		    $files.each(function() {
		        var path = $(this).attr('src');
			    var ext = path.substring(path.lastIndexOf('.')+1, path.length);
			    var filename = path.substring(0, path.lastIndexOf('.'));
			    $(this).attr('src', filename+'-mobile.'+ext);
		    });

		    var $systeminfo = $('.fgnp-service-bar .fgnp-system-info');
		    var $systemaction = $('.fgnp-service-bar .fgnp-system-action');
		    var $useraction = $('<div class="fgnp-user-action"></div>');
		    var $useractionfirstelement = $('.fgnp-user-action').children().find("[data-dropdown]");
		    var $logo = $('.fgnp-service-bar .fgnp-logo');
		    var $copyright = $('.fgnp-copyright');

		    $('.fgnp-offcanvas').append('<div class="fgnp-offcanvas-content"></div>');
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append($systemaction);
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append($systeminfo);
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append('<span class="fgnp-offcanvas-menu">Menu</span>');
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append($('.fgnp-nav'));
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append($useraction);
		    $('.fgnp-offcanvas .fgnp-offcanvas-content .fgnp-user-action').prepend('<span class="fgnp-offcanvas-user">' + $($useractionfirstelement.find('.fgnp-text')).text() + '</span>');
		    if($useractionfirstelement.length > 0){
			$('.fgnp-offcanvas .fgnp-offcanvas-content .fgnp-user-action').append($('#' + $useractionfirstelement.attr("data-dropdown").replace('#',''))).show();
			$('#' + $useractionfirstelement.attr("data-dropdown").replace('#','')).removeClass();
		    }
		    $('.fgnp-offcanvas .fgnp-offcanvas-content').append('<div class="fgnp-offcanvas-footer"></div>');
		    $('.fgnp-offcanvas-footer').append($logo);
		    $('.fgnp-offcanvas-footer').append($productname);
		    $('.fgnp-offcanvas-footer').append($copyright);
		    $('.fgnp-mobile-header').append($('.fgnp-nav-action'));
		    //change flat button style on the dark headers
		    if (!$('body').hasClass('fgnp-mobile-header-light')) {
		        $('.fgnp-mobile-header .fgnp-flat-button').each(function() {
		            if (!$(this).hasClass('fgnp-highlight')) {
		                $(this).addClass('fgnp-highlight').addClass('fgnp-color');
		            }
		        });
		    }
		    $('.fgnp-service-bar').html('').hide();
		    $('.fgnp-navbar').html('').hide();
		    $('.fgnp-pane-top').remove();


		    //hiding and displaying the off-canvas panel with the mobile status bar and navbar
		    $('.fgnp-offcanvas-switch').on("click", function(e){
			if($('.fgnp-offcanvas').is(":visible")){
			    $('.fgnp-offcanvas').hide();
			    $('body').removeClass("fgnp-offcanvas-visible", "fgnp-overflow");
			} else {
			    if($('.fgnp-layout').outerHeight() > $('body').height()){
				$('body').addClass("fgnp-overflow");
			    }
			    $('.fgnp-offcanvas').show();
			    $('body').addClass("fgnp-offcanvas-visible");
			}
		    });

		    //hiding the off-canvas panel when a click happens anywhere (else) on the page
		    $(document).on("mouseup", function (e)
		    {
			var container = $(".fgnp-offcanvas");
			var switchbutton = $('.fgnp-offcanvas-switch');

			if (!container.is(e.target) && container.has(e.target).length === 0 && !switchbutton.is(e.target)){
			    container.hide();
			    $('body').removeClass("fgnp-offcanvas-visible", "fgnp-overflow");
			}
		    });

		}

		//applying the 'fgnp-current' class on the 'fgnp-pane-center' page
		var currentPageLength = 0;
		$('.fgnp-mobile-page').each(function(){
		    if ($(this).hasClass('fgnp-current')) currentPageLength++
		});
		if (currentPageLength == 0) $('.fgnp-pane-center').addClass('fgnp-current')

		}

	    //building the layout
	    $('.fgnp-layout-inner').layout();
	    var container = $(".fgnp-layout");
	    function relayout()
	    {
		    container.layout({resize : false });
		    $(".fgnp-scrollable, .fgnp-accordion.fgnp-single").fgnpScrollable(null, "mobile");
	    }

	    if(!$("body").hasClass('fgnp-device-mobile')){
            $(window).resize(relayout);
            relayout();
	    } else {
            $(".fgnp-accordion").parent().css("height", "auto");
        }

	    if($("body").hasClass('fgnp-device-desktop')){
		$('.fgnp-resizable').resizable();
	    }

	    $('.fgnp-layout-toggle').fgnpLayoutToggle();


	// ---------------------------------------- Layout Functions END -----------------------------------------------



	// ---------------------------------------- Modal View Functions START -----------------------------------------

	    // *this entire section should be moved into the plugin at some point. Not in the document ready function section but into actual functions

	    // Attach the modal functionality to an object with attr data-fgnp-modal="#ID"
	    $("[data-modal-target]").on('click', function ()
	    {
		    var id = $(this).data('modal-target');
		    var element = $("#" + id);

		    if(!$("body").hasClass('fgnp-device-mobile')){
			if(element.data('modalWidth') !== undefined){
			    element.css('width', element.data('modalWidth'));
			}
			if(element.data('modalHeight') !== undefined){
			    element.css('height', element.data('modalHeight'));
			}
			if(!parseInt(element.css('min-height')) > 0){
			    element.css('min-height', element.outerHeight()+'px');
			}
			if(!parseInt(element.css('min-width')) > 0){
			    element.css('min-width', element.outerWidth()+'px');
			}
		    }


		    var opts = $.extend( {}, { position: 'center'}, $(this).data('modal'));
		    //var opts = $(this).data('modal');

		    var getYCoord = function (windowHeight, $popup, o)
		    {
			if($("body").hasClass('fgnp-device-mobile')){
			    return Math.max(o.amsl, ((windowHeight - $popup.outerHeight(true)) / 2 - o.amsl) + parseInt($(window).scrollTop()));
			} else {
			    return Math.max(0, (windowHeight - $popup.outerHeight(true) - o.amsl));
			}
		    };

		    var getXCoord = function (windowWidth, $popup, o)
		    {
			    return (windowWidth - $popup.outerWidth(true)) / 2;
		    };

		    if(opts.position.indexOf("top") !== -1)
		    {
			    getYCoord = function (windowHeight, $popup, o)
			    {
				if($("body").hasClass('fgnp-device-mobile')){
				    return o.amsl + parseInt($(window).scrollTop());
				} else {
				    return o.amsl;
				}
			    };
		    }

		    if(opts.position.indexOf("right") !== -1)
		    {
			    getXCoord = function (windowWidth, $popup, o)
			    {
				    return windowWidth - $popup.outerWidth(true) - o.amsl;
			    };
		    }

		    if(opts.position.indexOf("left") !== -1)
		    {
			    getXCoord = function (windowWidth, $popup, o)
			    {
				    return o.amsl;
			    };
		    }

		    if(opts.position === "center")
		    {
			    getXCoord = function (windowWidth, $popup, o)
			    {
				    return (windowWidth - $popup.outerWidth(true)) / 2
			    };

			    getYCoord = function (windowHeight, $popup, o)
			    {
				if($("body").hasClass('fgnp-device-mobile')){
				    return Math.max(o.amsl + parseInt($(window).scrollTop()), ((windowHeight - $popup.outerHeight(true)) / 2 - o.amsl) + parseInt($(window).scrollTop()));
				} else {
				    return (windowHeight - $popup.outerHeight(true)) / 2
				}
			    };
		    }

		    opts.getXCoord = getXCoord;
		    opts.getYCoord = getYCoord;
		    delete opts.position;

		    element.fgnpModal(opts);
		    element.resize();

	    });

	    // displaying the breadcrumb in a modal window
//        if($("body").hasClass('fgnp-device-mobile')){
//
//            $(".fgnp-breadcrumbs").each(function(){
//                $(this).attr({'data-dropdown': 'fgnp-dropdown-mobile'});
//
//                var links = $(this).find('li');
//                var message = '<ul class="fgnp-dropdown" id="fgnp-dropdown-mobile">';
//
//                $(links).each(function ()
//                {
//                    $(this).find('span').remove();
//                    var messageHTML = $('<div>').append($(this).clone()).html();
//                    message += messageHTML;
//                });
//                message += "</ul>";
//
//                $('#fgnp-dropdown-mobile').remove();
//                $('body').append(message);
//
//            });
//        }

//	    $(".fgnp-device-mobile .fgnp-breadcrumbs .fgnp-current").on("click", function (event)
//	    {
//		    event.stopPropagation();
//		    var breadCrumbs = $(this).closest('.fgnp-breadcrumbs');
//		    var links = $(breadCrumbs).find('li');
//		    var message = '<ul>';
//
//		    $(links).each(function ()
//		    {
//			    $(this).find('span').remove();
//			    var messageHTML = $('<div>').append($(this).clone()).html();
//			    message += messageHTML;
//		    });
//		    message += "</ul>";
//
//		    $.fgnpAlert(message, 1); //passing "1" as the indicator of mobile device
//		    return false;
//	    });


	// ---------------------------------------- Modal View Functions END -------------------------------------------

	// ---------------------------------------- Dropdown Functions START -------------------------------------------

	    // *this entire section should be moved into the plugin at some point. Not in the document ready function section but into actual functions

	    //giving ID-s to all elements that has dropdown but doesn't have ID
	    $('[data-dropdown]').each(function () {
		    var callerid, targetid, newid, newincid;

		    callerid = $(this).attr('id');
		    if(callerid === undefined){
			    newid = $(this).data('dropdown') + 'Trigger';
			    newincid = 0;

			    while($('body').find(newid).length > 0) {
				newid = newid + String(newincid);
				newincid++;
			    }
			    newid = newid.replace("#", '');
			    $(this).attr('id', newid);
			    callerid = $(this).attr('id');
		    }
		    callerid = "#" + String(callerid);
		    targetid = "#" + $(this).data('dropdown').replace("#", "");
		    $(callerid).fgnpDropdown(targetid);
	    });

//	    $('body.fgnp-device-mobile [data-dropdown] ').on('click', function (e)
//	    {
//		    var element = $('#' + $(this).data('dropdown').replace('#', ''));
//		    var newElement = element.clone();
//		    newElement.removeClass();
//		    newElement.attr("id", newElement.attr("id") + '_clone');
//		    newElement.appendTo(element.parent()).hide();
//		    $('#' + $(this).attr('id').replace('#', '')).fgnpDropdown('#' + newElement.attr('id').replace('#',''));
//		    $.fgnpAlert(newElement, 1); //passing "1" as the indicator of mobile device
//	    });

	// ---------------------------------------- Dropdown Functions END ---------------------------------------------


	// ---------------------------------------- Tabs width Functions START -----------------------------------------

	    if($("body").hasClass('fgnp-device-mobile')){
			$('.fgnp-tabs').addClass('fgnp-justified');
	    }

	// ---------------------------------------- Tabs width Functions END -------------------------------------------

	// ---------------------------------------- Pane swipe and move Functions START---------------------------------

	    if($.fn.detectBrowser && $.fn.detectBrowser('isMobile'))
	    {
		$('.fgnp-scrollable').toggleClass('fgnp-scrollable fgnp-scrollable-mobile');
		$('.fgnp-scrollable-mobile').css("height","");
		//$('.fgnp-data-table').addClass('fgnp-data-table-block');

		$('.fgnp-pane-left, .fgnp-pane-center, .fgnp-pane-right, .fgnp-pane-bottom').removeClass('fgnp-mobile-page').addClass('fgnp-mobile-page');

		$(document).on('click', '[data-page-link]', function()
		{
			var selector = $(this).data('page-link');
			var $page = $(selector);
			$.fgnpPages('selectPage', { page : $page });
			return false;
		});

		var $pages = $(".fgnp-mobile-page");
		if($pages.length > 1)
		{
		    // pane swiping by fingers to left and right
//		    $(document).fgnpSwipe({
//			swipe: function(event, direction, distance, duration, fingerCount) {
//				switch(direction)
//				{
//					case "left":
//						$.fgnpPages('selectPage', { index: $.fgnpPages('nextPage') });
//						break;
//
//					case "right":
//						$.fgnpPages('selectPage', { index: $.fgnpPages('previousPage') });
//						break;
//				}
//			},
//			threshold: 100
//		    });

		    // pane "swiping" (moving) by clicking on the left or right arrows
		    $(".fgnp-pane-to-left").on('click', function () {
			$.fgnpPages('selectPage', { index: $.fgnpPages('previousPage') });
		    });

		    $(".fgnp-pane-to-right").on('click', function () {
			$.fgnpPages('selectPage', { index: $.fgnpPages('nextPage') });
		    });


		} else {
		    $("body").addClass("fgnp-no-carousel");
		}
	    }

	// ---------------------------------------- Pane swipe and move Functions Functions END -----------------------



	// ---------------------------------------- Table sortable Functions START ------------------------------------

	    // *this entire section should be moved into the plugin at some point. Not in the document ready function section but into actual functions

	    $(document).on('click', '.fgnp-table-fixed-header-thead th', function()
	    {
		    var $this = $(this);

		    var dir = $.fn.fgnpTableSortable.dir;
		    var sort_dir = $this.data("sort-dir") === dir.ASC ? dir.DESC : dir.ASC;

		    var $wrapper = $(this).parents('.fgnp-table-fixed-header-wrapper');
		    var $tbodyTable = $wrapper.find('.fgnp-table-fixed-header-tbody table');

		    var index = $(this).index();
		    $tbodyTable.find('th').eq(index).click();

		    $this.parent().find('th').data("sort-dir", null).removeClass("fgnp-asc fgnp-des");
		    $this.data("sort-dir", sort_dir).addClass("fgnp-" + sort_dir);
	    });

	// ---------------------------------------- Table sortable Functions END ---------------------------------------


	// ---------------------------------------- Plugin bindings START ----------------------------------------------

	    // Binding plugins to elements
//	    $('[title]').fgnpTooltip();
	    $('body').fgnpResponsiveTables();
//	    $(".fgnp-listbox").fgnpSelector();
//	    $(".fgnp-selector").fgnpSelector();
	    $(".fgnp-tabs").fgnpTabs();
	    $('.fgnp-tile-container').fgnpTiles();
	    $(".fgnp-pagination").fgnpPagination();
	    $(".fgnp-accordion").fgnpAccordion();
	    $(".fgnp-data-table.fgnp-sortable").fgnpTableSortable();
        if(!$("body").hasClass('fgnp-device-mobile')){
            $(".fgnp-scrollable, .fgnp-accordion.fgnp-single").fgnpScrollable();
        } else {
       	    $(".fgnp-scrollable").fgnpScrollable();
        }

	    $('.fgnp-date').fgnpDatepicker();

	    if(!$("body").hasClass('fgnp-device-mobile')){
		$(".fgnp-draggable").fgnpDraggable();
	    }

	    $(".fgnp-tree").each(function() {
		    $(this).fgnpTree($(this).data('list-view'));
	    });

	// ---------------------------------------- Plugin bindings END ------------------------------------------------

};

// the width of the system bar can be calculated only after all the images are loaded so the $(window).load function has to be used
$(window).load(function() {

// ---------------------------------------- Getting the width of fgnp-system-info START ------------------------

    var setSystemInfoWidth = function(){
	if(!($('body').hasClass('fgnp-device-mobile') || $('body').hasClass('fgnp-device-tablet'))){
	    var productImageLeft = 0;
	    $('.fgnp-service-bar .fgnp-product-name').show();
	    if($('.fgnp-service-bar .fgnp-product-name').length > 0){
		productImageLeft = parseInt($('.fgnp-service-bar').css('padding-left').replace('px', '')) + $('.fgnp-service-bar .fgnp-product-name').outerWidth();
	    }
	    $('.fgnp-service-bar .fgnp-system-info').css({"position": "absolute", "top": 0+"px", "left": productImageLeft + "px"});

	    $('.fgnp-service-bar .fgnp-system-info').outerWidth($('.fgnp-service-bar').width() - $('.fgnp-service-bar .fgnp-product-name').outerWidth() -
		    $('.fgnp-service-bar .fgnp-system-action').outerWidth() - $('.fgnp-service-bar .fgnp-user-action').outerWidth() - $('.fgnp-service-bar .fgnp-logo').outerWidth());

	    $('.fgnp-service-bar .fgnp-system-info').show();
	}
    };
    setSystemInfoWidth();

    $(window).on('resize', function(){
	    setSystemInfoWidth();
    });

// ---------------------------------------- Getting the width of fgnp-system-info END --------------------------



// ---------------------------------------- Getting the mobile-title START -------------------------------------


    var setMobileTitleWidth = function(){
	if(($('body').hasClass('fgnp-device-mobile') || $('body').hasClass('fgnp-device-tablet')) && $('.fgnp-mobile-header').length > 0){


	    var sectionLeft, sectionWidth;
	    var $sectionTitle = '<div class="fgnp-section-title"></div>';
	    var $header = $('.fgnp-mobile-header');

	    sectionWidth = $header.width();
	    sectionLeft = ($header.outerWidth() - $header.width()) / 2 + $header.offset().left;

	    if($header.children().not('.fgnp-section-title').length > 0) {
		$header.children().not('.fgnp-section-title').each(function(){
		    sectionWidth = sectionWidth - $(this).outerWidth();
		});

		if($('.fgnp-offcanvas-switch').length > 0){
		    sectionLeft = $('.fgnp-offcanvas-switch').offset().left + $('.fgnp-offcanvas-switch').actual('outerWidth');
		}
	    }

	    if($header.find('.fgnp-section-title').length === 0){
		$header.append($sectionTitle);
	    }

	    $header.find('.fgnp-section-title').css({
		"top": "0px",
		"left": sectionLeft + "px",
		"width": sectionWidth + "px"
	    });

	    $header.find('.fgnp-section-title').show();
	}
    };
    setMobileTitleWidth();

    $(window).on('resize', function(){
	    setMobileTitleWidth();
    });

    $('.fgnp-mobile-header .fgnp-section-title').html($('.fgnp-offcanvas .fgnp-nav li.fgnp-current').text());


// ---------------------------------------- Getting the mobile-title END ----------------------------------------------


});

/* Docready ends here */
