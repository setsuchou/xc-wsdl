/*
 * jquery.fgnp-pager.js v1.3.2
 * Copyright 2015 FUJITSU LIMITED
 *=============================================================================================================*/

(function ($)
{
	var methods = {
		init: function (options)
		{
			return $(this).each(function ()
			{
				var $this = $(this);

				var data = $(this).data(options.dataKey);
				var newOpts = $.extend({}, options, data);
				newOpts.strings = $.extend({}, options.defaultStrings, newOpts.text);

				if (!newOpts.currentPage)
				    newOpts.currentPage = newOpts.start;

				if (newOpts.start >= newOpts.end)
				    return;

				var id = $this.attr('id');
				if (!id)
				    id = 'pager-dropdown';
				else
				    id = id + '-dropdown';

				var $pager = $("<ul class='fgnp-pager'></ul>");
				var $first = $('<li class="fgnp-pager-first"><button class="fgnp-flat-button"><span class="fgnp-font-icon-page-first"></span></button></li>');
				var $prev = $('<li class="fgnp-pager-prev"><button class="fgnp-flat-button"><span class="fgnp-font-icon-page-back"></span></button></li>');

				var $page = $('<li class="fgnp-pager-select">' +
				    '<button class="fgnp-flat-button" data-dropdown="#' + id + '">' +
				    '<span class="fgnp-text">' + newOpts.text + newOpts.currentPage + '/' + newOpts.end + '</span><span class="fgnp-menu"></span>' +
				    '</button></li>');

				var $next = $('<li class="fgnp-pager-next"><button class="fgnp-flat-button"><span class="fgnp-font-icon-page-next"></span></button></li>');
				var $last = $('<li class="fgnp-pager-last"><button class="fgnp-flat-button"><span class="fgnp-font-icon-page-last"></span></button></li>');

				var $dropdown = $("<ul id='" + id + "' class='fgnp-dropdown fgnp-fixed'></ul>");
				for (var i = newOpts.start; i < newOpts.end + 1; i++)
				{
				    var $class = "";
				    if (i === newOpts.currentPage)
				        $class = 'fgnp-current';

				    var $link = $('<li class="' + $class + '"><a class="' + $class + '" href="#">' + i + '</a></li>');
				    $link.click({currentPage: i, options: newOpts}, methods.onPageSelect);
				    $dropdown.append($link);
				}

				if (newOpts.currentPage === newOpts.start)
				{
				    $prev.find('button').attr("disabled", "disabled");
				    $first.find('button').attr("disabled", "disabled");
				}

				if (newOpts.currentPage === newOpts.end)
				{
				    $next.find('button').attr("disabled", "disabled");
				    $last.find('button').attr("disabled", "disabled");
				}

				$first.find('button').click({ currentPage: newOpts.start, options: newOpts}, methods.onPageSelect);
				$prev.find('button').click({ currentPage: newOpts.currentPage - 1, options: newOpts}, methods.onPageSelect);

				$next.find('button').click({ currentPage: newOpts.currentPage + 1, options: newOpts}, methods.onPageSelect);
				$last.find('button').click({ currentPage: newOpts.end, options: newOpts}, methods.onPageSelect);

				$pager.append($first, $prev);
				$pager.append($page);
				$page.append($dropdown);
				$pager.append($next, $last);
				$(this).replaceWith($pager);
                $dropdown.appendTo('body');

            });
        },

		onPageSelect: function (event)
		{
			var options = event.data.options;
			var currentPage = event.data.currentPage;

			if (currentPage < options.start)
				currentPage = options.start

			if (currentPage > options.end)
				currentPage = options.end

			var url = options.pageUrl;
			url = url.replace("{page}", currentPage);
			window.location = url;
		}
	};

	$.fn.fgnpPager = function (method, opts)
	{
		var defaults = {
			text       : '',
			dataKey    : 'pager',
			start      : 0,
			end        : 0,
			currentPage: 0,
			pageUrl    : "",
			methods    : { }
		};

		if (!opts && typeof method === "object")
			opts = method;

		var options = $.extend({}, defaults, opts);

		if (options.methods)
			$.extend(methods, options.methods);

		var arguments = [ options ];

		if (methods[method])
		{
			return methods[method].apply(this, arguments);
		}
		else if (typeof method === 'object' || !method)
		{
			return methods.init.apply(this, arguments);
		}
	};
})(jQuery);

(function ($)
{
	var methods = {
		init: function (options)
		{
			return $(this).each(function ()
			{
				var data = $(this).data(options.dataKey);
				var newOpts = $.extend({}, options, data);
				newOpts.strings = $.extend({}, options.defaultStrings, newOpts.text)

				if (!newOpts.currentPage)
					newOpts.currentPage = newOpts.start;

				if (newOpts.start >= newOpts.end)
					return;

				var $pager = $("<ul class='fgnp-pagination'></ul>");
				var $prev = $('<li class="fgnp-prev"><a href="#">' + newOpts.strings.prev + '</a></li>');

				var $next = $('<li class="fgnp-next"><a href="#">' + newOpts.strings.next + '</a></li>');

				$prev.click({ currentPage: newOpts.currentPage - 1, options: newOpts}, methods.onPageSelect);

				$next.click({ currentPage: newOpts.currentPage + 1, options: newOpts}, methods.onPageSelect);

				$pager.append($prev);

				//If the surroundPage number is even, add 1 to it to make it odd
				if (newOpts.surroundPage % 2 === 0)
					newOpts.surroundPage++;

				//Split the numbers down the middle
				var total = newOpts.surroundPage - 1;
				var left = total / 2;
				var right = total / 2;

				//Calculate if the center is too close to either side
				var actualLeft = newOpts.currentPage - newOpts.start;
				var actualRight = newOpts.end - newOpts.currentPage;

				//If too close to the left, move numbers to the right
				if (actualLeft < left)
				{
					var diff = left - actualLeft;
					left -= diff;
					right += diff;
				}

				//If too close to the right, move numbers to the left
				if (actualRight < right)
				{
					var diff = right - actualRight;
					right -= diff;
					left += diff;
				}

				//If it's still too close to the left, adjust manually
				if (newOpts.currentPage - left < newOpts.start)
					left = newOpts.currentPage - newOpts.start;

				//If it's still to close to the right, adjust manually
				if (newOpts.currentPage + right > newOpts.end)
					right = newOpts.end - newOpts.currentPage;

				//If the show first option is true, and the first number isn't within our range, show the first number
				if (newOpts.showFirst && newOpts.currentPage - left !== newOpts.start)
				{
					var $link = $("<li><a href='#'>" + newOpts.start + "</a></li>");
					$link.click({ currentPage: newOpts.start, options: newOpts}, methods.onPageSelect);
					$pager.append($link);

					if (newOpts.currentPage - left - 1 > newOpts.start)
						$pager.append('<li class="fgnp-more">...</li>');
				}

				//Show the numbers to the left of the current page
				for (var i = newOpts.currentPage - left; i < newOpts.currentPage; i++)
				{
					var $link = $("<li><a href='#'>" + i + "</a></li>");
					$link.click({ currentPage: i, options: newOpts}, methods.onPageSelect);
					$pager.append($link);
				}

				//Show the current page
				var $link = $("<li class='fgnp-current'>" + newOpts.currentPage + "</li>");
				$link.click({ currentPage: newOpts.currentPage, options: newOpts}, methods.onPageSelect);
				$pager.append($link);

				//Show the numebrs to the right of the current page
				for (var i = newOpts.currentPage + 1; i <= newOpts.currentPage + right; i++)
				{
					var $link = $("<li><a href='#'>" + i + "</a></li>");
					$link.click({ currentPage: i, options: newOpts}, methods.onPageSelect);
					$pager.append($link);
				}

				//If showLast is true, and the last number isn't within our range, show it
				if (newOpts.showLast && newOpts.currentPage + right < newOpts.end)
				{

					if (newOpts.currentPage + right + 1 < newOpts.end)
						$pager.append('<li class="fgnp-more">...</li>');

					var $link = $("<li><a href='#'>" + newOpts.end + "</a></li>");
					$link.click({ currentPage: newOpts.end, options: newOpts}, methods.onPageSelect);
					$pager.append($link);
				}

				//If we are the first or last page, hide the previous or next link respectively
				if (newOpts.currentPage === newOpts.start)
					$prev.hide();

				if (newOpts.currentPage === newOpts.end)
					$next.hide();

				$pager.append($next);

				$(this).replaceWith($pager);
			});
		},

		onPageSelect: function (event)
		{
			var options = event.data.options;
			var currentPage = event.data.currentPage;

			if (currentPage < options.start)
				currentPage = options.start

			if (currentPage > options.end)
				currentPage = options.end

			var url = options.pageUrl;
			url = url.replace("{page}", currentPage);
			window.location = url;
		}
	};
	$.fn.fgnpPagination = function (method, opts)
	{
		/**
		 * @param dataKey: The key for the .data() for optios
		 * @param start: The first number in our pages array
		 * @param end: The last number in our pages array
		 * @param currentPage: The current page we are on
		 * @surroundPage: How many pages to be shown in total
		 * @showFirst: Show the first page if it's not in our array
		 * @showLast: Show the last page if it's not in our range
		 * @pageUrl: The url to send people to on click
		 * @onPageSelect: The function that runs when someone selects a page
		 */
		var defaultOptions = {
			dataKey       : 'pagination',
			start         : 0,
			end           : 0,
			currentPage   : 0,
			surroundPage  : 5,
			showFirst     : true,
			showLast      : true,
			pageUrl       : "",
			text          : { },
			methods       : { },
			defaultStrings: {
				next: "Next",
				prev: "Prev"
			}
		};

		if (!opts && typeof method === "object")
			opts = method;

		var options = $.extend({}, defaultOptions, opts);

		if (options.methods)
			$.extend(methods, options.methods);

		if ($.fn.detectBrowser && $.fn.detectBrowser('isMobile'))
		{
			options.showLast = false;
			options.showFirst = false;
		}

		var arguments = [ options ];

		if (methods[method])
		{
			return methods[method].apply(this, arguments);
		}
		else if (typeof method === 'object' || !method)
		{
			return methods.init.apply(this, arguments);
		}
	};
})(jQuery);

/* Pager Plugin ends here */