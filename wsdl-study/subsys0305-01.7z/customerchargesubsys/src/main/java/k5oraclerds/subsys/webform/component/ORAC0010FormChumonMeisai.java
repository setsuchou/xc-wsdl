package k5oraclerds.subsys.webform.component;

import java.io.Serializable;

import javax.validation.Valid;

import k5oraclerds.subsys.model.Ｔ＿注文明細;

public class ORAC0010FormChumonMeisai implements Serializable {

	private static final long serialVersionUID = 1L;
	// チェックボックス
	private boolean booleanCheckbox;

	// 商品名
	private String shohinmei;

	// Ｔ＿注文明細
	@Valid
	private Ｔ＿注文明細 注文明細;


	/**
	 * @return the booleanCheckbox
	 */
	public boolean getStrCheckbox() {
		return booleanCheckbox;
	}

	/**
	 * @param booleanCheckbox the booleanCheckbox to set
	 */
	public void setStrCheckbox(boolean booleanCheckbox) {
		this.booleanCheckbox = booleanCheckbox;
	}

	/**
	 * @return the shohinmei
	 */
	public String getShohinmei() {
		return shohinmei;
	}

	/**
	 * @param shohinmei the shohinmei to set
	 */
	public void setShohinmei(String shohinmei) {
		this.shohinmei = shohinmei;
	}

	/**
	 * @return the 注文明細
	 */
	public Ｔ＿注文明細 get注文明細() {
		return 注文明細;
	}

	/**
	 * @param 注文明細 the 注文明細 to set
	 */
	public void set注文明細(Ｔ＿注文明細 注文明細) {
		this.注文明細 = 注文明細;
	}

}
