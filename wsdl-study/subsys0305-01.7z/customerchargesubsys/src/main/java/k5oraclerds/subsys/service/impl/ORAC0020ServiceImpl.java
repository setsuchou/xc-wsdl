package k5oraclerds.subsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import k5oraclerds.subsys.dao.ORAC0020FormMeisaiMapper;
import k5oraclerds.subsys.dao.Ｔ＿契約情報Mapper;
import k5oraclerds.subsys.model.Ｔ＿契約情報;
import k5oraclerds.subsys.service.ORAC0020Service;
import k5oraclerds.subsys.webform.component.ORAC0020FormMeisai;

@Service("ORAC0020Service")
public class ORAC0020ServiceImpl implements ORAC0020Service {

	@Autowired
	private Ｔ＿契約情報Mapper Ｔ＿契約情報Mapper;

	@Autowired
	private ORAC0020FormMeisaiMapper ORAC0020FormMeisaiMapper;

	@Override
	public Ｔ＿契約情報 getＴ＿契約情報ByPrimaryKey(String ｋ５契約番号, String サービス申込番号) {
		// TODO 自動生成されたメソッド・スタブ
		Ｔ＿契約情報 entity = Ｔ＿契約情報Mapper.selectByPrimaryKey(ｋ５契約番号, サービス申込番号);
		return entity;
	}

	@Override
	public List<ORAC0020FormMeisai> selectMeisaiByKeiyakuCondition(String sabisuMoshikomiBango, String k5keiyakubango,
			String aidenteiteiDmein, String sabisushuryoBiFrom, String sabisushuryoBiTo) {
		// List<ORAC0020FormMeisai> list = new ArrayList<ORAC0020FormMeisai>();
		List<ORAC0020FormMeisai> list = ORAC0020FormMeisaiMapper.selectMeisaiByKeiyakuCondition(sabisuMoshikomiBango,
				k5keiyakubango, aidenteiteiDmein, sabisushuryoBiFrom, sabisushuryoBiTo);
		return list;
	}

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * k5oraclerds.subsys.service.ORAC0020Service#selectMeisaiByChumonCondition(
	 * java.lang.String, java.lang.String, java.lang.Short, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<ORAC0020FormMeisai> selectMeisaiByChumonCondition(String サービス申込番号, String Ｋ５契約番号, Short 連番,
			String アイデンティティドメイン, String サービス終了日from, String サービス終了日to, String 適用開始希望日from, String 適用開始希望日to) {
		List<ORAC0020FormMeisai> list = ORAC0020FormMeisaiMapper.selectMeisaiByChumonCondition( サービス申込番号,  Ｋ５契約番号,連番,
				 アイデンティティドメイン,サービス終了日from,  サービス終了日to,  適用開始希望日from,  適用開始希望日to);
		return list;
	}

}
