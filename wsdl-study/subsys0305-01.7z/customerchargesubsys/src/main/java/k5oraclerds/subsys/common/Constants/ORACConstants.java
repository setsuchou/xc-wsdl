package k5oraclerds.subsys.common.Constants;

/**
 *
 *  定数を定義するクラス
 * @author setsuchou
 *
 *
 */
public final class ORACConstants {


	/**
	 * 論理削除フラグ（0：削除しない；1：削除；）
	 */
	public static final String DEL_FLAG_NORMAL = "0";
	public static final String DEL_FLAG_DELETE = "1";
}
