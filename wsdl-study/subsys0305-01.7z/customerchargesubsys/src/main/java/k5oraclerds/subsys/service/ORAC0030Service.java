package k5oraclerds.subsys.service;

import java.util.List;

import k5oraclerds.subsys.model.Ｍ＿料金プラン;
import k5oraclerds.subsys.model.Ｔ＿契約情報;

public interface ORAC0030Service {

	public int updateByPrimaryKey(Ｔ＿契約情報 record);

	public List<Ｍ＿料金プラン> getRyokimPuran();

}
